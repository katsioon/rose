# ⭐ Rosé Bot — Patreon Setup Guide

Everything you need to launch your Patreon page and start earning from Rosé Bot.

---

## 1. Create Your Patreon Page

1. Go to **https://patreon.com** → click **"Create on Patreon"**
2. Choose **"Membership"** as your creator type
3. Page name: **Rosé Bot** (or your preferred name)
4. Category: **Gaming** → **Bots & Tools**
5. Add a short description — example:

   > *Rosé is a cozy all-in-one Discord bot with AI chat, virtual pets, support tickets, RL resources, economy games, and more. Support development and unlock Premium features!*

6. Upload a profile picture (your bot's avatar or a cute rose graphic)
7. **Don't publish yet** — finish setting up tiers first

---

## 2. Set Up Tiers

Go to your page → **"Add a tier"**. Here's a recommended structure:

---

### 🌸 Tier 1 — Supporter · **$2/month**

**Title:** Supporter  
**Description:**
> You love Rosé and want to keep her running! Every bit helps with hosting costs.

**Benefits:**
- 💛 Supporter role in the Rosé Discord server
- Your name in `/credits` (if you add that command)
- Warm fuzzy feelings 🌸

---

### 🌹 Tier 2 — Premium User · **$4/month**

**Title:** Premium  
**Description:**
> Unlock the full Rosé experience with Premium features on any server you're in.

**Benefits:**
- ⭐ **Premium status on your Discord account** (works in every server with Rosé)
- 🤖 **50 AI messages/day** (vs 5 free)
- 🧠 **AI conversation memory** — Rosé remembers your chats
- 🎨 **AI image prompt generator**
- 🐾 **Up to 5 pets** (vs 1)
- 🐉 **Rare & Legendary pet types** unlocked
- 💰 **2× daily coins** (🪙1,000 vs 500)
- 💼 **1.5× work earnings**
- 📚 **Submit RL resources** to the library
- 🎫 **Up to 10 open tickets** (vs 1)
- ⭐ Premium badge in your `/userinfo`

---

### 👑 Tier 3 — Server Premium · **$9/month**

**Title:** Server Premium  
**Description:**
> Unlock Premium for your entire Discord server — all members benefit!

**Benefits:**
- 🏠 **All Premium features unlocked server-wide** (every member gets Premium perks)
- 💬 Priority support in the Rosé Discord
- 🔔 Early access to new features
- Your server listed as a "Featured Server" in `/premium info`
- Direct line to the developer for feedback/feature requests

---

### 💎 Tier 4 — Lifetime · **$50 one-time** *(optional)*

**Title:** Lifetime Premium  
**Description:**
> One-time payment for permanent Premium on your account — forever.

**Benefits:**
- Everything in Premium User tier, permanently
- Special Lifetime badge in Discord

> ⚠️ To enable one-time payments on Patreon: go to **Membership → Settings → Payment Options** and enable "one-time support." Alternatively, skip this tier and offer it manually via Ko-fi or PayPal.

---

## 3. Connect Patreon to Your Discord Server

This automatically gives paying members their Discord role.

1. In Patreon: **Settings → Apps → Discord** → Connect your Discord account
2. In your Discord server: Create these roles:
   - `🌸 Supporter`
   - `⭐ Premium`
   - `👑 Server Premium`
3. Back in Patreon, under each tier → **"Add a Discord role"** → map to the matching role
4. Members who subscribe get the role automatically within a few minutes

---

## 4. Manually Grant Premium in the Bot

After someone subscribes and gets their Discord role, grant them bot Premium using your dev command:

```
/dev grant_premium target_id: 123456789  target_type: user  days: 30
```

**Automating this** (optional but worth doing eventually):
- Use the **Patreon Webhooks API** to listen for new pledges
- When a pledge fires → call your own endpoint → run the db update
- This requires a small web server (Flask/FastAPI) but makes it fully automatic

For now, manual granting works fine. Check your Patreon dashboard weekly and grant/revoke as needed.

To **revoke** when someone cancels:
```
/dev revoke_premium target_id: 123456789  target_type: user
```

---

## 5. Page Tips

### Description page sections to include:
- **What is Rosé?** — 2-3 sentence pitch
- **Why support?** — hosting costs, development time, your goals
- **What's Premium?** — bullet list of perks with emojis
- **FAQ** — "What servers does Premium work on?", "How do I get my role?", etc.

### Post regularly to keep patrons engaged:
- 📢 Changelog posts when you add new features
- 🗺️ Roadmap posts showing what's coming
- 🎉 Milestone celebrations (100 servers, 1000 users, etc.)
- 🙏 Supporter shoutouts

### Set your goal:
Add a visible earnings goal like:
> **$20/month** — Covers monthly hosting costs (VPS)
> **$50/month** — Covers hosting + domain + development time

Goals make people feel like their contribution directly matters.

---

## 6. Promote Your Patreon

- Add the link to every Premium-related bot response (already done in the bot!)
- Pin a message in your Discord support server with the Patreon link
- Add it to your bot's `/help` output (already done)
- List it on bot directories:
  - **top.gg** — add a "Support" link
  - **discord.bots.gg**
  - **infinitybots.gg**

---

## 7. Patreon Best Practices

| Do | Don't |
|----|-------|
| Keep tiers simple (2-3 is plenty) | Have 8 confusing tiers |
| Post updates regularly | Go silent for weeks |
| Thank supporters publicly | Ignore your community |
| Be transparent about how funds are used | Be vague about costs |
| Respond to messages quickly | Let DMs pile up |

---

## 8. Summary Checklist

- [ ] Create Patreon page at patreon.com
- [ ] Set up 2-3 tiers (Supporter $2, Premium $4, Server $9)
- [ ] Connect Patreon to your Discord server
- [ ] Create Discord roles and map them to tiers
- [ ] Update `discord.gg/rKajpSCGKF` and `patreon.com/katsioon` in the bot to your actual links
- [ ] Add your real Discord user ID to `DEV_IDS` in `cogs/dev.py`
- [ ] Publish your Patreon page
- [ ] Post about it in your Discord server

---

*Good luck! 🌸 Even $10/month covers most hosting costs for a small bot.*
