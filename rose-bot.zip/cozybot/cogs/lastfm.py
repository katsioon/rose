"""
Last.fm integration for Rosé bot.
/fm nowplaying, recent, topartists, toptracks, topalbums, profile, compare, link
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiohttp
import aiosqlite
import os
from utils.helpers import error_embed, info_embed

LASTFM_KEY = os.getenv("LASTFM_API_KEY", "")
BASE = "https://ws.audioscrobbler.com/2.0/"

class LastFMCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _api(self, method, **params):
        if not LASTFM_KEY:
            return None, "No Last.fm API key! Add `LASTFM_API_KEY` to `.env` — get one free at last.fm/api"
        p = {"method": method, "api_key": LASTFM_KEY, "format": "json", **params}
        async with aiohttp.ClientSession() as s:
            async with s.get(BASE, params=p, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status != 200:
                    return None, f"Last.fm error {r.status}"
                data = await r.json()
                if "error" in data:
                    return None, data.get("message", "Unknown error")
                return data, None

    async def _get_username(self, user_id, interaction_username):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT lastfm_username FROM social_profiles WHERE user_id=?", (user_id,)) as cur:
                row = await cur.fetchone()
        return row[0] if row and row[0] else None

    async def _require_username(self, interaction):
        un = await self._get_username(interaction.user.id, interaction.user.name)
        if not un:
            await interaction.response.send_message(embed=error_embed(
                "Link your Last.fm first! Use `/fm link <username>`"
            ))
        return un

    @nextcord.slash_command(name="fm", description="🎵 Last.fm music commands")
    async def fm(self, interaction: nextcord.Interaction):
        pass

    @fm.subcommand(name="link", description="Link your Last.fm account")
    async def link(self, interaction: nextcord.Interaction,
                   username: str = SlashOption(description="Your Last.fm username")):
        data, err = await self._api("user.getinfo", user=username)
        if err:
            await interaction.response.send_message(embed=error_embed(f"User not found: {err}"))
            return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING", (interaction.user.id,))
            await db.execute("UPDATE social_profiles SET lastfm_username=? WHERE user_id=?", (username, interaction.user.id))
            await db.commit()
        info = data["user"]
        embed = nextcord.Embed(title="🎵 Last.fm Linked!", description=f"Linked to **{info['name']}**", color=0xD51007)
        embed.add_field(name="Scrobbles", value=f"{int(info['playcount']):,}")
        embed.set_thumbnail(url=info["image"][-1]["#text"] if info.get("image") else None)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="nowplaying", description="See what you're listening to right now")
    async def nowplaying(self, interaction: nextcord.Interaction,
                         user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        un = await self._get_username(target.id, target.name)
        if not un:
            await interaction.response.send_message(embed=error_embed(
                f"{'That user has' if user else 'You have'} not linked a Last.fm account. Use `/fm link`"
            ))
            return
        data, err = await self._api("user.getrecenttracks", user=un, limit=1)
        if err:
            await interaction.response.send_message(embed=error_embed(err)); return
        tracks = data["recenttracks"].get("track", [])
        if not tracks:
            await interaction.response.send_message(embed=error_embed("No recent tracks found.")); return
        t = tracks[0] if isinstance(tracks, list) else tracks
        now = t.get("@attr", {}).get("nowplaying") == "true"
        embed = nextcord.Embed(
            title=f"{'🎵 Now Playing' if now else '⏮️ Last Played'}",
            description=f"**{t['name']}** by **{t['artist']['#text']}**\n*{t['album']['#text']}*",
            color=0xD51007,
        )
        embed.set_author(name=f"{target.display_name} on Last.fm", icon_url=target.display_avatar.url)
        img = t.get("image", [{}])[-1].get("#text", "")
        if img: embed.set_thumbnail(url=img)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="recent", description="View recent tracks")
    async def recent(self, interaction: nextcord.Interaction,
                     user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        un = await self._get_username(target.id, target.name)
        if not un:
            await interaction.response.send_message(embed=error_embed("No Last.fm linked. Use `/fm link`")); return
        data, err = await self._api("user.getrecenttracks", user=un, limit=10)
        if err:
            await interaction.response.send_message(embed=error_embed(err)); return
        tracks = data["recenttracks"].get("track", [])
        lines = [f"{'▶️' if t.get('@attr',{}).get('nowplaying') else '⏮️'} **{t['name']}** — {t['artist']['#text']}"
                 for t in tracks[:10]]
        embed = nextcord.Embed(title=f"🎵 {target.display_name}'s Recent Tracks",
                               description="\n".join(lines), color=0xD51007)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="topartists", description="Top artists this week/month/year/all")
    async def topartists(self, interaction: nextcord.Interaction,
                         period: str = SlashOption(choices={"Week":"7day","Month":"1month","Year":"12month","All time":"overall"}, required=False, default="7day")):
        un = await self._require_username(interaction)
        if not un: return
        data, err = await self._api("user.gettopartists", user=un, period=period, limit=10)
        if err:
            await interaction.response.send_message(embed=error_embed(err)); return
        artists = data["topartists"]["artist"]
        lines = [f"`{i+1}.` **{a['name']}** — {int(a['playcount']):,} plays" for i,a in enumerate(artists)]
        embed = nextcord.Embed(title=f"🎤 Top Artists ({period})", description="\n".join(lines), color=0xD51007)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="toptracks", description="Top tracks this week/month/year/all")
    async def toptracks(self, interaction: nextcord.Interaction,
                        period: str = SlashOption(choices={"Week":"7day","Month":"1month","Year":"12month","All time":"overall"}, required=False, default="7day")):
        un = await self._require_username(interaction)
        if not un: return
        data, err = await self._api("user.gettoptracks", user=un, period=period, limit=10)
        if err:
            await interaction.response.send_message(embed=error_embed(err)); return
        tracks = data["toptracks"]["track"]
        lines = [f"`{i+1}.` **{t['name']}** — {t['artist']['name']} ({int(t['playcount']):,})" for i,t in enumerate(tracks)]
        embed = nextcord.Embed(title=f"🎵 Top Tracks ({period})", description="\n".join(lines), color=0xD51007)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="profile", description="View your Last.fm profile stats")
    async def profile(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        un = await self._get_username(target.id, target.name)
        if not un:
            await interaction.response.send_message(embed=error_embed("No Last.fm linked.")); return
        data, err = await self._api("user.getinfo", user=un)
        if err:
            await interaction.response.send_message(embed=error_embed(err)); return
        u = data["user"]
        embed = nextcord.Embed(title=f"🎵 {u['name']}", url=u["url"], color=0xD51007)
        embed.add_field(name="Scrobbles", value=f"{int(u['playcount']):,}")
        embed.add_field(name="Artists",   value=f"{int(u.get('artist_count',0)):,}")
        embed.add_field(name="Albums",    value=f"{int(u.get('album_count',0)):,}")
        embed.add_field(name="Tracks",    value=f"{int(u.get('track_count',0)):,}")
        img = u.get("image", [{}])[-1].get("#text", "")
        if img: embed.set_thumbnail(url=img)
        await interaction.response.send_message(embed=embed)

    @fm.subcommand(name="compare", description="Compare music taste with another user")
    async def compare(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(description="User to compare with")):
        un1 = await self._get_username(interaction.user.id, interaction.user.name)
        un2 = await self._get_username(user.id, user.name)
        if not un1 or not un2:
            await interaction.response.send_message(embed=error_embed("Both users need Last.fm linked (`/fm link`)")); return
        d1, _ = await self._api("user.gettopartists", user=un1, period="overall", limit=50)
        d2, _ = await self._api("user.gettopartists", user=un2, period="overall", limit=50)
        if not d1 or not d2:
            await interaction.response.send_message(embed=error_embed("Could not fetch data.")); return
        a1 = {a["name"] for a in d1["topartists"]["artist"]}
        a2 = {a["name"] for a in d2["topartists"]["artist"]}
        common = a1 & a2
        pct = int(len(common) / max(len(a1 | a2), 1) * 100)
        shared = ", ".join(list(common)[:5]) or "None found"
        embed = nextcord.Embed(title=f"🎵 Taste Comparison", color=0xD51007)
        embed.description = (
            f"**{interaction.user.display_name}** vs **{user.display_name}**\n\n"
            f"**{pct}% compatible** 🎧\n**Shared artists:** {shared}"
        )
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(LastFMCog(bot))
