import nextcord
from nextcord.ext import commands
import aiosqlite
from utils.helpers import info_embed, now

class PremiumCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @nextcord.slash_command(name="premium", description="⭐ Premium commands")
    async def premium(self, interaction: nextcord.Interaction): pass

    @premium.subcommand(name="info", description="Learn about Rosé Premium")
    async def premium_info(self, interaction: nextcord.Interaction):
        embed = nextcord.Embed(
            title="⭐ Rosé Premium",
            description="Unlock the full cozy experience!",
            color=0xFFD700)
        embed.add_field(
            name="🎫 Tickets",
            value="• Up to 10 open tickets (vs 1)\n• Custom ticket messages",
            inline=False)
        embed.add_field(
            name="🐾 Pets",
            value="• Up to 5 pets (vs 1)\n• Rare & Legendary pet types\n• 2x daily coins",
            inline=False)
        embed.add_field(
            name="📚 RL Resources",
            value="• Submit custom resources\n• Premium resource feed",
            inline=False)
        embed.add_field(
            name="💰 Economy",
            value="• 2x daily reward (🪙 1,000 vs 500)\n• 1.5x work reward",
            inline=False)
        embed.add_field(
            name="🛒 Get Premium",
            value="**[Patreon](https://patreon.com/katsioon)** — Subscribe to get access\n"
                  "**[Support Server](https://discord.gg/rKajpSCGKF)** — Join for help & updates",
            inline=False)
        embed.set_footer(text="Join the Discord for support • Patreon for Premium")
        await interaction.response.send_message(embed=embed)

    @premium.subcommand(name="status", description="Check your premium status")
    async def premium_status(self, interaction: nextcord.Interaction):
        user_premium = interaction.user.id in self.bot.premium_users
        guild_premium = interaction.guild_id in self.bot.premium_guilds
        
        if not user_premium and not guild_premium:
            embed = nextcord.Embed(
                description="You don't have Premium!\n\n"
                            "Get it on **[Patreon](https://patreon.com/katsioon)** or join the **[Support Server](https://discord.gg/rKajpSCGKF)** for info!",
                color=0x808080)
            await interaction.response.send_message(embed=embed)
            return

        lines = []
        if user_premium:
            async with aiosqlite.connect(self.bot.db_path) as db:
                async with db.execute("SELECT expires_at FROM premium_users WHERE user_id=?", (interaction.user.id)) as cur:
                    row = await cur.fetchone()
            exp = row[0] if row else 0
            exp_str = "Never" if exp > 9999999990 else f"<t:{exp}:D>"
            lines.append(f"✅ **User Premium** — expires {exp_str}")

        if guild_premium:
            async with aiosqlite.connect(self.bot.db_path) as db:
                async with db.execute("SELECT expires_at FROM premium_guilds WHERE guild_id=?", (interaction.guild_id)) as cur:
                    row = await cur.fetchone()
            exp = row[0] if row else 0
            exp_str = "Never" if exp > 9999999990 else f"<t:{exp}:D>"
            lines.append(f"✅ **Server Premium** — expires {exp_str}")

        embed = nextcord.Embed(
            title="⭐ Premium Status",
            description="\n".join(lines),
            color=0xFFD700)
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(PremiumCog(bot))
