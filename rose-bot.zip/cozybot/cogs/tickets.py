import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import asyncio
import time
from utils.helpers import success_embed, error_embed, info_embed, premium_embed, now
from utils.i18n import t

MAX_TICKETS_FREE    = 1
MAX_TICKETS_PREMIUM = 10


class TicketCreateView(nextcord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @nextcord.ui.button(label="🎫 Open Ticket", style=nextcord.ButtonStyle.green, custom_id="ticket:create")
    async def create_ticket(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        await TicketsCog._open_ticket(self.bot, interaction, topic=None)


class TicketControlView(nextcord.ui.View):
    def __init__(self, bot, ticket_id: int):
        super().__init__(timeout=None)
        self.bot = bot
        self.ticket_id = ticket_id

    @nextcord.ui.button(label="🔒 Close", style=nextcord.ButtonStyle.red, custom_id="ticket:close")
    async def close_ticket(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        await TicketsCog._close_ticket(self.bot, interaction, self.ticket_id)

    @nextcord.ui.button(label="📋 Transcript", style=nextcord.ButtonStyle.blurple, custom_id="ticket:transcript")
    async def transcript(self, button: nextcord.ui.Button, interaction: nextcord.Interaction):
        await TicketsCog._send_transcript(self.bot, interaction, self.ticket_id)


class TicketsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    async def _open_ticket(bot, interaction: nextcord.Interaction, topic: str = None):
        guild  = interaction.guild
        user   = interaction.user
        lang   = await bot.get_lang(guild.id)
        is_premium = guild.id in bot.premium_guilds or user.id in bot.premium_users

        # ── Check open ticket limit ───────────────────────────────────────────
        async with aiosqlite.connect(bot.db_path) as db:
            async with db.execute(
                "SELECT COUNT(*) FROM tickets WHERE guild_id=? AND user_id=? AND status='open'",
                (guild.id, user.id)
            ) as cur:
                count = (await cur.fetchone())[0]

            limit = MAX_TICKETS_PREMIUM if is_premium else MAX_TICKETS_FREE
            if count >= limit:
                await interaction.response.send_message(
                    embed=error_embed(t(lang, "ticket_limit", count=count))
                )
                return

            # ── Fetch guild config ────────────────────────────────────────────
            async with db.execute(
                "SELECT ticket_category_id, ticket_support_role_id FROM guild_config WHERE guild_id=?",
                (guild.id,)   # <-- tuple with comma — this was the bug
            ) as cur:
                row = await cur.fetchone()

        cat_id  = row[0] if row else None
        role_id = row[1] if row else None

        category = guild.get_channel(cat_id) if cat_id else None

        # ── Pre-flight permission check ───────────────────────────────────────
        # Use guild-level permissions — category overrides ARE included when
        # guild.me has an explicit allow override on the category.
        # Avoid re-checking at category level as it can miss explicit overrides.
        bot_guild_perms = guild.me.guild_permissions
        bot_cat_perms   = category.permissions_for(guild.me) if isinstance(category, nextcord.CategoryChannel) else None

        can_manage = (
            bot_guild_perms.manage_channels        # guild-level grant
            or bot_guild_perms.administrator       # admin bypasses everything
            or (bot_cat_perms is not None and bot_cat_perms.manage_channels)  # category override
        )
        if not can_manage:
            await interaction.response.send_message(
                embed=error_embed(
                    "I need **Manage Channels** permission"
                    + (f" on the **{category.name}** category." if category else " in this server.")
                )
            )
            return

        # ── Build permission overwrites ───────────────────────────────────────
        # Always explicitly set overwrites so the ticket is private regardless
        # of what the category inherits
        overwrites = {
            guild.default_role: nextcord.PermissionOverwrite(view_channel=False),
            user: nextcord.PermissionOverwrite(
                view_channel=True, send_messages=True,
                attach_files=True, embed_links=True, read_message_history=True
            ),
            guild.me: nextcord.PermissionOverwrite(
                view_channel=True, send_messages=True,
                manage_channels=True, manage_messages=True,
                read_message_history=True, embed_links=True
            ),
        }
        if role_id:
            role = guild.get_role(role_id)
            if role:
                overwrites[role] = nextcord.PermissionOverwrite(
                    view_channel=True, send_messages=True, read_message_history=True
                )

        # ── Create channel ────────────────────────────────────────────────────
        ticket_num = int(time.time()) % 100000
        safe_name  = "".join(c for c in user.name.lower() if c.isalnum() or c == "-")[:10]
        try:
            ch = await guild.create_text_channel(
                name=f"ticket-{safe_name}-{ticket_num}",
                category=category,
                overwrites=overwrites,
                topic=f"Support ticket for {user} | {topic or 'No topic'}",
                reason=f"Ticket opened by {user}",
            )
        except nextcord.Forbidden as e:
            await interaction.response.send_message(
                embed=error_embed(
                    f"Missing permissions to create the ticket channel.\n"
                    f"Make sure I have **Manage Channels**"
                    + (f" on the **{category.name}** category." if category else ".")
                )
            )
            return
        except Exception as e:
            await interaction.response.send_message(
                embed=error_embed(f"Failed to create channel: {e}")
            )
            return

        # ── Save to DB ────────────────────────────────────────────────────────
        async with aiosqlite.connect(bot.db_path) as db:
            cur = await db.execute(
                "INSERT INTO tickets (guild_id, channel_id, user_id, topic) VALUES (?,?,?,?)",
                (guild.id, ch.id, user.id, topic)
            )
            ticket_id = cur.lastrowid
            await db.commit()

        # ── Send ticket message ───────────────────────────────────────────────
        embed = nextcord.Embed(
            title=t(lang, "ticket_opened_title"),
            description=t(lang, "ticket_opened_desc",
                          user=user.mention,
                          topic=topic or t(lang, "not_specified")),
            color=0x57F287,
        )
        embed.set_footer(text=f"Ticket #{ticket_id}")
        view = TicketControlView(bot, ticket_id)
        mention = f"<@&{role_id}>" if role_id else ""
        await ch.send(content=f"{user.mention} {mention}".strip(), embed=embed, view=view)

        await interaction.response.send_message(
            embed=success_embed(t(lang, "ticket_created", channel=ch.mention))
        )

    @staticmethod
    async def _close_ticket(bot, interaction: nextcord.Interaction, ticket_id: int):
        lang = await bot.get_lang(interaction.guild_id)
        async with aiosqlite.connect(bot.db_path) as db:
            await db.execute(
                "UPDATE tickets SET status='closed', closed_at=? WHERE id=?",
                (now(), ticket_id)
            )
            await db.commit()
        embed = nextcord.Embed(
            description=t(lang, "ticket_closing", user=interaction.user.mention),
            color=0xFF4444,
        )
        await interaction.response.send_message(embed=embed)
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete(reason="Ticket closed")
        except Exception:
            pass

    @staticmethod
    async def _send_transcript(bot, interaction: nextcord.Interaction, ticket_id: int):
        lang = await bot.get_lang(interaction.guild_id)
        messages = []
        async for msg in interaction.channel.history(limit=300, oldest_first=True):
            if not msg.author.bot:
                messages.append(f"[{msg.created_at.strftime('%Y-%m-%d %H:%M')}] {msg.author}: {msg.content}")
        transcript = "\n".join(messages) or "No messages."
        import io
        file = nextcord.File(
            fp=io.BytesIO(transcript.encode()),
            filename=f"transcript-{ticket_id}.txt"
        )
        await interaction.response.send_message(
            embed=success_embed(t(lang, "transcript_ready")),
            file=file
        )

    # ── Slash commands ─────────────────────────────────────────────────────────

    @nextcord.slash_command(name="ticket", description="🎫 Ticket system")
    async def ticket(self, interaction: nextcord.Interaction):
        pass

    @ticket.subcommand(name="open", description="Open a support ticket")
    async def ticket_open(
        self,
        interaction: nextcord.Interaction,
        topic: str = SlashOption(description="What do you need help with?", required=False),
    ):
        await self._open_ticket(self.bot, interaction, topic)

    @ticket.subcommand(name="panel", description="Send a ticket creation panel (Admin)")
    async def ticket_panel(
        self,
        interaction: nextcord.Interaction,
        channel: nextcord.abc.GuildChannel = SlashOption(description="Channel to send panel in"),
        title: str = SlashOption(description="Panel title", required=False, default="🎫 Support Tickets"),
        description: str = SlashOption(description="Panel description", required=False),
    ):
        if not (interaction.user.guild_permissions.manage_channels or interaction.user.guild_permissions.manage_guild):
            lang = await self.bot.get_lang(interaction.guild_id)
            await interaction.response.send_message(embed=error_embed(t(lang, "no_permission")))
            return
        embed = nextcord.Embed(
            title=title,
            description=description or "Click the button below to open a support ticket!",
            color=0x57F287,
        )
        view = TicketCreateView(self.bot)
        await channel.send(embed=embed, view=view)
        await interaction.response.send_message(embed=success_embed(f"Panel sent to {channel.mention}"))

    @ticket.subcommand(name="setup", description="Configure the ticket system (Admin)")
    async def ticket_setup(
        self,
        interaction: nextcord.Interaction,
        category: nextcord.abc.GuildChannel = SlashOption(description="Category for ticket channels"),
        support_role: nextcord.Role = SlashOption(description="Support team role"),
        log_channel: nextcord.abc.GuildChannel = SlashOption(description="Log channel", required=False),
    ):
        if not (interaction.user.guild_permissions.manage_channels or interaction.user.guild_permissions.manage_guild):
            lang = await self.bot.get_lang(interaction.guild_id)
            await interaction.response.send_message(embed=error_embed(t(lang, "no_permission")))
            return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                """INSERT INTO guild_config (guild_id, ticket_category_id, ticket_support_role_id, ticket_log_channel_id)
                VALUES (?,?,?,?)
                ON CONFLICT(guild_id) DO UPDATE SET
                    ticket_category_id=excluded.ticket_category_id,
                    ticket_support_role_id=excluded.ticket_support_role_id,
                    ticket_log_channel_id=excluded.ticket_log_channel_id""",
                (interaction.guild_id, category.id, support_role.id, log_channel.id if log_channel else None)
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(
                f"✅ Ticket system configured!\n"
                f"Category: {category.mention}\n"
                f"Role: {support_role.mention}"
            )
        )

    @ticket.subcommand(name="list", description="List your open tickets")
    async def ticket_list(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT id, channel_id, topic, status, created_at FROM tickets "
                "WHERE guild_id=? AND user_id=? ORDER BY created_at DESC LIMIT 10",
                (interaction.guild_id, interaction.user.id)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            lang = await self.bot.get_lang(interaction.guild_id)
            await interaction.response.send_message(embed=info_embed("🎫 Tickets", t(lang, "no_tickets")))
            return
        desc = ""
        for tid, ch_id, topic, status, ts in rows:
            ch = interaction.guild.get_channel(ch_id)
            ch_str = ch.mention if ch else f"`deleted`"
            emoji = "🟢" if status == "open" else "🔴"
            desc += f"{emoji} **#{tid}** {ch_str} — {topic or 'No topic'}\n"
        await interaction.response.send_message(embed=info_embed("🎫 Your Tickets", desc))

    @ticket.subcommand(name="add_user", description="Add a user to this ticket")
    async def ticket_add_user(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="User to add"),
    ):
        await interaction.channel.set_permissions(
            user, read_messages=True, send_messages=True, attach_files=True
        )
        await interaction.response.send_message(embed=success_embed(f"{user.mention} added to ticket."))

    @ticket.subcommand(name="remove_user", description="Remove a user from this ticket")
    async def ticket_remove_user(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="User to remove"),
    ):
        await interaction.channel.set_permissions(user, overwrite=None)
        await interaction.response.send_message(embed=success_embed(f"{user.mention} removed from ticket."))


def setup(bot):
    bot.add_cog(TicketsCog(bot))
