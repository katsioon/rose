"""
Social commands for Rosé bot.
/social — hug, pat, kiss, poke, wave, highfive, cuddle, boop,
           bite, slap, cry, laugh, blush, sleep, dance, think,
           profile, rep, leaderboard
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
import datetime
from utils.helpers import success_embed, error_embed, info_embed

# ── GIF pools (reliable Tenor embed links by action) ──────────────────────────
GIFS = {
    "hug": [
        "https://media.tenor.com/sskRwbQ7xwUAAAAC/anime-hug.gif",
        "https://media.tenor.com/od_Hd5bzNGwAAAAC/hug-anime.gif",
        "https://media.tenor.com/6F5gDZNqY0QAAAAC/kanna-hug.gif",
        "https://media.tenor.com/GG3ShiZKkIkAAAAC/anime-hug-cute.gif",
        "https://media.tenor.com/WvTMHXeHsBoAAAAC/anime-hug.gif",
    ],
    "pat": [
        "https://media.tenor.com/O0jjuJXqq0oAAAAC/anime-head-pat.gif",
        "https://media.tenor.com/SoJlHimN14YAAAAC/headpat-anime.gif",
        "https://media.tenor.com/Y-ZTqZf3SJMAAAAC/anime-pat.gif",
        "https://media.tenor.com/GFmGHRrY9UsAAAAC/pat-headpat.gif",
        "https://media.tenor.com/i1UqOfUr2MUAAAAC/head-pat-anime.gif",
    ],
    "kiss": [
        "https://media.tenor.com/WTCBXSR5nfYAAAAC/anime-kiss.gif",
        "https://media.tenor.com/JFEMlFgEwF4AAAAC/kiss-anime.gif",
        "https://media.tenor.com/dJBKOFa0_SMAAAAC/anime-kiss-cute.gif",
        "https://media.tenor.com/eDuVNKQGRm8AAAAC/anime-kiss.gif",
    ],
    "poke": [
        "https://media.tenor.com/OerJH5pOLpcAAAAC/poke-anime.gif",
        "https://media.tenor.com/EgN1GLBER4IAAAAC/anime-poke.gif",
        "https://media.tenor.com/tLKSqSH8LdgAAAAC/yui-poke.gif",
        "https://media.tenor.com/q9KNzAYM4OMAAAAC/poke-finger.gif",
    ],
    "wave": [
        "https://media.tenor.com/K_RdLn8dNF4AAAAC/anime-wave.gif",
        "https://media.tenor.com/HhVpDiPkNR0AAAAC/wave-anime.gif",
        "https://media.tenor.com/FeT1HQFZ8LYAAAAC/anime-waving.gif",
        "https://media.tenor.com/Qq_6ZBqNhooAAAAC/anime-wave-bye.gif",
    ],
    "highfive": [
        "https://media.tenor.com/K8VN9TZ4KzkAAAAC/high-five-anime.gif",
        "https://media.tenor.com/cQtl4EM9KBAAAAAC/high-five.gif",
        "https://media.tenor.com/I_QDqE4K_AQAAAAC/anime-highfive.gif",
    ],
    "cuddle": [
        "https://media.tenor.com/vHIYOJFmZsgAAAAC/cuddle-anime.gif",
        "https://media.tenor.com/V2g_9e8sfuMAAAAC/anime-cuddle.gif",
        "https://media.tenor.com/3xJF2-HF9VsAAAAC/cuddle-hug.gif",
        "https://media.tenor.com/MhMiJjFHl_YAAAAC/snuggle-cuddle.gif",
    ],
    "boop": [
        "https://media.tenor.com/D3j7jRSF-ioAAAAC/boop-anime.gif",
        "https://media.tenor.com/5VXjYV9wHQ0AAAAC/boop-nose.gif",
        "https://media.tenor.com/4NpkP-OuFx8AAAAC/anime-boop.gif",
    ],
    "bite": [
        "https://media.tenor.com/9EvlDzrJhtsAAAAC/anime-bite.gif",
        "https://media.tenor.com/5_aFEA0JVp4AAAAC/bite-anime.gif",
        "https://media.tenor.com/eBqbLM2H5QQAAAAC/anime-bite-neck.gif",
    ],
    "slap": [
        "https://media.tenor.com/K_cHMCPyRegAAAAC/anime-slap.gif",
        "https://media.tenor.com/VGmFfWOjLb0AAAAC/slap-anime.gif",
        "https://media.tenor.com/UVoFKyaLl58AAAAC/anime-slap-hard.gif",
        "https://media.tenor.com/MHBl8XTvLlMAAAAC/slap-face.gif",
    ],
    "cry": [
        "https://media.tenor.com/KgaHe-9oJKcAAAAC/anime-cry.gif",
        "https://media.tenor.com/5kh2EsCPulkAAAAC/sad-anime-cry.gif",
        "https://media.tenor.com/5qflCVDlMekAAAAC/anime-tears-cry.gif",
        "https://media.tenor.com/VaZCxgCNLgkAAAAC/anime-cry-cute.gif",
    ],
    "laugh": [
        "https://media.tenor.com/EupF_fXNUBkAAAAC/anime-laugh.gif",
        "https://media.tenor.com/eJj2w0PLVPIAAAAC/laugh-anime.gif",
        "https://media.tenor.com/YKgMR7rVNroAAAAC/anime-haha-laugh.gif",
        "https://media.tenor.com/UGVa8hH-DpUAAAAC/laugh-haha.gif",
    ],
    "blush": [
        "https://media.tenor.com/xZ0WMxS_aLMAAAAC/anime-blush.gif",
        "https://media.tenor.com/hWYmJqrV9eAAAAAC/blush-anime.gif",
        "https://media.tenor.com/n_TxzVoA9CMAAAAC/anime-blush-cute.gif",
        "https://media.tenor.com/S7PV4S9G4OcAAAAC/blush-shy.gif",
    ],
    "sleep": [
        "https://media.tenor.com/fYkbpTgqrrcAAAAC/anime-sleep.gif",
        "https://media.tenor.com/pMAnAuHlYekAAAAC/sleep-anime.gif",
        "https://media.tenor.com/Gfm1F3Q0dIQAAAAC/anime-sleeping-cute.gif",
        "https://media.tenor.com/Qsmc_5dMSRIAAAAC/anime-sleep-night.gif",
    ],
    "dance": [
        "https://media.tenor.com/MolQqLkIWBUAAAAC/anime-dance.gif",
        "https://media.tenor.com/g_5H1KUACFMAAAAC/dance-anime.gif",
        "https://media.tenor.com/M95Wq44i04kAAAAC/anime-dance-cute.gif",
        "https://media.tenor.com/FeMz6r9YyTQAAAAC/anime-dancing.gif",
    ],
    "think": [
        "https://media.tenor.com/NRNYGJxJuiIAAAAC/thinking-anime.gif",
        "https://media.tenor.com/kqf1Bw9mWXsAAAAC/anime-think.gif",
        "https://media.tenor.com/H7MRDL1A2J0AAAAC/thinking-hmm.gif",
        "https://media.tenor.com/XElnfFuvjicAAAAC/anime-hmm.gif",
    ],
    "stare": [
        "https://media.tenor.com/kxBnS1XNWBQAAAAC/anime-stare.gif",
        "https://media.tenor.com/7_8DlZm3q0EAAAAC/stare-anime.gif",
        "https://media.tenor.com/DKmAE7H2TNMAAAAC/anime-stare-intensely.gif",
    ],
    "nom": [
        "https://media.tenor.com/7GjBIVKSI5kAAAAC/anime-eat.gif",
        "https://media.tenor.com/U0jxJpPJYBkAAAAC/nom-anime.gif",
        "https://media.tenor.com/R4lMcBhBGTYAAAAC/eating-anime.gif",
    ],
    "punch": [
        "https://media.tenor.com/xnvBSMwTJPQAAAAC/anime-punch.gif",
        "https://media.tenor.com/7FqdJww_lPUAAAAC/punch-anime.gif",
        "https://media.tenor.com/KlIjCJJBHaYAAAAC/anime-punch-hard.gif",
    ],
}

# ── Action messages ────────────────────────────────────────────────────────────
MESSAGES = {
    "hug":      ["{a} gives {b} a warm hug! 🤗", "{a} wraps their arms around {b}! 💕", "{a} hugs {b} tightly! 🌸"],
    "pat":      ["{a} gently pats {b} on the head! 👋", "{a} gives {b} a comforting pat! 🌸", "{a} pats {b}! ✨"],
    "kiss":     ["{a} kisses {b}! 💋", "{a} gives {b} a sweet kiss! 😘", "{a} plants a kiss on {b}! 💕"],
    "poke":     ["{a} pokes {b}! 👉", "{a} gives {b} a little poke! 😄", "{a} couldn't resist poking {b}!"],
    "wave":     ["{a} waves at {b}! 👋", "{a} gives {b} a friendly wave! 🌸", "Hey {b}, {a} is waving at you!"],
    "highfive": ["{a} high fives {b}! 🙌", "{a} and {b} share a high five! ✋", "High five! {a} and {b}! 🙌"],
    "cuddle":   ["{a} cuddles up with {b}! 🥰", "{a} and {b} cuddle together! 💕", "{a} snuggles with {b}! 🌸"],
    "boop":     ["{a} boops {b}'s nose! 👉🐽", "{a} gives {b} a little boop! 🌸", "Boop! {a} got {b}!"],
    "bite":     ["{a} bites {b}! 😬", "{a} takes a nibble of {b}! 🦷", "{a} chomps {b}! Ouch!"],
    "slap":     ["{a} slaps {b}! 💥", "{a} gives {b} a big slap! 😤", "{a} slapped {b} into next week!"],
    "cry":      ["{a} is crying... someone comfort them! 😭", "{a} bursts into tears! 💧", "{a} is sobbing! 😢"],
    "laugh":    ["{a} is dying of laughter! 😂", "{a} can't stop laughing! 🤣", "{a} is absolutely losing it! 😂"],
    "blush":    ["{a} is blushing! 😳", "{a} turns bright red! 🌸", "{a} is so flustered! 😊"],
    "sleep":    ["{a} has fallen asleep... zzz 💤", "{a} is out cold! 😴", "{a} drifts off to dreamland 🌙"],
    "dance":    ["{a} is breaking it down! 💃", "{a} starts dancing! 🕺", "{a} busts some moves! ✨"],
    "think":    ["{a} is deep in thought... 🤔", "{a} ponders the mysteries of life 💭", "{a} hmm..."],
    "stare":    ["{a} stares intensely at {b}... 👀", "{a} won't stop staring at {b}!", "{a} locks eyes with {b} 👁️"],
    "nom":      ["{a} is happily nom nom nomming! 😋", "{a} eats with pure joy! 🍽️", "{a} goes full nom mode! 🥢"],
    "punch":    ["{a} punches {b}! POW! 💥", "{a} gives {b} a solid punch! 👊", "{a} bonks {b}! 💢"],
}

# Self-action (no target needed)
SELF_ACTIONS = {"cry", "laugh", "blush", "sleep", "dance", "think", "nom"}
# Actions that need a target
TARGET_ACTIONS = {"hug","pat","kiss","poke","wave","highfive","cuddle","boop","bite","slap","stare","punch"}


class SocialCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _send_action(
        self,
        interaction: nextcord.Interaction,
        action: str,
        target: nextcord.Member = None,
        color: int = 0xFF91A4,
    ):
        a = interaction.user.display_name
        b = target.display_name if target else None

        # Pick message
        msg_template = random.choice(MESSAGES[action])
        if b:
            msg = msg_template.format(a=f"**{a}**", b=f"**{b}**")
        else:
            msg = msg_template.format(a=f"**{a}**")

        gif = random.choice(GIFS[action])
        embed = nextcord.Embed(description=msg, color=color)
        embed.set_image(url=gif)
        embed.set_footer(text=f"🌸 /social {action}")
        await interaction.response.send_message(embed=embed)

        # Track stats for specific actions
        if action in ("hug", "pat", "slap") and target:
            try:
                async with aiosqlite.connect(self.bot.db_path) as db:
                    await db.execute(
                        "INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING",
                        (interaction.user.id,)
                    )
                    await db.execute(
                        "INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING",
                        (target.id,)
                    )
                    await db.execute(
                        f"UPDATE social_profiles SET {action}s_given={action}s_given+1 WHERE user_id=?",
                        (interaction.user.id,)
                    )
                    await db.execute(
                        f"UPDATE social_profiles SET {action}s_received={action}s_received+1 WHERE user_id=?",
                        (target.id,)
                    )
                    await db.commit()
            except Exception:
                pass

    # ── /social group ──────────────────────────────────────────────────────────

    @nextcord.slash_command(name="social", description="🌸 Social interaction commands")
    async def social(self, interaction: nextcord.Interaction):
        pass

    # ── Affectionate ───────────────────────────────────────────────────────────

    @social.subcommand(name="hug", description="Give someone a hug 🤗")
    async def hug(self, interaction: nextcord.Interaction,
                  user: nextcord.Member = SlashOption(description="Who to hug")):
        await self._send_action(interaction, "hug", user, 0xFF91A4)

    @social.subcommand(name="pat", description="Pat someone on the head 👋")
    async def pat(self, interaction: nextcord.Interaction,
                  user: nextcord.Member = SlashOption(description="Who to pat")):
        await self._send_action(interaction, "pat", user, 0xFFD700)

    @social.subcommand(name="kiss", description="Kiss someone 💋")
    async def kiss(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to kiss")):
        await self._send_action(interaction, "kiss", user, 0xFF6B9D)

    @social.subcommand(name="cuddle", description="Cuddle with someone 🥰")
    async def cuddle(self, interaction: nextcord.Interaction,
                     user: nextcord.Member = SlashOption(description="Who to cuddle")):
        await self._send_action(interaction, "cuddle", user, 0xFF91A4)

    @social.subcommand(name="boop", description="Boop someone's nose 👉🐽")
    async def boop(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to boop")):
        await self._send_action(interaction, "boop", user, 0xFFD700)

    # ── Playful ────────────────────────────────────────────────────────────────

    @social.subcommand(name="poke", description="Poke someone 👉")
    async def poke(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to poke")):
        await self._send_action(interaction, "poke", user, 0xF4A261)

    @social.subcommand(name="wave", description="Wave at someone 👋")
    async def wave(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to wave at")):
        await self._send_action(interaction, "wave", user, 0x57F287)

    @social.subcommand(name="highfive", description="High five someone 🙌")
    async def highfive(self, interaction: nextcord.Interaction,
                       user: nextcord.Member = SlashOption(description="Who to high five")):
        await self._send_action(interaction, "highfive", user, 0x57F287)

    @social.subcommand(name="stare", description="Stare at someone intensely 👀")
    async def stare(self, interaction: nextcord.Interaction,
                    user: nextcord.Member = SlashOption(description="Who to stare at")):
        await self._send_action(interaction, "stare", user, 0x5865F2)

    @social.subcommand(name="bite", description="Bite someone 😬")
    async def bite(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to bite")):
        await self._send_action(interaction, "bite", user, 0xFF4444)

    @social.subcommand(name="slap", description="Slap someone 💥")
    async def slap(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to slap")):
        await self._send_action(interaction, "slap", user, 0xFF4444)

    @social.subcommand(name="punch", description="Punch someone 👊")
    async def punch(self, interaction: nextcord.Interaction,
                    user: nextcord.Member = SlashOption(description="Who to punch")):
        await self._send_action(interaction, "punch", user, 0xFF4444)

    @social.subcommand(name="nom", description="Nom at someone 😋")
    async def nom(self, interaction: nextcord.Interaction,
                  user: nextcord.Member = SlashOption(description="Who to nom", required=False)):
        await self._send_action(interaction, "nom", user, 0xFFD700)

    # ── Emote (self) ───────────────────────────────────────────────────────────

    @social.subcommand(name="cry", description="Cry 😭")
    async def cry(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "cry", color=0x5865F2)

    @social.subcommand(name="laugh", description="Laugh 😂")
    async def laugh(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "laugh", color=0xFFD700)

    @social.subcommand(name="blush", description="Blush 😳")
    async def blush(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "blush", color=0xFF91A4)

    @social.subcommand(name="sleep", description="Fall asleep 💤")
    async def sleep(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "sleep", color=0x9B59B6)

    @social.subcommand(name="dance", description="Dance! 💃")
    async def dance(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "dance", color=0xFF6B9D)

    @social.subcommand(name="think", description="Think deeply 🤔")
    async def think(self, interaction: nextcord.Interaction):
        await self._send_action(interaction, "think", color=0x5865F2)

    # ── Reputation system ──────────────────────────────────────────────────────

    @social.subcommand(name="rep", description="Give someone a reputation point ⭐")
    async def rep(self, interaction: nextcord.Interaction,
                  user: nextcord.Member = SlashOption(description="Who to rep")):
        if user.id == interaction.user.id:
            await interaction.response.send_message(
                embed=error_embed("You can't rep yourself!")
            )
            return

        async with aiosqlite.connect(self.bot.db_path) as db:
            # Check cooldown — 1 rep per user per 12 hours
            async with db.execute(
                "SELECT last_rep_given FROM social_profiles WHERE user_id=?",
                (interaction.user.id,)
            ) as cur:
                row = await cur.fetchone()

            import time
            now = int(time.time())
            last_given = row[0] if row and row[0] else 0
            cooldown   = 43200  # 12 hours

            if now - last_given < cooldown:
                remaining = cooldown - (now - last_given)
                h, m = divmod(remaining // 60, 60)
                await interaction.response.send_message(
                    embed=error_embed(f"You can rep someone again in **{h}h {m}m**!")
                )
                return

            # Give rep
            await db.execute(
                "INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING",
                (user.id,)
            )
            await db.execute(
                "UPDATE social_profiles SET rep=rep+1 WHERE user_id=?",
                (user.id,)
            )
            await db.execute(
                "INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING",
                (interaction.user.id,)
            )
            await db.execute(
                "UPDATE social_profiles SET last_rep_given=? WHERE user_id=?",
                (now, interaction.user.id)
            )
            await db.commit()

            async with db.execute(
                "SELECT rep FROM social_profiles WHERE user_id=?", (user.id,)
            ) as cur:
                new_rep = (await cur.fetchone())[0]

        embed = nextcord.Embed(
            description=f"⭐ **{interaction.user.display_name}** gave a rep to **{user.display_name}**!\nThey now have **{new_rep}** rep.",
            color=0xFFD700,
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    # ── Social profile ─────────────────────────────────────────────────────────

    @social.subcommand(name="profile", description="View a user's social profile 🌸")
    async def profile(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(description="Whose profile", required=False)):
        target = user or interaction.user
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO social_profiles (user_id) VALUES (?) ON CONFLICT(user_id) DO NOTHING",
                (target.id,)
            )
            await db.commit()
            async with db.execute(
                "SELECT rep, hugs_given, hugs_received, pats_given, pats_received, "
                "slaps_given, slaps_received, bio FROM social_profiles WHERE user_id=?",
                (target.id,)
            ) as cur:
                row = await cur.fetchone()

        rep, hg, hr, pg, pr, sg, sr, bio = row if row else (0,0,0,0,0,0,0,None)

        is_premium = target.id in self.bot.premium_users or interaction.guild_id in self.bot.premium_guilds
        joined = target.joined_at.strftime("%b %d, %Y") if target.joined_at else "Unknown"

        embed = nextcord.Embed(
            title=f"🌸 {target.display_name}'s Profile",
            description=bio or "*No bio set — use `/social setbio` to add one!*",
            color=0xFF91A4,
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="⭐ Rep",         value=str(rep),     inline=True)
        embed.add_field(name="📅 Joined",      value=joined,       inline=True)
        embed.add_field(name="🏅 Premium",     value="⭐ Yes" if is_premium else "No", inline=True)
        embed.add_field(name="🤗 Hugs Given",  value=str(hg),      inline=True)
        embed.add_field(name="💕 Hugs Received",value=str(hr),     inline=True)
        embed.add_field(name="👋 Pats Given",  value=str(pg),      inline=True)
        embed.add_field(name="💢 Slaps Given", value=str(sg),      inline=True)
        await interaction.response.send_message(embed=embed)

    @social.subcommand(name="setbio", description="Set your profile bio 📝")
    async def setbio(self, interaction: nextcord.Interaction,
                     bio: str = SlashOption(description="Your bio (max 150 chars)")):
        bio = bio[:150]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO social_profiles (user_id, bio) VALUES (?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET bio=excluded.bio",
                (interaction.user.id, bio)
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Bio updated! 🌸\n*\"{bio}\"*")
        )

    @social.subcommand(name="leaderboard", description="Top users by reputation ⭐")
    async def leaderboard(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT user_id, rep FROM social_profiles ORDER BY rep DESC LIMIT 10"
            ) as cur:
                rows = await cur.fetchall()

        if not rows:
            await interaction.response.send_message(
                embed=info_embed("⭐ Rep Leaderboard", "Nobody has rep yet! Use `/social rep` to give some.")
            )
            return

        medals = ["🥇","🥈","🥉"] + ["🏅"]*7
        lines  = []
        for i, (uid, rep) in enumerate(rows):
            member = interaction.guild.get_member(uid)
            name   = member.display_name if member else f"User {uid}"
            lines.append(f"{medals[i]} **{name}** — {rep} rep")

        embed = nextcord.Embed(
            title="⭐ Rep Leaderboard",
            description="\n".join(lines),
            color=0xFFD700,
        )
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(SocialCog(bot))
