"""
Global bot shop for Rosé bot.
Players spend coins on: role colors, profile badges, XP boosts, pet accessories,
custom rank card colors, name effects, economy bonuses.
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
from utils.helpers import error_embed, success_embed, info_embed

SHOP_ITEMS = {
    # id: {name, desc, price, category, type}
    "xp_boost_1d":   {"name":"XP Boost (1 day)",      "desc":"2× XP for 24 hours",                "price":500,  "cat":"boosts",   "emoji":"⚡"},
    "xp_boost_7d":   {"name":"XP Boost (7 days)",     "desc":"2× XP for 7 days",                  "price":2500, "cat":"boosts",   "emoji":"⚡"},
    "coin_boost_1d": {"name":"Coin Boost (1 day)",    "desc":"2× coins from /work and /daily",     "price":400,  "cat":"boosts",   "emoji":"🪙"},
    "badge_rose":    {"name":"Rose Badge 🌸",          "desc":"Shown on your /social profile",      "price":200,  "cat":"badges",   "emoji":"🌸"},
    "badge_star":    {"name":"Star Badge ⭐",           "desc":"Shown on your /social profile",      "price":200,  "cat":"badges",   "emoji":"⭐"},
    "badge_crown":   {"name":"Crown Badge 👑",         "desc":"Shown on your /social profile",      "price":500,  "cat":"badges",   "emoji":"👑"},
    "badge_fire":    {"name":"Fire Badge 🔥",          "desc":"Shown on your /social profile",      "price":350,  "cat":"badges",   "emoji":"🔥"},
    "card_pack_3":   {"name":"Card Pack (3 cards)",   "desc":"3 random card draws instantly",      "price":120,  "cat":"cards",    "emoji":"🃏"},
    "card_pack_10":  {"name":"Card Pack (10 cards)",  "desc":"10 random card draws instantly",     "price":350,  "cat":"cards",    "emoji":"🃏"},
    "pet_treat":     {"name":"Pet Treat",              "desc":"Instantly restore pet happiness",    "price":80,   "cat":"pets",     "emoji":"🦴"},
    "pet_energy":    {"name":"Pet Energy Drink",       "desc":"Instantly restore pet energy",       "price":80,   "cat":"pets",     "emoji":"⚡"},
    "color_gold":    {"name":"Gold Rank Color",        "desc":"Sets your rank card to gold",        "price":300,  "cat":"cosmetic", "emoji":"🥇"},
    "color_purple":  {"name":"Purple Rank Color",      "desc":"Sets your rank card to purple",      "price":300,  "cat":"cosmetic", "emoji":"💜"},
    "color_blue":    {"name":"Blue Rank Color",        "desc":"Sets your rank card to blue",        "price":300,  "cat":"cosmetic", "emoji":"💙"},
    "fish_bait":     {"name":"Super Bait",             "desc":"Next 5 casts have +20% rare chance", "price":150,  "cat":"games",    "emoji":"🎣"},
    "pickaxe_plus":  {"name":"Enchanted Pickaxe",      "desc":"Next 10 digs find +1 bonus ore",     "price":200,  "cat":"games",    "emoji":"⛏️"},
}

CATEGORIES = ["boosts","badges","cards","pets","cosmetic","games"]

class ShopCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _get_coins(self, uid):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO economy (user_id) VALUES (?)", (uid,))
            await db.commit()
            async with db.execute("SELECT coins FROM economy WHERE user_id=?", (uid,)) as cur:
                row = await cur.fetchone()
        return row[0] if row else 0

    async def _spend(self, uid, amount):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (amount,uid))
            await db.execute("INSERT INTO shop_purchases (user_id,item_id,purchased_at) VALUES (?,?,strftime('%s','now'))", (uid,"_"))
            await db.commit()

    @nextcord.slash_command(name="shop", description="🏪 Global Bot Shop — spend your coins!")
    async def shop(self, interaction: nextcord.Interaction):
        pass

    @shop.subcommand(name="browse", description="Browse the shop by category")
    async def browse(self, interaction: nextcord.Interaction,
                     category: str = SlashOption(description="Category", choices={c.title():c for c in CATEGORIES}, required=False)):
        items = {k:v for k,v in SHOP_ITEMS.items() if not category or v["cat"]==category}
        embed = nextcord.Embed(
            title=f"🏪 Bot Shop{f' — {category.title()}' if category else ''}",
            color=0xFFD700,
        )
        by_cat: dict = {}
        for k,v in items.items():
            by_cat.setdefault(v["cat"],[]).append((k,v))
        for cat, entries in by_cat.items():
            lines = [f"{v['emoji']} **{v['name']}** — 🪙{v['price']}\n  *{v['desc']}*" for _,v in entries]
            embed.add_field(name=cat.title(), value="\n".join(lines), inline=False)
        embed.set_footer(text="Buy with /shop buy <item_id>  |  Check balance with /economy balance")
        await interaction.response.send_message(embed=embed)

    @shop.subcommand(name="buy", description="Buy an item from the shop")
    async def buy(self, interaction: nextcord.Interaction,
                  item_id: str = SlashOption(description="Item ID (from /shop browse)", choices={v["name"]:k for k,v in SHOP_ITEMS.items()})):
        item = SHOP_ITEMS.get(item_id)
        if not item:
            await interaction.response.send_message(embed=error_embed("Invalid item.")); return
        uid = interaction.user.id
        coins = await self._get_coins(uid)
        if coins < item["price"]:
            await interaction.response.send_message(embed=error_embed(f"Need 🪙{item['price']}, you have 🪙{coins}.")); return
        # Apply item effect
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (item["price"],uid))
            await db.execute("INSERT INTO shop_purchases (user_id,item_id,purchased_at) VALUES (?,?,strftime('%s','now'))", (uid,item_id))
            # Apply immediate effects
            if item_id == "badge_rose":  await db.execute("UPDATE social_profiles SET badges=COALESCE(badges,'')||'🌸' WHERE user_id=?", (uid,))
            elif item_id == "badge_star":  await db.execute("UPDATE social_profiles SET badges=COALESCE(badges,'')||'⭐' WHERE user_id=?", (uid,))
            elif item_id == "badge_crown": await db.execute("UPDATE social_profiles SET badges=COALESCE(badges,'')||'👑' WHERE user_id=?", (uid,))
            elif item_id == "badge_fire":  await db.execute("UPDATE social_profiles SET badges=COALESCE(badges,'')||'🔥' WHERE user_id=?", (uid,))
            elif item_id == "color_gold":
                await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (interaction.guild_id,uid))
                await db.execute("UPDATE levels SET rank_color='gold' WHERE user_id=?", (uid,))
            elif item_id == "color_purple":
                await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (interaction.guild_id,uid))
                await db.execute("UPDATE levels SET rank_color='purple' WHERE user_id=?", (uid,))
            elif item_id == "color_blue":
                await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (interaction.guild_id,uid))
                await db.execute("UPDATE levels SET rank_color='blue' WHERE user_id=?", (uid,))
            await db.commit()
        # Card packs
        if item_id in ("card_pack_3","card_pack_10"):
            count = 3 if item_id=="card_pack_3" else 10
            from cogs.rpg import CARDS, CARD_RARITIES, _draw_rarity
            drawn = []
            async with aiosqlite.connect(self.bot.db_path) as db:
                for _ in range(count):
                    rar = _draw_rarity()
                    pool = [c for c in CARDS if c[1]==rar]
                    card = random.choice(pool) if pool else CARDS[-1]
                    cname = card[0]
                    drawn.append(f"{CARD_RARITIES[rar][1]} {card[2]} **{cname}**")
                    await db.execute("INSERT INTO card_collection (user_id,card_name,rarity,count) VALUES (?,?,?,1) ON CONFLICT(user_id,card_name) DO UPDATE SET count=count+1", (uid,cname,rar))
                await db.commit()
            embed = nextcord.Embed(title=f"🃏 Opened {count} Cards!", description="\n".join(drawn), color=0x9B59B6)
            await interaction.response.send_message(embed=embed); return
        await interaction.response.send_message(embed=success_embed(
            f"Bought {item['emoji']} **{item['name']}**!\n*{item['desc']}*"
        ))

    @shop.subcommand(name="inventory", description="View your purchased items")
    async def inventory(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT item_id,COUNT(*) as qty FROM shop_purchases WHERE user_id=? GROUP BY item_id ORDER BY purchased_at DESC",
                (interaction.user.id,)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🎒 Shop Inventory","Nothing yet! Browse with `/shop browse`.")); return
        lines = []
        for item_id,qty in rows:
            item = SHOP_ITEMS.get(item_id)
            if item:
                lines.append(f"{item['emoji']} **{item['name']}** ×{qty}")
        embed = nextcord.Embed(title="🎒 Your Shop Items", description="\n".join(lines) or "Empty!", color=0xFFD700)
        await interaction.response.send_message(embed=embed)

import random

def setup(bot):
    bot.add_cog(ShopCog(bot))
