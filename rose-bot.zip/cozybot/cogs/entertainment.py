import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
import time
from utils.helpers import success_embed, error_embed, info_embed, premium_embed, now, human_time

WORK_COOLDOWN = 3600       # 1 hour
DAILY_COOLDOWN = 86400     # 24 hours
WORK_MIN, WORK_MAX = 50, 200
DAILY_AMOUNT = 500
SLOTS_COST = 20

SLOTS_SYMBOLS = ["🍒", "🍋", "🍊", "🍇", "⭐", "💎"]
SLOTS_WEIGHTS = [30, 25, 20, 15, 7, 3]

def slots_spin():
    return random.choices(SLOTS_SYMBOLS, weights=SLOTS_WEIGHTS, k=3)

def slots_payout(symbols, bet):
    s = set(symbols)
    if len(s) == 1:
        symbol = symbols[0]
        mult = {"💎": 50, "⭐": 20, "🍇": 10, "🍊": 5, "🍋": 3, "🍒": 2}
        return bet * mult.get(symbol, 2), "JACKPOT! 🎉"
    elif len(s) == 2:
        return bet // 2, "Two of a kind!"
    return -bet, "No match."

class EntertainmentCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _ensure_economy(self, user_id: int):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO economy (user_id) VALUES (?)", (user_id))
            await db.commit()

    async def _get_balance(self, user_id: int) -> tuple:
        await self._ensure_economy(user_id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT coins, bank FROM economy WHERE user_id=?", (user_id)) as cur:
                return await cur.fetchone()

    async def _add_coins(self, user_id: int, amount: int):
        await self._ensure_economy(user_id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (amount, user_id))
            await db.commit()

    # ── /fun ──────────────────────────────────────────────────────────────────

    @nextcord.slash_command(name="fun", description="🎮 Fun commands")
    async def fun(self, interaction: nextcord.Interaction): pass

    @fun.subcommand(name="8ball", description="Ask the magic 8-ball a question")
    async def eightball(self, interaction: nextcord.Interaction, question: str = SlashOption(description="Your question")):
        responses = [
            "It is certain.", "It is decidedly so.", "Without a doubt.", "Yes, definitely.",
            "You may rely on it.", "As I see it, yes.", "Most likely.", "Outlook good.",
            "Yes.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.",
            "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again.",
            "Don't count on it.", "My reply is no.", "My sources say no.",
            "Outlook not so good.", "Very doubtful.",
        ]
        answer = random.choice(responses)
        embed = nextcord.Embed(color=0x5865F2)
        embed.add_field(name="❓ Question", value=question, inline=False)
        embed.add_field(name="🎱 Answer", value=f"**{answer}**", inline=False)
        await interaction.response.send_message(embed=embed)

    @fun.subcommand(name="coinflip", description="Flip a coin")
    async def coinflip(self, interaction: nextcord.Interaction,
                       bet: str = SlashOption(description="heads or tails", choices=["heads", "tails"], required=False)):
        result = random.choice(["heads", "tails"])
        emoji = "🪙"
        if bet:
            won = bet == result
            desc = f"The coin landed on **{result}** {emoji}\nYou {'won' if won else 'lost'}!"
        else:
            desc = f"The coin landed on **{result}** {emoji}"
        await interaction.response.send_message(embed=info_embed("Coin Flip", desc))

    @fun.subcommand(name="roll", description="Roll dice")
    async def roll(self, interaction: nextcord.Interaction,
                   dice: str = SlashOption(description="Format: NdN e.g. 2d6", default="1d6")):
        try:
            n, d = map(int, dice.lower().split("d"))
            assert 1 <= n <= 20 and 2 <= d <= 1000
        except:
            await interaction.response.send_message(embed=error_embed("Invalid dice format. Use NdN (e.g. 2d6)"))
            return
        rolls = [random.randint(1, d) for _ in range(n)]
        embed = nextcord.Embed(
            title=f"🎲 Rolling {dice}",
            description=f"Rolls: {', '.join(map(str, rolls))}\n**Total: {sum(rolls)}**",
            color=0xF4A261
        )
        await interaction.response.send_message(embed=embed)

    @fun.subcommand(name="trivia", description="Answer a trivia question")
    async def trivia(self, interaction: nextcord.Interaction):
        questions = [
            ("What is the capital of Japan?", "Tokyo", ["London", "Beijing", "Tokyo", "Seoul"]),
            ("How many planets are in our solar system?", "8", ["7", "8", "9", "10"]),
            ("What is 7 × 8?", "56", ["48", "56", "64", "72"]),
            ("Which element has symbol 'Au'?", "Gold", ["Silver", "Gold", "Copper", "Iron"]),
            ("What year did WW2 end?", "1945", ["1944", "1945", "1946", "1947"]),
            ("What is the largest ocean?", "Pacific", ["Atlantic", "Indian", "Pacific", "Arctic"]),
            ("How many sides does a hexagon have?", "6", ["5", "6", "7", "8"]),
        ]
        q, answer, options = random.choice(questions)
        shuffled = options[:]
        random.shuffle(shuffled)

        view = TriviaView(answer, interaction.user.id, self.bot)
        embed = nextcord.Embed(title="🧠 Trivia Time!", description=f"**{q}**", color=0x5865F2)
        for i, opt in enumerate(shuffled):
            view.add_item(TriviaButton(opt, answer, i))
        await interaction.response.send_message(embed=embed, view=view)

    @fun.subcommand(name="rps", description="Rock, Paper, Scissors")
    async def rps(self, interaction: nextcord.Interaction,
                  choice: str = SlashOption(description="Your choice", choices=["rock", "paper", "scissors"])):
        bot_choice = random.choice(["rock", "paper", "scissors"])
        emojis = {"rock": "🪨", "paper": "📄", "scissors": "✂️"}
        beats = {"rock": "scissors", "paper": "rock", "scissors": "paper"}
        if choice == bot_choice:
            result, color = "It's a tie! 🤝", 0x808080
        elif beats[choice] == bot_choice:
            result, color = "You win! 🎉", 0x57F287
        else:
            result, color = "I win! 😏", 0xFF4444
        embed = nextcord.Embed(
            title="Rock Paper Scissors",
            description=f"You: {emojis[choice]} vs Me: {emojis[bot_choice]}\n\n**{result}**",
            color=color
        )
        await interaction.response.send_message(embed=embed)

    @fun.subcommand(name="joke", description="Get a random joke")
    async def joke(self, interaction: nextcord.Interaction):
        jokes = [
            ("Why don't scientists trust atoms?", "Because they make up everything!"),
            ("Why did the scarecrow win an award?", "Because he was outstanding in his field!"),
            ("Why don't eggs tell jokes?", "They'd crack each other up."),
            ("What do you call a fake noodle?", "An impasta!"),
            ("Why did the math book look so sad?", "Because it had too many problems."),
            ("What do you call cheese that isn't yours?", "Nacho cheese!"),
            ("Why can't you give Elsa a balloon?", "Because she'll let it go."),
        ]
        setup, punchline = random.choice(jokes)
        embed = nextcord.Embed(color=0xF4A261)
        embed.add_field(name="😄", value=setup, inline=False)
        embed.add_field(name="💬", value=f"||{punchline}||", inline=False)
        await interaction.response.send_message(embed=embed)

    @fun.subcommand(name="fact", description="Random interesting fact")
    async def fact(self, interaction: nextcord.Interaction):
        facts = [
            "Honey never spoils. Archaeologists have found 3000-year-old honey in Egyptian tombs.",
            "A group of flamingos is called a 'flamboyance'.",
            "Octopuses have three hearts, blue blood, and nine brains.",
            "The shortest war in history was between Britain and Zanzibar in 1896 — lasting 38 minutes.",
            "Bananas are berries, but strawberries aren't.",
            "A day on Venus is longer than a year on Venus.",
            "The Eiffel Tower can grow by 6 inches in summer due to thermal expansion.",
            "There are more possible chess games than atoms in the observable universe.",
        ]
        await interaction.response.send_message(embed=info_embed("🔍 Random Fact", random.choice(facts), 0x5865F2))

    # ── /economy ──────────────────────────────────────────────────────────────

    @nextcord.slash_command(name="economy", description="💰 Economy commands")
    async def economy(self, interaction: nextcord.Interaction): pass

    @economy.subcommand(name="balance", description="Check your coin balance")
    async def balance(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(description="Check another user", required=False)):
        target = user or interaction.user
        coins, bank = await self._get_balance(target.id)
        embed = nextcord.Embed(title=f"💰 {target.display_name}'s Balance", color=0xFFD700)
        embed.add_field(name="Wallet", value=f"🪙 {coins:,}")
        embed.add_field(name="Bank", value=f"🏦 {bank:,}")
        embed.add_field(name="Total", value=f"💎 {coins+bank:,}")
        await interaction.response.send_message(embed=embed)

    @economy.subcommand(name="daily", description="Claim your daily coins")
    async def daily(self, interaction: nextcord.Interaction):
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT last_daily FROM economy WHERE user_id=?", (interaction.user.id)) as cur:
                row = await cur.fetchone()
            last = row[0] if row else 0
            remaining = DAILY_COOLDOWN - (now() - last)
            if remaining > 0:
                await interaction.response.send_message(
                    embed=error_embed(f"Daily already claimed! Come back in **{human_time(remaining)}**"))
                return
            bonus = DAILY_AMOUNT * 2 if interaction.user.id in self.bot.premium_users else DAILY_AMOUNT
            await db.execute("UPDATE economy SET coins=coins+?, last_daily=? WHERE user_id=?",
                             (bonus, now(), interaction.user.id))
            await db.commit()
        embed = nextcord.Embed(
            title="☀️ Daily Reward!",
            description=f"You claimed **🪙 {bonus:,}** coins!{'  ⭐ Premium bonus!' if bonus > DAILY_AMOUNT else ''}",
            color=0xFFD700
        )
        await interaction.response.send_message(embed=embed)

    @economy.subcommand(name="work", description="Work to earn coins")
    async def work(self, interaction: nextcord.Interaction):
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT last_work FROM economy WHERE user_id=?", (interaction.user.id)) as cur:
                row = await cur.fetchone()
            last = row[0] if row else 0
            remaining = WORK_COOLDOWN - (now() - last)
            if remaining > 0:
                await interaction.response.send_message(
                    embed=error_embed(f"You're tired! Rest for **{human_time(remaining)}**"))
                return
            amount = random.randint(WORK_MIN, WORK_MAX)
            if interaction.user.id in self.bot.premium_users:
                amount = int(amount * 1.5)
            jobs = ["coded a website", "delivered pizzas", "walked dogs", "tutored a student",
                    "fixed computers", "wrote a blog post", "designed a logo", "drove for Uber"]
            job = random.choice(jobs)
            await db.execute("UPDATE economy SET coins=coins+?, last_work=? WHERE user_id=?",
                             (amount, now(), interaction.user.id))
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"You {job} and earned **🪙 {amount:,}** coins!")
        )

    @economy.subcommand(name="slots", description="Play the slot machine")
    async def slots(self, interaction: nextcord.Interaction,
                    bet: int = SlashOption(description="How many coins to bet", min_value=10)):
        coins, _ = await self._get_balance(interaction.user.id)
        if coins < bet:
            await interaction.response.send_message(
                embed=error_embed(f"Not enough coins! You have 🪙 {coins:,}")
            )
            return
        reels = slots_spin()
        winnings, msg = slots_payout(reels, bet)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (winnings, interaction.user.id))
            await db.commit()
        color = 0xFFD700 if winnings > 0 else 0xFF4444
        embed = nextcord.Embed(
            title="🎰 Slot Machine",
            description=f"| {' | '.join(reels)} |\n\n**{msg}**\n"
                        f"{'Won' if winnings > 0 else 'Lost'}: 🪙 {abs(winnings):,}",
            color=color
        )
        new_bal = coins + winnings
        embed.set_footer(text=f"Balance: 🪙 {new_bal:,}")
        await interaction.response.send_message(embed=embed)

    @economy.subcommand(name="give", description="Give coins to another user")
    async def give(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(description="Who to give to"),
                   amount: int = SlashOption(description="Amount", min_value=1)):
        if user.id == interaction.user.id:
            await interaction.response.send_message(embed=error_embed("You can't give coins to yourself!"))
            return
        coins, _ = await self._get_balance(interaction.user.id)
        if coins < amount:
            await interaction.response.send_message(embed=error_embed("Not enough coins!"))
            return
        await self._ensure_economy(user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (amount, interaction.user.id))
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (amount, user.id))
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"{interaction.user.mention} gave **🪙 {amount:,}** coins to {user.mention}!")
        )

    @economy.subcommand(name="leaderboard", description="Top 10 richest users")
    async def leaderboard(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT user_id, coins+bank as total FROM economy ORDER BY total DESC LIMIT 10"
            ) as cur:
                rows = await cur.fetchall()
        medals = ["🥇", "🥈", "🥉"]
        desc = ""
        for i, (uid, total) in enumerate(rows):
            medal = medals[i] if i < 3 else f"{i+1}."
            user = self.bot.get_user(uid)
            name = user.name if user else f"User#{uid}"
            desc += f"{medal} **{name}** — 🪙 {total:,}\n"
        await interaction.response.send_message(embed=info_embed("💰 Richest Users", desc or "No data yet."))


class TriviaButton(nextcord.ui.Button):
    def __init__(self, label: str, answer: str, idx: int):
        super().__init__(label=label, style=nextcord.ButtonStyle.blurple, row=idx // 2)
        self.answer = answer
        self._label = label

    async def callback(self, interaction: nextcord.Interaction):
        correct = self._label == self.answer
        for item in self.view.children:
            item.disabled = True
            if hasattr(item, "_label"):
                if item._label == self.answer:
                    item.style = nextcord.ButtonStyle.green
                elif not correct and item._label == self._label:
                    item.style = nextcord.ButtonStyle.red
        if correct:
            embed = nextcord.Embed(description="✅ Correct! Great job!", color=0x57F287)
        else:
            embed = nextcord.Embed(description=f"❌ Wrong! The answer was **{self.answer}**", color=0xFF4444)
        await interaction.response.edit_message(view=self.view)
        await interaction.followup.send(embed=embed)


class TriviaView(nextcord.ui.View):
    def __init__(self, answer, user_id, bot):
        super().__init__(timeout=30)
        self.answer = answer
        self.user_id = user_id
        self.bot = bot


def setup(bot):
    bot.add_cog(EntertainmentCog(bot))
