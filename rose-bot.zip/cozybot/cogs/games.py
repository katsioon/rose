"""
Simulation games for Rosé bot.
/fish: cast, collection, sell, leaderboard
/farm: plant, harvest, market, plot
/mine: dig, smelt, craft, sell
/race: enter, results
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
import time
from utils.helpers import error_embed, success_embed, info_embed

# ── Fishing ────────────────────────────────────────────────────────────────────
FISH = [
    ("Common Carp",  "🐟", 0.35, 5,  10),
    ("Goldfish",     "🐠", 0.25, 10, 20),
    ("Tuna",         "🐡", 0.15, 25, 50),
    ("Swordfish",    "🗡️", 0.10, 50, 100),
    ("Shark",        "🦈", 0.08, 80, 180),
    ("Mermaid's Tear","💎",0.04, 200,500),
    ("Old Boot",     "👢", 0.03, 0,  0),
]  # name, emoji, prob, xp, sell_price

# ── Farming ───────────────────────────────────────────────────────────────────
CROPS = {
    "wheat":     {"emoji":"🌾","grow":120, "sell":15, "seed_cost":5},
    "carrot":    {"emoji":"🥕","grow":180, "sell":25, "seed_cost":8},
    "pumpkin":   {"emoji":"🎃","grow":600, "sell":80, "seed_cost":20},
    "strawberry":{"emoji":"🍓","grow":300, "sell":50, "seed_cost":15},
    "rose":      {"emoji":"🌹","grow":900, "sell":150,"seed_cost":40},
}

# ── Mining ────────────────────────────────────────────────────────────────────
ORES = [
    ("Stone",   "🪨", 0.40, 1,  2),
    ("Iron",    "⚙️", 0.25, 5,  15),
    ("Gold",    "🪙", 0.15, 10, 40),
    ("Diamond", "💎", 0.10, 25, 120),
    ("Ruby",    "❤️", 0.07, 40, 200),
    ("Sapphire","💙", 0.03, 80, 400),
]  # name, emoji, prob, xp, sell

# ── Racing ────────────────────────────────────────────────────────────────────
ANIMALS = ["🐇","🐢","🦊","🐎","🦅","🐌","🐆","🐊"]
RACE_DURATION = 30  # seconds before results


class GamesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._fish_cd:  dict = {}
        self._mine_cd:  dict = {}
        self._races:    dict = {}  # channel_id -> {participants, start_time}

    async def _ensure_economy(self, uid):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO economy (user_id) VALUES (?)", (uid,))
            await db.commit()

    # ─────────────────────────────────────────────────────────────────────────
    # FISHING
    # ─────────────────────────────────────────────────────────────────────────
    @nextcord.slash_command(name="fish", description="🎣 Fishing mini-game")
    async def fish(self, interaction: nextcord.Interaction):
        pass

    @fish.subcommand(name="cast", description="Cast your line and catch a fish!")
    async def cast(self, interaction: nextcord.Interaction):
        uid = interaction.user.id
        now = time.time()
        cd = 30
        if now - self._fish_cd.get(uid,0) < cd:
            left = int(cd-(now-self._fish_cd[uid]))
            await interaction.response.send_message(embed=error_embed(f"Your line is still in the water! Wait **{left}s**.")); return
        self._fish_cd[uid] = now
        # Pick fish
        r = random.random()
        cum = 0.0
        caught = FISH[-1]
        for f in FISH:
            cum += f[2]
            if r <= cum:
                caught = f
                break
        fname,femoji,_,xp,sell = caught
        async with aiosqlite.connect(self.bot.db_path) as db:
            if sell > 0:
                await db.execute("INSERT INTO fish_bucket (user_id,fish_name,emoji,sell_price) VALUES (?,?,?,?)", (uid,fname,femoji,sell))
            await db.commit()
        if sell == 0:
            await interaction.response.send_message(embed=nextcord.Embed(description=f"👢 You caught... an **Old Boot**. It's worthless. Try again!", color=0x808080))
        else:
            embed = nextcord.Embed(description=f"🎣 You caught a {femoji} **{fname}**!\nSell it for 🪙{sell} with `/fish sell`", color=0x5865F2)
            await interaction.response.send_message(embed=embed)

    @fish.subcommand(name="bucket", description="View your caught fish")
    async def bucket(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT fish_name,emoji,sell_price FROM fish_bucket WHERE user_id=? ORDER BY sell_price DESC LIMIT 15", (interaction.user.id,)) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🪣 Fish Bucket", "Empty! Use `/fish cast` to catch some.")); return
        total = sum(r[2] for r in rows)
        lines = [f"{r[1]} **{r[0]}** — 🪙{r[2]}" for r in rows]
        embed = nextcord.Embed(title="🪣 Your Fish Bucket", description="\n".join(lines), color=0x5865F2)
        embed.set_footer(text=f"Total sell value: 🪙{total}")
        await interaction.response.send_message(embed=embed)

    @fish.subcommand(name="sell", description="Sell all fish in your bucket")
    async def sell_fish(self, interaction: nextcord.Interaction):
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT SUM(sell_price),COUNT(*) FROM fish_bucket WHERE user_id=?", (interaction.user.id,)) as cur:
                row = await cur.fetchone()
        total,count = row
        if not count:
            await interaction.response.send_message(embed=error_embed("Your bucket is empty!")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("DELETE FROM fish_bucket WHERE user_id=?", (interaction.user.id,))
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (total,interaction.user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Sold **{count}** fish for 🪙**{total}**!"))

    @fish.subcommand(name="leaderboard", description="Top fishers by earnings")
    async def fish_lb(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT user_id,SUM(sell_price),COUNT(*) FROM fish_bucket GROUP BY user_id ORDER BY SUM(sell_price) DESC LIMIT 10") as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🎣 Fishing Leaderboard","No data yet!")); return
        medals = ["🥇","🥈","🥉"]+["🏅"]*7
        lines = [f"{medals[i]} <@{uid}> — {cnt} fish (🪙{val:,})" for i,(uid,val,cnt) in enumerate(rows)]
        await interaction.response.send_message(embed=nextcord.Embed(title="🎣 Top Fishers",description="\n".join(lines),color=0x5865F2))

    # ─────────────────────────────────────────────────────────────────────────
    # FARMING
    # ─────────────────────────────────────────────────────────────────────────
    @nextcord.slash_command(name="farm", description="🌾 Farming simulation")
    async def farm(self, interaction: nextcord.Interaction):
        pass

    @farm.subcommand(name="plot", description="View your farm plots")
    async def plot(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT slot,crop,planted_at FROM farm_plots WHERE user_id=? ORDER BY slot", (interaction.user.id,)) as cur:
                rows = await cur.fetchall()
        now = time.time()
        slots = {r[0]:(r[1],r[2]) for r in rows}
        lines = []
        for i in range(5):
            if i not in slots:
                lines.append(f"Plot {i+1}: 🟫 Empty")
            else:
                crop,planted_at = slots[i]
                c = CROPS[crop]
                elapsed = now - planted_at
                if elapsed >= c["grow"]:
                    lines.append(f"Plot {i+1}: {c['emoji']} **{crop.title()}** — ✅ Ready to harvest!")
                else:
                    left = int(c["grow"]-elapsed)
                    m,s = divmod(left,60)
                    lines.append(f"Plot {i+1}: {c['emoji']} **{crop.title()}** — ⏳ {m}m {s}s left")
        embed = nextcord.Embed(title="🌾 Your Farm", description="\n".join(lines), color=0x57F287)
        embed.set_footer(text="Use /farm plant and /farm harvest")
        await interaction.response.send_message(embed=embed)

    @farm.subcommand(name="plant", description="Plant a crop in an empty plot")
    async def plant(self, interaction: nextcord.Interaction,
                    crop: str = SlashOption(description="Crop to plant", choices={c.title():c for c in CROPS}),
                    slot: int = SlashOption(description="Plot slot (1-5)", min_value=1, max_value=5)):
        slot -= 1
        c = CROPS[crop]
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT crop FROM farm_plots WHERE user_id=? AND slot=?", (interaction.user.id,slot)) as cur:
                existing = await cur.fetchone()
            if existing:
                await interaction.response.send_message(embed=error_embed(f"Plot {slot+1} is occupied! Harvest first.")); return
            async with db.execute("SELECT coins FROM economy WHERE user_id=?", (interaction.user.id,)) as cur:
                coins_row = await cur.fetchone()
            if not coins_row or coins_row[0] < c["seed_cost"]:
                await interaction.response.send_message(embed=error_embed(f"Need 🪙{c['seed_cost']} for seeds.")); return
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (c["seed_cost"],interaction.user.id))
            await db.execute("INSERT INTO farm_plots (user_id,slot,crop,planted_at) VALUES (?,?,?,?)", (interaction.user.id,slot,crop,time.time()))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Planted {c['emoji']} **{crop.title()}** in plot {slot+1}! Ready in {c['grow']//60}m."))

    @farm.subcommand(name="harvest", description="Harvest a ready crop")
    async def harvest(self, interaction: nextcord.Interaction,
                      slot: int = SlashOption(description="Plot slot (1-5)", min_value=1, max_value=5)):
        slot -= 1
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT crop,planted_at FROM farm_plots WHERE user_id=? AND slot=?", (interaction.user.id,slot)) as cur:
                row = await cur.fetchone()
            if not row:
                await interaction.response.send_message(embed=error_embed(f"Plot {slot+1} is empty!")); return
            crop,planted_at = row
            c = CROPS[crop]
            if time.time()-planted_at < c["grow"]:
                left = int(c["grow"]-(time.time()-planted_at))
                m,s = divmod(left,60)
                await interaction.response.send_message(embed=error_embed(f"Not ready yet! {m}m {s}s left.")); return
            await db.execute("DELETE FROM farm_plots WHERE user_id=? AND slot=?", (interaction.user.id,slot))
            await self._ensure_economy(interaction.user.id)
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (c["sell"],interaction.user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Harvested {c['emoji']} **{crop.title()}** for 🪙{c['sell']}!"))

    # ─────────────────────────────────────────────────────────────────────────
    # MINING
    # ─────────────────────────────────────────────────────────────────────────
    @nextcord.slash_command(name="mine", description="⛏️ Mining simulation")
    async def mine(self, interaction: nextcord.Interaction):
        pass

    @mine.subcommand(name="dig", description="Mine for ores (20s cooldown)")
    async def dig(self, interaction: nextcord.Interaction):
        uid = interaction.user.id
        now = time.time()
        if now - self._mine_cd.get(uid,0) < 20:
            left = int(20-(now-self._mine_cd[uid]))
            await interaction.response.send_message(embed=error_embed(f"Your pickaxe needs a rest! **{left}s**.")); return
        self._mine_cd[uid] = now
        count = random.randint(1,3)
        haul = []
        async with aiosqlite.connect(self.bot.db_path) as db:
            for _ in range(count):
                r = random.random()
                cum = 0.0
                ore = ORES[-1]
                for o in ORES:
                    cum += o[2]
                    if r <= cum:
                        ore = o; break
                oname,oemoji,_,_,osell = ore
                await db.execute("INSERT INTO mine_inventory (user_id,ore_name,emoji,sell_price) VALUES (?,?,?,?)", (uid,oname,oemoji,osell))
                haul.append(f"{oemoji} {oname}")
            await db.commit()
        embed = nextcord.Embed(title="⛏️ Mining Results!", description="\n".join(haul), color=0x795548)
        embed.set_footer(text="Sell with /mine sell")
        await interaction.response.send_message(embed=embed)

    @mine.subcommand(name="inventory", description="View your mined ores")
    async def mine_inv(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT ore_name,emoji,sell_price FROM mine_inventory WHERE user_id=? ORDER BY sell_price DESC LIMIT 20", (interaction.user.id,)) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("⛏️ Mine Inventory","Empty! Use `/mine dig`."))
            return
        total = sum(r[2] for r in rows)
        lines = [f"{r[1]} **{r[0]}** — 🪙{r[2]}" for r in rows]
        embed = nextcord.Embed(title="⛏️ Mine Inventory",description="\n".join(lines),color=0x795548)
        embed.set_footer(text=f"Total value: 🪙{total}")
        await interaction.response.send_message(embed=embed)

    @mine.subcommand(name="sell", description="Sell all your ores")
    async def sell_ore(self, interaction: nextcord.Interaction):
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT SUM(sell_price),COUNT(*) FROM mine_inventory WHERE user_id=?", (interaction.user.id,)) as cur:
                row = await cur.fetchone()
        total,count = row
        if not count:
            await interaction.response.send_message(embed=error_embed("Nothing to sell!")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("DELETE FROM mine_inventory WHERE user_id=?", (interaction.user.id,))
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (total,interaction.user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Sold **{count}** ores for 🪙**{total}**!"))

    # ─────────────────────────────────────────────────────────────────────────
    # RACING
    # ─────────────────────────────────────────────────────────────────────────
    @nextcord.slash_command(name="race", description="🏁 Animal racing — bet and compete!")
    async def race(self, interaction: nextcord.Interaction):
        pass

    @race.subcommand(name="start", description="Start a race in this channel (30s to join)")
    async def race_start(self, interaction: nextcord.Interaction,
                         bet: int = SlashOption(description="Entry fee in coins", min_value=10, max_value=500)):
        ch = interaction.channel_id
        if ch in self._races:
            await interaction.response.send_message(embed=error_embed("A race is already running here!")); return
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT coins FROM economy WHERE user_id=?", (interaction.user.id,)) as cur:
                row = await cur.fetchone()
        if not row or row[0] < bet:
            await interaction.response.send_message(embed=error_embed("Not enough coins!")); return
        self._races[ch] = {"bet": bet, "start": time.time(), "participants": [interaction.user.id]}
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (bet, interaction.user.id))
            await db.commit()
        embed = nextcord.Embed(title="🏁 Race Starting!", description=f"Entry fee: 🪙{bet}\nUse `/race join` within **30 seconds**!", color=0xFFD700)
        await interaction.response.send_message(embed=embed)
        import asyncio
        await asyncio.sleep(30)
        await self._run_race(interaction, ch)

    @race.subcommand(name="join", description="Join the current race")
    async def race_join(self, interaction: nextcord.Interaction):
        ch = interaction.channel_id
        if ch not in self._races:
            await interaction.response.send_message(embed=error_embed("No race running here! Use `/race start`.")); return
        race = self._races[ch]
        if interaction.user.id in race["participants"]:
            await interaction.response.send_message(embed=error_embed("You're already in!")); return
        bet = race["bet"]
        await self._ensure_economy(interaction.user.id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT coins FROM economy WHERE user_id=?", (interaction.user.id,)) as cur:
                row = await cur.fetchone()
        if not row or row[0] < bet:
            await interaction.response.send_message(embed=error_embed(f"Need 🪙{bet} to enter!")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins-? WHERE user_id=?", (bet, interaction.user.id))
            await db.commit()
        race["participants"].append(interaction.user.id)
        await interaction.response.send_message(embed=success_embed(f"You joined the race! 🏁 {len(race['participants'])} racers."))

    async def _run_race(self, interaction, ch_id):
        race = self._races.pop(ch_id, None)
        if not race: return
        participants = race["participants"]
        bet = race["bet"]
        if len(participants) < 2:
            # Refund
            async with aiosqlite.connect(self.bot.db_path) as db:
                for uid in participants:
                    await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (bet,uid))
                await db.commit()
            try: await interaction.channel.send(embed=error_embed("Not enough racers — everyone refunded!"))
            except: pass
            return
        animals = random.sample(ANIMALS, min(len(participants), len(ANIMALS)))
        results = list(zip(participants, animals))
        random.shuffle(results)
        winner_id, winner_animal = results[0]
        prize = bet * len(participants)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (prize, winner_id))
            await db.commit()
        lines = [f"{animal} <@{uid}>" for uid,animal in results]
        embed = nextcord.Embed(title="🏁 Race Results!", color=0xFFD700)
        embed.description = "\n".join(lines)
        embed.add_field(name="🏆 Winner", value=f"<@{winner_id}> {winner_animal}")
        embed.add_field(name="💰 Prize",  value=f"🪙{prize}")
        try: await interaction.channel.send(embed=embed)
        except: pass


def setup(bot):
    bot.add_cog(GamesCog(bot))
