"""
Custom commands feature for Rosé bot.
Server admins can create, edit, delete custom slash-like text commands.
Triggered via /cmd <name> or prefix !name
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
from utils.helpers import error_embed, success_embed, info_embed

class CustomCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _get_cmd(self, guild_id, name):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT response,embed_color,image_url,uses FROM custom_commands WHERE guild_id=? AND name=?",
                (guild_id, name.lower())
            ) as cur:
                return await cur.fetchone()

    @nextcord.slash_command(name="cc", description="⚙️ Custom commands manager")
    async def cc(self, interaction: nextcord.Interaction):
        pass

    @cc.subcommand(name="add", description="Create a custom command (Admin)")
    async def add(self, interaction: nextcord.Interaction,
                  name: str = SlashOption(description="Command name (no spaces)"),
                  response: str = SlashOption(description="Response text. Use {user} {server} for placeholders"),
                  color: str = SlashOption(description="Embed color hex (e.g. FF91A4)", required=False, default="FF91A4"),
                  image_url: str = SlashOption(description="Optional image URL", required=False)):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("You need **Manage Server** permission.")); return
        name = name.lower().replace(" ","_")[:30]
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM custom_commands WHERE guild_id=?", (interaction.guild_id,)) as cur:
                count = (await cur.fetchone())[0]
        premium = interaction.guild_id in self.bot.premium_guilds
        limit = 50 if premium else 10
        if count >= limit:
            await interaction.response.send_message(embed=error_embed(f"Custom command limit: {limit} ({'upgrade on Patreon for 50!' if not premium else 'max'})")); return
        try:
            hex_color = int(color.strip("#"), 16)
        except:
            hex_color = 0xFF91A4
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO custom_commands (guild_id,name,response,embed_color,image_url) VALUES (?,?,?,?,?) ON CONFLICT(guild_id,name) DO UPDATE SET response=excluded.response,embed_color=excluded.embed_color,image_url=excluded.image_url",
                (interaction.guild_id, name, response, hex_color, image_url)
            )
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Custom command `/{name}` created!"))

    @cc.subcommand(name="delete", description="Delete a custom command (Admin)")
    async def delete(self, interaction: nextcord.Interaction,
                     name: str = SlashOption(description="Command name to delete")):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("Need **Manage Server**.")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            cur = await db.execute("DELETE FROM custom_commands WHERE guild_id=? AND name=?", (interaction.guild_id,name.lower()))
            await db.commit()
        if cur.rowcount:
            await interaction.response.send_message(embed=success_embed(f"Deleted `/{name}`."))
        else:
            await interaction.response.send_message(embed=error_embed(f"No command named `/{name}` found."))

    @cc.subcommand(name="list", description="List all custom commands in this server")
    async def list_cmds(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT name,uses FROM custom_commands WHERE guild_id=? ORDER BY uses DESC", (interaction.guild_id,)) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("⚙️ Custom Commands", "No custom commands yet! Use `/cc add`.")); return
        lines = [f"`/{r[0]}` — used {r[1]}×" for r in rows]
        embed = nextcord.Embed(title=f"⚙️ Custom Commands ({len(rows)})", description="\n".join(lines), color=0xFF91A4)
        embed.set_footer(text="Trigger: /cmd <name>")
        await interaction.response.send_message(embed=embed)

    @cc.subcommand(name="info", description="View info about a custom command")
    async def cmd_info(self, interaction: nextcord.Interaction,
                       name: str = SlashOption(description="Command name")):
        row = await self._get_cmd(interaction.guild_id, name)
        if not row:
            await interaction.response.send_message(embed=error_embed(f"No command `/{name}` found.")); return
        resp,color,img,uses = row
        embed = nextcord.Embed(title=f"⚙️ /{name}", description=resp[:500], color=color or 0xFF91A4)
        embed.add_field(name="Uses", value=str(uses))
        if img: embed.set_image(url=img)
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="cmd", description="Run a custom command")
    async def cmd(self, interaction: nextcord.Interaction,
                  name: str = SlashOption(description="Custom command name")):
        row = await self._get_cmd(interaction.guild_id, name)
        if not row:
            await interaction.response.send_message(embed=error_embed(f"No custom command `/{name}` found. See `/cc list`.")); return
        resp,color,img,uses = row
        text = resp.replace("{user}", interaction.user.mention).replace("{server}", interaction.guild.name).replace("{name}", interaction.user.display_name)
        embed = nextcord.Embed(description=text, color=color or 0xFF91A4)
        if img: embed.set_image(url=img)
        embed.set_footer(text=f"/{name}")
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE custom_commands SET uses=uses+1 WHERE guild_id=? AND name=?", (interaction.guild_id,name))
            await db.commit()
        await interaction.response.send_message(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: nextcord.Message):
        if message.author.bot or not message.guild: return
        if not message.content.startswith("!"): return
        name = message.content[1:].split()[0].lower()
        row = await self._get_cmd(message.guild.id, name)
        if not row: return
        resp,color,img,_ = row
        text = resp.replace("{user}", message.author.mention).replace("{server}", message.guild.name).replace("{name}", message.author.display_name)
        embed = nextcord.Embed(description=text, color=color or 0xFF91A4)
        if img: embed.set_image(url=img)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE custom_commands SET uses=uses+1 WHERE guild_id=? AND name=?", (message.guild.id,name))
            await db.commit()
        await message.channel.send(embed=embed)


def setup(bot):
    bot.add_cog(CustomCog(bot))
