"""
Advanced leveling system for Rosé bot.
XP on message, configurable rates, custom rank cards, level roles,
leaderboard, server customization, XP boosts for premium.
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import asyncio
import math
import random
import io
import os
from utils.helpers import error_embed, success_embed, info_embed

def xp_for_level(level: int) -> int:
    """XP required to reach `level` from 0."""
    return int(5 * (level ** 2) + 50 * level + 100)

def level_from_xp(xp: int) -> int:
    level = 0
    while xp >= xp_for_level(level + 1):
        xp -= xp_for_level(level + 1)
        level += 1
    return level

def xp_in_level(xp: int) -> tuple[int, int]:
    """Returns (xp_into_current_level, xp_needed_for_next_level)."""
    level = 0
    while xp >= xp_for_level(level + 1):
        xp -= xp_for_level(level + 1)
        level += 1
    return xp, xp_for_level(level + 1)

RANK_COLORS = {
    "default": 0xFF91A4, "blue": 0x5865F2, "green": 0x57F287,
    "gold": 0xFFD700, "purple": 0x9B59B6, "red": 0xFF4444,
}

class LevelsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._cd: dict = {}  # user_id -> last_xp_time

    async def _config(self, guild_id: int) -> dict:
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT xp_min,xp_max,xp_cooldown,level_up_channel,level_up_msg,xp_multiplier,no_xp_roles,no_xp_channels FROM level_config WHERE guild_id=?",
                (guild_id,)
            ) as cur:
                row = await cur.fetchone()
        if not row:
            return {"xp_min":15,"xp_max":25,"cooldown":60,"channel":None,"msg":None,"mult":1.0,"no_roles":"","no_channels":""}
        return {"xp_min":row[0],"xp_max":row[1],"cooldown":row[2],"channel":row[3],"msg":row[4],"mult":row[5],"no_roles":row[6] or "","no_channels":row[7] or ""}

    async def _get_user(self, guild_id, user_id):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (guild_id,user_id))
            await db.commit()
            async with db.execute("SELECT xp,level,rank_color FROM levels WHERE guild_id=? AND user_id=?", (guild_id,user_id)) as cur:
                return await cur.fetchone()

    @commands.Cog.listener()
    async def on_message(self, message: nextcord.Message):
        if message.author.bot or not message.guild:
            return
        cfg = await self._config(message.guild.id)
        # Cooldown check
        import time
        key = (message.guild.id, message.author.id)
        now = time.time()
        if now - self._cd.get(key, 0) < cfg["cooldown"]:
            return
        self._cd[key] = now
        # Check no-xp channels/roles
        if str(message.channel.id) in cfg["no_channels"].split(","):
            return
        # Award XP
        premium = message.author.id in self.bot.premium_users
        mult = cfg["mult"] * (2.0 if premium else 1.0)
        gain = int(random.randint(cfg["xp_min"], cfg["xp_max"]) * mult)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (message.guild.id,message.author.id))
            async with db.execute("SELECT xp,level FROM levels WHERE guild_id=? AND user_id=?", (message.guild.id,message.author.id)) as cur:
                row = await cur.fetchone()
            old_xp, old_level = row
            new_xp = old_xp + gain
            new_level = level_from_xp(new_xp)
            await db.execute("UPDATE levels SET xp=?,level=? WHERE guild_id=? AND user_id=?", (new_xp,new_level,message.guild.id,message.author.id))
            await db.commit()
        # Level up!
        if new_level > old_level:
            await self._on_level_up(message, new_level, cfg)

    async def _on_level_up(self, message, new_level, cfg):
        msg_template = cfg["msg"] or "🎉 {user} reached **Level {level}**!"
        text = msg_template.format(user=message.author.mention, level=new_level)
        embed = nextcord.Embed(description=text, color=0xFFD700)
        ch_id = cfg["channel"]
        ch = message.guild.get_channel(ch_id) if ch_id else message.channel
        if ch:
            try: await ch.send(embed=embed)
            except: pass
        # Check level roles
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT role_id FROM level_roles WHERE guild_id=? AND level<=? ORDER BY level DESC LIMIT 1", (message.guild.id, new_level)) as cur:
                row = await cur.fetchone()
        if row:
            role = message.guild.get_role(row[0])
            if role:
                try: await message.author.add_roles(role, reason="Level up")
                except: pass

    @nextcord.slash_command(name="level", description="📈 Leveling system")
    async def level(self, interaction: nextcord.Interaction):
        pass

    @level.subcommand(name="rank", description="View your rank card")
    async def rank(self, interaction: nextcord.Interaction,
                   user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        row = await self._get_user(interaction.guild_id, target.id)
        xp, lvl, color_name = row
        xp_cur, xp_next = xp_in_level(xp)
        pct = int(xp_cur / xp_next * 10)
        bar = "█" * pct + "░" * (10 - pct)
        # Rank position
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT COUNT(*)+1 FROM levels WHERE guild_id=? AND xp>?", (interaction.guild_id, xp)) as cur:
                rank_pos = (await cur.fetchone())[0]
        color = RANK_COLORS.get(color_name or "default", 0xFF91A4)
        embed = nextcord.Embed(title=f"📊 {target.display_name}'s Rank", color=color)
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="🏅 Rank",  value=f"#{rank_pos}", inline=True)
        embed.add_field(name="⭐ Level", value=str(lvl),       inline=True)
        embed.add_field(name="✨ XP",    value=f"{xp:,}",      inline=True)
        embed.add_field(name="Progress", value=f"`{bar}` {xp_cur:,} / {xp_next:,} XP", inline=False)
        embed.set_footer(text="⭐ Premium users earn 2× XP!" if target.id not in self.bot.premium_users else "⭐ Premium — 2× XP active!")
        await interaction.response.send_message(embed=embed)

    @level.subcommand(name="leaderboard", description="Top members by XP")
    async def leaderboard(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT user_id,xp,level FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT 10", (interaction.guild_id,)) as cur:
                rows = await cur.fetchall()
        medals = ["🥇","🥈","🥉"] + ["🏅"]*7
        lines = []
        for i,(uid,xp,lvl) in enumerate(rows):
            m = interaction.guild.get_member(uid)
            name = m.display_name if m else f"User {uid}"
            lines.append(f"{medals[i]} **{name}** — Lv.{lvl} ({xp:,} XP)")
        embed = nextcord.Embed(title="📈 XP Leaderboard", description="\n".join(lines) or "No data yet!", color=0xFFD700)
        await interaction.response.send_message(embed=embed)

    @level.subcommand(name="color", description="Set your rank card color")
    async def color(self, interaction: nextcord.Interaction,
                    color: str = SlashOption(choices={c.title():c for c in RANK_COLORS})):
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (interaction.guild_id,interaction.user.id))
            await db.execute("UPDATE levels SET rank_color=? WHERE guild_id=? AND user_id=?", (color,interaction.guild_id,interaction.user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Rank card color set to **{color.title()}**!"))

    @level.subcommand(name="setup", description="Configure the leveling system (Admin)")
    async def setup(self, interaction: nextcord.Interaction,
                    xp_min: int = SlashOption(description="Min XP per message", required=False, default=15),
                    xp_max: int = SlashOption(description="Max XP per message", required=False, default=25),
                    cooldown: int = SlashOption(description="Seconds between XP gains", required=False, default=60),
                    channel: nextcord.TextChannel = SlashOption(description="Level-up announcement channel", required=False),
                    message: str = SlashOption(description="Level-up message ({user} {level})", required=False)):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("You need **Manage Server** permission.")); return
        ch_id = channel.id if channel else None
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO level_config (guild_id,xp_min,xp_max,xp_cooldown,level_up_channel,level_up_msg) VALUES (?,?,?,?,?,?) "
                "ON CONFLICT(guild_id) DO UPDATE SET xp_min=excluded.xp_min,xp_max=excluded.xp_max,xp_cooldown=excluded.xp_cooldown,level_up_channel=excluded.level_up_channel,level_up_msg=excluded.level_up_msg",
                (interaction.guild_id,xp_min,xp_max,cooldown,ch_id,message)
            )
            await db.commit()
        await interaction.response.send_message(embed=success_embed(
            f"Leveling configured!\nXP: {xp_min}–{xp_max} per message · Cooldown: {cooldown}s"
            + (f"\nChannel: {channel.mention}" if channel else "")
        ))

    @level.subcommand(name="set_role", description="Assign a role at a specific level (Admin)")
    async def set_role(self, interaction: nextcord.Interaction,
                       level_num: int = SlashOption(description="Level to award role"),
                       role: nextcord.Role = SlashOption(description="Role to award")):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("Need **Manage Server**.")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO level_roles (guild_id,level,role_id) VALUES (?,?,?) ON CONFLICT(guild_id,level) DO UPDATE SET role_id=excluded.role_id",
                (interaction.guild_id,level_num,role.id)
            )
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"{role.mention} will be awarded at **Level {level_num}**!"))

    @level.subcommand(name="give_xp", description="Give XP to a member (Admin)")
    async def give_xp(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(description="User"),
                      amount: int = SlashOption(description="XP amount")):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("Need **Manage Server**.")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("INSERT OR IGNORE INTO levels (guild_id,user_id) VALUES (?,?)", (interaction.guild_id,user.id))
            await db.execute("UPDATE levels SET xp=xp+? WHERE guild_id=? AND user_id=?", (amount,interaction.guild_id,user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Gave **{amount:,} XP** to {user.mention}!"))

    @level.subcommand(name="reset", description="Reset a member's XP (Admin)")
    async def reset(self, interaction: nextcord.Interaction,
                    user: nextcord.Member = SlashOption(description="User to reset")):
        if not interaction.user.guild_permissions.manage_guild:
            await interaction.response.send_message(embed=error_embed("Need **Manage Server**.")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE levels SET xp=0,level=0 WHERE guild_id=? AND user_id=?", (interaction.guild_id,user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Reset {user.mention}'s XP."))

def setup(bot):
    bot.add_cog(LevelsCog(bot))
