"""
Pets cog - adopt, raise, and care for virtual pets
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
import time
from utils.helpers import error_embed, success_embed, info_embed, premium_embed, now, human_time, PET_TYPES

FEED_COOLDOWN = 7200      # 2h
PLAY_COOLDOWN = 3600      # 1h
SLEEP_COOLDOWN = 28800    # 8h
FEED_AMOUNT = 30
PLAY_AMOUNT = 25
SLEEP_AMOUNT = 50

RARITY_COLORS = {
    "common": 0x808080,
    "uncommon": 0x57F287,
    "rare": 0x5865F2,
    "legendary": 0xFFD700,
}

def stat_bar(value: int, max_val: int = 100) -> str:
    filled = int((value / max_val) * 10)
    return "█" * filled + "░" * (10 - filled) + f" {value}%"

def decay_stat(val: int, elapsed_hours: float, rate: float = 5.0) -> int:
    return max(0, int(val - elapsed_hours * rate))

class PetsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _get_pet(self, user_id: int, pet_id: int = None):
        async with aiosqlite.connect(self.bot.db_path) as db:
            if pet_id:
                async with db.execute("SELECT * FROM pets WHERE user_id=? AND id=?", (user_id, pet_id)) as cur:
                    return await cur.fetchone()
            else:
                async with db.execute("SELECT * FROM pets WHERE user_id=? ORDER BY adopted_at DESC LIMIT 1", (user_id)) as cur:
                    return await cur.fetchone()

    def _compute_stats(self, pet):
        pid, uid, name, ptype, level, xp, hunger, happiness, energy, last_fed, last_played, last_slept, adopted_at = pet
        n = now()
        elapsed_fed = (n - last_fed) / 3600
        elapsed_played = (n - last_played) / 3600
        elapsed_slept = (n - last_slept) / 3600
        current_hunger = decay_stat(hunger, elapsed_fed, 8.0)
        current_happiness = decay_stat(happiness, elapsed_played, 5.0)
        current_energy = decay_stat(energy, elapsed_slept, 3.0)
        return current_hunger, current_happiness, current_energy

    def _pet_embed(self, pet, hunger, happiness, energy):
        pid, uid, name, ptype, level, xp, _, _, _, last_fed, last_played, last_slept, adopted_at = pet
        info = PET_TYPES.get(ptype, {"emoji": "🐾", "rarity": "common"})
        rarity = info["rarity"]
        xp_needed = level * 100
        embed = nextcord.Embed(
            title=f"{info['emoji']} {name}",
            description=f"*A {rarity} {ptype}*",
            color=RARITY_COLORS.get(rarity, 0x808080)
        )
        embed.add_field(name="Level", value=f"**{level}** ({xp}/{xp_needed} XP)")
        embed.add_field(name="Rarity", value=rarity.title())
        embed.add_field(name="Pet ID", value=f"#{pid}")
        embed.add_field(
            name="🍖 Hunger",
            value=stat_bar(hunger),
            inline=False
        )
        embed.add_field(
            name="💛 Happiness",
            value=stat_bar(happiness),
            inline=False
        )
        embed.add_field(
            name="⚡ Energy",
            value=stat_bar(energy),
            inline=False
        )
        if hunger < 20:
            embed.add_field(name="⚠️ Warning", value="Your pet is hungry!", inline=False)
        if happiness < 20:
            embed.add_field(name="⚠️ Warning", value="Your pet is unhappy!", inline=False)
        embed.set_footer(text=f"Adopted: <t:{adopted_at}:R>")
        return embed

    @nextcord.slash_command(name="pet", description="🐾 Virtual pet system")
    async def pet(self, interaction: nextcord.Interaction): pass

    @pet.subcommand(name="adopt", description="Adopt a new pet")
    async def pet_adopt(
        self,
        interaction: nextcord.Interaction,
        name: str = SlashOption(description="Name your pet"),
        pet_type: str = SlashOption(description="Pet type", choices=list(PET_TYPES.keys()))):
        is_premium = interaction.user.id in self.bot.premium_users
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM pets WHERE user_id=?", (interaction.user.id)) as cur:
                count = (await cur.fetchone())[0]
        
        max_pets = 5 if is_premium else 1
        if count >= max_pets:
            msg = f"You can only have {max_pets} pet{'s' if max_pets > 1 else ''}."
            if not is_premium:
                await interaction.response.send_message(embed=premium_embed("Multiple Pets"))
            else:
                await interaction.response.send_message(embed=error_embed(msg))
            return

        # Check if legendary/rare requires premium
        info = PET_TYPES[pet_type]
        if info["rarity"] in ("rare", "legendary") and not is_premium:
            await interaction.response.send_message(embed=premium_embed(f"Rare/Legendary Pets ({pet_type.title()})"))
            return

        async with aiosqlite.connect(self.bot.db_path) as db:
            cur = await db.execute(
                "INSERT INTO pets (user_id, name, type) VALUES (?,?,?)",
                (interaction.user.id, name[:20], pet_type)
            )
            pid = cur.lastrowid
            await db.commit()

        embed = nextcord.Embed(
            title=f"🎉 Welcome, {name}!",
            description=f"You adopted a **{info['rarity']}** {info['emoji']} **{pet_type}**!\n\nRemember to feed and play with your pet to keep them happy!",
            color=RARITY_COLORS.get(info["rarity"], 0x57F287)
        )
        embed.set_footer(text=f"Pet ID: #{pid} • Use /pet status to check on them")
        await interaction.response.send_message(embed=embed)

    @pet.subcommand(name="status", description="Check your pet's status")
    async def pet_status(
        self,
        interaction: nextcord.Interaction,
        pet_id: int = SlashOption(description="Pet ID (leave blank for last pet)", required=False)):
        pet = await self._get_pet(interaction.user.id, pet_id)
        if not pet:
            await interaction.response.send_message(embed=error_embed("You don't have a pet! Use `/pet adopt`"))
            return
        hunger, happiness, energy = self._compute_stats(pet)
        await interaction.response.send_message(embed=self._pet_embed(pet, hunger, happiness, energy))

    @pet.subcommand(name="feed", description="Feed your pet")
    async def pet_feed(
        self,
        interaction: nextcord.Interaction,
        pet_id: int = SlashOption(description="Pet ID (leave blank for last pet)", required=False)):
        pet = await self._get_pet(interaction.user.id, pet_id)
        if not pet:
            await interaction.response.send_message(embed=error_embed("No pet found!"))
            return
        pid = pet[0]
        last_fed = pet[9]
        remaining = FEED_COOLDOWN - (now() - last_fed)
        if remaining > 0:
            await interaction.response.send_message(
                embed=error_embed(f"Your pet isn't hungry yet! Wait **{human_time(remaining)}**"))
            return
        hunger, happiness, energy = self._compute_stats(pet)
        new_hunger = min(100, hunger + FEED_AMOUNT)
        new_xp = pet[5] + 10
        new_level = pet[4]
        if new_xp >= new_level * 100:
            new_xp -= new_level * 100
            new_level += 1
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "UPDATE pets SET hunger=?, last_fed=?, xp=?, level=? WHERE id=?",
                (new_hunger, now(), new_xp, new_level, pid)
            )
            await db.commit()
        msg = f"You fed **{pet[2]}**! 🍖\nHunger: {stat_bar(new_hunger)}"
        if new_level > pet[4]:
            msg += f"\n\n🎉 **{pet[2]} leveled up to level {new_level}!**"
        await interaction.response.send_message(embed=success_embed(msg))

    @pet.subcommand(name="play", description="Play with your pet")
    async def pet_play(
        self,
        interaction: nextcord.Interaction,
        pet_id: int = SlashOption(description="Pet ID (leave blank for last pet)", required=False)):
        pet = await self._get_pet(interaction.user.id, pet_id)
        if not pet:
            await interaction.response.send_message(embed=error_embed("No pet found!"))
            return
        pid = pet[0]
        last_played = pet[10]
        remaining = PLAY_COOLDOWN - (now() - last_played)
        if remaining > 0:
            await interaction.response.send_message(
                embed=error_embed(f"Your pet needs rest! Wait **{human_time(remaining)}**"))
            return
        hunger, happiness, energy = self._compute_stats(pet)
        activities = ["played fetch", "solved a puzzle", "went for a walk", "danced around", "played hide and seek"]
        activity = random.choice(activities)
        new_happiness = min(100, happiness + PLAY_AMOUNT)
        new_xp = pet[5] + 15
        new_level = pet[4]
        if new_xp >= new_level * 100:
            new_xp -= new_level * 100
            new_level += 1
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "UPDATE pets SET happiness=?, last_played=?, xp=?, level=? WHERE id=?",
                (new_happiness, now(), new_xp, new_level, pid)
            )
            await db.commit()
        msg = f"You {activity} with **{pet[2]}**! 🎮\nHappiness: {stat_bar(new_happiness)}"
        if new_level > pet[4]:
            msg += f"\n\n🎉 **{pet[2]} leveled up to level {new_level}!**"
        await interaction.response.send_message(embed=success_embed(msg))

    @pet.subcommand(name="sleep", description="Let your pet rest")
    async def pet_sleep(
        self,
        interaction: nextcord.Interaction,
        pet_id: int = SlashOption(description="Pet ID (leave blank for last pet)", required=False)):
        pet = await self._get_pet(interaction.user.id, pet_id)
        if not pet:
            await interaction.response.send_message(embed=error_embed("No pet found!"))
            return
        pid = pet[0]
        last_slept = pet[11]
        remaining = SLEEP_COOLDOWN - (now() - last_slept)
        if remaining > 0:
            await interaction.response.send_message(
                embed=error_embed(f"Your pet isn't tired! Wait **{human_time(remaining)}**"))
            return
        hunger, happiness, energy = self._compute_stats(pet)
        new_energy = min(100, energy + SLEEP_AMOUNT)
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE pets SET energy=?, last_slept=? WHERE id=?", (new_energy, now(), pid))
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"**{pet[2]}** had a nice rest! 😴\nEnergy: {stat_bar(new_energy)}")
        )

    @pet.subcommand(name="list", description="View all your pets")
    async def pet_list(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT id, name, type, level, hunger, happiness, energy FROM pets WHERE user_id=? ORDER BY level DESC",
                (interaction.user.id)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🐾 Your Pets", "No pets yet! Use `/pet adopt`"))
            return
        desc = ""
        for pid, name, ptype, level, h, hp, e in rows:
            info = PET_TYPES.get(ptype, {"emoji": "🐾", "rarity": "common"})
            desc += f"{info['emoji']} **{name}** ({ptype}) — Lv.{level} `#{pid}`\n"
        embed = nextcord.Embed(title="🐾 Your Pets", description=desc, color=0xF4A261)
        await interaction.response.send_message(embed=embed)

    @pet.subcommand(name="rename", description="Rename your pet")
    async def pet_rename(
        self,
        interaction: nextcord.Interaction,
        new_name: str = SlashOption(description="New name"),
        pet_id: int = SlashOption(description="Pet ID", required=False)):
        pet = await self._get_pet(interaction.user.id, pet_id)
        if not pet:
            await interaction.response.send_message(embed=error_embed("No pet found!"))
            return
        old_name = pet[2]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE pets SET name=? WHERE id=?", (new_name[:20], pet[0]))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"**{old_name}** is now named **{new_name}**!"))

    @pet.subcommand(name="leaderboard", description="Top pets by level")
    async def pet_leaderboard(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT user_id, name, type, level FROM pets ORDER BY level DESC LIMIT 10"
            ) as cur:
                rows = await cur.fetchall()
        medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 7
        desc = ""
        for i, (uid, name, ptype, level) in enumerate(rows):
            user = self.bot.get_user(uid)
            owner = user.name if user else f"User#{uid}"
            info = PET_TYPES.get(ptype, {"emoji": "🐾"})
            desc += f"{medals[i]} {info['emoji']} **{name}** Lv.{level} — *owned by {owner}*\n"
        await interaction.response.send_message(embed=info_embed("🏆 Top Pets", desc or "No pets yet!"))


def setup(bot):
    bot.add_cog(PetsCog(bot))
