"""
Utility cog - server tools, reminders, polls, user info, etc.
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import asyncio
import time
from utils.helpers import error_embed, success_embed, info_embed, now, human_time

class PollView(nextcord.ui.View):
    def __init__(self, options: list[str]):
        super().__init__(timeout=None)
        self.votes: dict = {opt: set() for opt in options}
        self.options = options
        for i, opt in enumerate(options[:5]):
            btn = PollButton(opt, i)
            self.add_item(btn)

    def results_embed(self, question: str) -> nextcord.Embed:
        total = sum(len(v) for v in self.votes.values())
        desc = ""
        for opt, voters in self.votes.items():
            pct = (len(voters) / total * 100) if total > 0 else 0
            bar = "█" * int(pct / 10) + "░" * (10 - int(pct / 10))
            desc += f"**{opt}**\n{bar} {len(voters)} votes ({pct:.0f}%)\n\n"
        embed = nextcord.Embed(title=f"📊 {question}", description=desc or "No votes yet.", color=0x5865F2)
        embed.set_footer(text=f"Total votes: {total}")
        return embed

class PollButton(nextcord.ui.Button):
    def __init__(self, label: str, idx: int):
        super().__init__(label=label[:80], style=nextcord.ButtonStyle.blurple, row=idx // 3)
        self._opt = label

    async def callback(self, interaction: nextcord.Interaction):
        view: PollView = self.view
        uid = interaction.user.id
        # Remove from other options
        for opt, voters in view.votes.items():
            voters.discard(uid)
        view.votes[self._opt].add(uid)
        embed = view.results_embed(interaction.message.embeds[0].title.replace("📊 ", ""))
        await interaction.response.edit_message(embed=embed, view=view)

class UtilityCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._reminder_task = None

    def cog_load(self):
        self._reminder_task = asyncio.create_task(self._reminder_loop())

    def cog_unload(self):
        if self._reminder_task:
            self._reminder_task.cancel()

    async def _reminder_loop(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                async with aiosqlite.connect(self.bot.db_path) as db:
                    async with db.execute(
                        "SELECT id, user_id, channel_id, message FROM reminders WHERE remind_at<=? AND done=0",
                        (now())
                    ) as cur:
                        rows = await cur.fetchall()
                    for rid, uid, ch_id, msg in rows:
                        ch = self.bot.get_channel(ch_id)
                        if ch:
                            embed = nextcord.Embed(
                                title="⏰ Reminder!",
                                description=f"<@{uid}>, you asked me to remind you:\n\n{msg}",
                                color=0xF4A261)
                            try:
                                await ch.send(embed=embed)
                            except:
                                pass
                        await db.execute("UPDATE reminders SET done=1 WHERE id=?", (rid))
                    await db.commit()
            except Exception as e:
                pass
            await asyncio.sleep(30)

    @nextcord.slash_command(name="remind", description="⏰ Set a reminder")
    async def remind(
        self,
        interaction: nextcord.Interaction,
        time_str: str = SlashOption(description="When (e.g. 10m, 2h, 1d)"),
        message: str = SlashOption(description="What to remind you about")):
        # Parse time
        units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
        try:
            unit = time_str[-1].lower()
            amount = int(time_str[:-1])
            assert unit in units and 1 <= amount <= 999
            seconds = amount * units[unit]
        except:
            await interaction.response.send_message(
                embed=error_embed("Invalid time format! Use: `10m`, `2h`, `1d`"))
            return

        remind_at = now() + seconds
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO reminders (user_id, channel_id, message, remind_at) VALUES (?,?,?,?)",
                (interaction.user.id, interaction.channel_id, message, remind_at)
            )
            await db.commit()
        embed = nextcord.Embed(
            title="⏰ Reminder Set!",
            description=f"I'll remind you in **{human_time(seconds)}**:\n*{message}*",
            color=0x57F287)
        embed.set_footer(text=f"Reminder at <t:{remind_at}:t>")
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="poll", description="📊 Create a poll")
    async def poll(
        self,
        interaction: nextcord.Interaction,
        question: str = SlashOption(description="Poll question"),
        options: str = SlashOption(description="Options separated by | (e.g. Yes|No|Maybe)")):
        opts = [o.strip() for o in options.split("|") if o.strip()][:5]
        if len(opts) < 2:
            await interaction.response.send_message(embed=error_embed("Need at least 2 options! Separate with |"))
            return
        view = PollView(opts)
        embed = nextcord.Embed(title=f"📊 {question}", description="Vote by clicking a button below!", color=0x5865F2)
        await interaction.response.send_message(embed=embed, view=view)

    @nextcord.slash_command(name="serverinfo", description="📋 Server information")
    async def serverinfo(self, interaction: nextcord.Interaction):
        g = interaction.guild
        embed = nextcord.Embed(title=g.name, color=0x5865F2)
        if g.icon:
            embed.set_thumbnail(url=g.icon.url)
        embed.add_field(name="Owner", value=f"<@{g.owner_id}>")
        embed.add_field(name="Members", value=f"{g.member_count:,}")
        embed.add_field(name="Channels", value=f"{len(g.channels)}")
        embed.add_field(name="Roles", value=f"{len(g.roles)}")
        embed.add_field(name="Boosts", value=f"{g.premium_subscription_count} (Level {g.premium_tier})")
        embed.add_field(name="Verification", value=str(g.verification_level).title())
        embed.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:D>")
        embed.set_footer(text=f"ID: {g.id}")
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="userinfo", description="👤 User information")
    async def userinfo(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="User to check", required=False)):
        member = user or interaction.user
        roles = [r.mention for r in reversed(member.roles) if r != interaction.guild.default_role][:10]
        embed = nextcord.Embed(
            title=str(member),
            description=f"{'⭐ Premium User' if member.id in self.bot.premium_users else ''}",
            color=member.color)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Display Name", value=member.display_name)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>")
        embed.add_field(name="Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "Unknown")
        embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles) or "None", inline=False)
        embed.set_footer(text=f"ID: {member.id}")
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="avatar", description="🖼️ Get a user's avatar")
    async def avatar(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="User (default: you)", required=False)):
        target = user or interaction.user
        embed = nextcord.Embed(title=f"{target.display_name}'s Avatar", color=0x5865F2)
        embed.set_image(url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="ping", description="🏓 Check bot latency")
    async def ping(self, interaction: nextcord.Interaction):
        latency = round(self.bot.latency * 1000)
        color = 0x57F287 if latency < 100 else 0xFEE75C if latency < 200 else 0xFF4444
        embed = nextcord.Embed(
            title="🏓 Pong!",
            description=f"**Latency:** {latency}ms",
            color=color)
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="help", description="📖 Help & command list")
    async def help_cmd(
        self,
        interaction: nextcord.Interaction,
        category: str = SlashOption(
            description="Category",
            choices=["tickets", "entertainment", "economy", "imagine", "horoscope", "social", "rl", "pets", "cozy", "utility", "premium"],
            required=False
        )):
        if category == "tickets" or not category and False:
            pass

        categories = {
            "🎫 Tickets": "`/ticket open` `/ticket panel` `/ticket setup` `/ticket list`",
            "🎮 Fun": "`/fun 8ball` `/fun coinflip` `/fun roll` `/fun trivia` `/fun rps` `/fun joke` `/fun fact`",
            "🎨 Imagine": "`/imagine generate` `/imagine styles` `/imagine usage` `/imagine info`",
            "🌸 Social": "`/social hug` `/social pat` `/social kiss` `/social cuddle` `/social boop` `/social poke` `/social wave` `/social highfive` `/social stare` `/social bite` `/social slap` `/social punch` `/social nom` `/social cry` `/social laugh` `/social blush` `/social sleep` `/social dance` `/social think` `/social rep` `/social profile` `/social setbio` `/social leaderboard`",
            "🔮 Horoscope": "`/horoscope daily` `/horoscope tarot` `/horoscope three_card` `/horoscope fortune` `/horoscope ask` `/horoscope compatibility` `/horoscope element` `/horoscope monthly` `/horoscope birthchart` `/horoscope affinity` `/horoscope numerology` `/horoscope signs`",
            "💰 Economy": "`/economy balance` `/economy daily` `/economy work` `/economy slots` `/economy give` `/economy leaderboard`",
            "📚 RL Resources": "`/rl browse` `/rl random` `/rl search` `/rl top` `/rl roadmap` `/rl submit` *(Premium)*",
            "🐾 Pets": "`/pet adopt` `/pet status` `/pet feed` `/pet play` `/pet sleep` `/pet list` `/pet rename` `/pet leaderboard`",
            "🍵 Cozy": "`/cozy affirmation` `/cozy vibe` `/cozy mood` `/cozy board` `/cozy tea` `/cozy breathe` `/cozy quote` `/cozy hug`",
            "🔧 Utility": "`/remind` `/poll` `/serverinfo` `/userinfo` `/avatar` `/ping`",
            "⭐ Premium": "`/premium info` `/premium status`",
        }

        embed = nextcord.Embed(
            title="📖 Rosé Help",
            description="Your all-in-one cozy Discord companion! 🍵\n\nUse `/help [category]` for details.",
            color=0xF4A261)
        for name, cmds in categories.items():
            embed.add_field(name=name, value=cmds, inline=False)
        embed.set_footer(text="⭐ = Premium feature • Join discord.gg/rKajpSCGKF for support")
        await interaction.response.send_message(embed=embed)

    @nextcord.slash_command(name="invites", description="📨 View invite stats for this server")
    async def invites(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="Check a specific user's invites", required=False)):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT invite_tracking FROM guild_config WHERE guild_id=?", (interaction.guild_id)) as cur:
                row = await cur.fetchone()
        if not row or not row[0]:
            await interaction.response.send_message(
                embed=error_embed("Invite tracking is disabled. Enable it with `/dev toggle_invite_tracking`."))
            return
        async with aiosqlite.connect(self.bot.db_path) as db:
            if user:
                async with db.execute(
                    "SELECT code, uses FROM invite_stats WHERE guild_id=? AND inviter_id=?",
                    (interaction.guild_id, user.id)
                ) as cur:
                    rows = await cur.fetchall()
                total = sum(r[1] for r in rows)
                desc = f"**{user.display_name}** has invited **{total}** member(s)\n"
                for code, uses in rows:
                    desc += f"`{code}` — {uses} uses\n"
                await interaction.response.send_message(embed=info_embed("📨 Invite Stats", desc))
            else:
                async with db.execute(
                    "SELECT inviter_id, SUM(uses) as total FROM invite_stats WHERE guild_id=? GROUP BY inviter_id ORDER BY total DESC LIMIT 10",
                    (interaction.guild_id)
                ) as cur:
                    rows = await cur.fetchall()
                desc = ""
                for uid, total in rows:
                    member = interaction.guild.get_member(uid)
                    name = member.display_name if member else f"User#{uid}"
                    desc += f"**{name}** — {total} invites\n"
                await interaction.response.send_message(embed=info_embed("📨 Top Inviters", desc or "No data yet."))


    @nextcord.slash_command(name="settings", description="⚙️ Server settings")
    async def settings(self, interaction: nextcord.Interaction):
        pass

    @settings.subcommand(name="language", description="Set the bot language for this server")
    async def settings_language(
        self,
        interaction: nextcord.Interaction,
        language: str = SlashOption(description="Choose language", choices={"English 🇬🇧":"en","Dutch 🇳🇱":"nl","French 🇫🇷":"fr","German 🇩🇪":"de","Spanish 🇪🇸":"es","Portuguese 🇧🇷":"pt"}),
    ):
        if not (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator):
            await interaction.response.send_message(embed=error_embed("You need **Manage Server** permission."))
            return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, lang) VALUES (?,?) ON CONFLICT(guild_id) DO UPDATE SET lang=excluded.lang",
                (interaction.guild_id, language)
            )
            await db.commit()
        from utils.i18n import LANGUAGE_NAMES
        name, flag = LANGUAGE_NAMES.get(language, ("Unknown","🌐"))
        await interaction.response.send_message(embed=success_embed(f"Language set to **{name}** {flag}"))


def setup(bot):
    bot.add_cog(UtilityCog(bot))
