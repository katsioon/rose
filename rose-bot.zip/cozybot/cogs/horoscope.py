"""
Horoscope & Oracle cog for Rosé bot.
Commands: daily, tarot, fortune, compatibility, numerology, signs,
          monthly, element, ask, birthchart, affinity
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import random
import datetime
from utils.i18n import t

SIGNS = [
    "aries","taurus","gemini","cancer","leo","virgo",
    "libra","scorpio","sagittarius","capricorn","aquarius","pisces"
]
SIGN_EMOJI = {
    "aries":"♈","taurus":"♉","gemini":"♊","cancer":"♋",
    "leo":"♌","virgo":"♍","libra":"♎","scorpio":"♏",
    "sagittarius":"♐","capricorn":"♑","aquarius":"♒","pisces":"♓",
}
SIGN_DATES = {
    "aries":"Mar 21 – Apr 19","taurus":"Apr 20 – May 20","gemini":"May 21 – Jun 20",
    "cancer":"Jun 21 – Jul 22","leo":"Jul 23 – Aug 22","virgo":"Aug 23 – Sep 22",
    "libra":"Sep 23 – Oct 22","scorpio":"Oct 23 – Nov 21","sagittarius":"Nov 22 – Dec 21",
    "capricorn":"Dec 22 – Jan 19","aquarius":"Jan 20 – Feb 18","pisces":"Feb 19 – Mar 20",
}
ELEMENTS = {"fire":["aries","leo","sagittarius"],"earth":["taurus","virgo","capricorn"],
            "air":["gemini","libra","aquarius"],"water":["cancer","scorpio","pisces"]}
ELEMENT_OF = {s:e for e,signs in ELEMENTS.items() for s in signs}
ELEMENT_EMOJI = {"fire":"🔥","earth":"🌍","air":"💨","water":"💧"}
MODALITIES = {"cardinal":["aries","cancer","libra","capricorn"],
              "fixed":["taurus","leo","scorpio","aquarius"],
              "mutable":["gemini","virgo","sagittarius","pisces"]}
MODALITY_OF = {s:m for m,signs in MODALITIES.items() for s in signs}
RULING_PLANETS = {
    "aries":"Mars ♂","taurus":"Venus ♀","gemini":"Mercury ☿","cancer":"Moon 🌙",
    "leo":"Sun ☀️","virgo":"Mercury ☿","libra":"Venus ♀","scorpio":"Pluto/Mars",
    "sagittarius":"Jupiter ♃","capricorn":"Saturn ♄","aquarius":"Uranus ⛢","pisces":"Neptune ♆",
}
SIGN_KEYWORDS = {
    "aries":"Bold, impulsive, courageous","taurus":"Patient, reliable, sensual",
    "gemini":"Curious, adaptable, witty","cancer":"Intuitive, nurturing, emotional",
    "leo":"Charismatic, creative, proud","virgo":"Analytical, practical, modest",
    "libra":"Diplomatic, fair, social","scorpio":"Intense, perceptive, passionate",
    "sagittarius":"Adventurous, optimistic, free","capricorn":"Ambitious, disciplined, patient",
    "aquarius":"Innovative, independent, humanitarian","pisces":"Empathetic, artistic, dreamy",
}

HOROSCOPE_TEMPLATES = [
    ("love",    ["💕 A meaningful connection deepens today.","💔 Give yourself space — healing is progress.",
                 "💞 Someone unexpected may catch your eye.","🌹 Honesty strengthens your closest bonds.",
                 "✨ Love flows freely when you open your heart.","🕊️ A misunderstanding clears up today.",
                 "🌸 Patience in love will be rewarded."]),
    ("career",  ["📈 A bold move pays off — trust your instincts.","⚠️ Patience now leads to reward later.",
                 "🤝 Collaboration brings unexpected solutions.","💡 Your creativity is your biggest asset today.",
                 "🔑 An opportunity arrives — be ready to say yes.","📊 Focus on the details others overlook.",
                 "🚀 A long-term goal moves one step closer."]),
    ("money",   ["💰 A smart investment is on the horizon.","🌱 Small savings now grow into security.",
                 "⚖️ Balance your spending and saving today.","🎯 Avoid impulsive purchases — wait 24 hours.",
                 "💎 Your financial patience will be rewarded.","🪙 An unexpected expense is manageable.",
                 "📈 Review your finances — something is working."]),
    ("health",  ["🌿 Rest is productive — don't skip it.","🏃 Movement lifts your mood today.",
                 "💧 Hydration is your best medicine today.","🌙 Prioritize sleep — your mind needs it.",
                 "🍎 Nourish your body and it will thank you.","🧘 A moment of stillness resets everything.",
                 "🌞 Fresh air and a short walk do wonders."]),
    ("general", ["🌟 Today holds more potential than it seems.","🔮 Trust the process — the path will clear.",
                 "🌈 A small joy arrives when least expected.","🕊️ Let go of what no longer serves you.",
                 "🌺 Your energy is magnetic — use it wisely.","🎯 Stay grounded and focused today.",
                 "🌙 Something you've been waiting for is close."]),
]

MONTHLY_THEMES = [
    "🌱 Growth & New Beginnings","💪 Strength & Resilience","🔍 Reflection & Clarity",
    "💞 Connection & Relationships","💰 Abundance & Manifestation","🛡️ Boundaries & Self-care",
    "🚀 Action & Momentum","🌙 Rest & Renewal","🎨 Creativity & Expression",
    "🔮 Intuition & Inner Wisdom","⚡ Change & Transformation","🌸 Gratitude & Appreciation",
]

TAROT_CARDS = [
    ("The Fool","🃏","New beginnings, innocence, spontaneity, a free spirit"),
    ("The Magician","🎩","Power, skill, concentration, action, resourcefulness"),
    ("The High Priestess","🌙","Intuition, sacred knowledge, divine feminine, subconscious"),
    ("The Empress","👑","Femininity, beauty, nature, nurturing, abundance"),
    ("The Emperor","🏛️","Authority, establishment, structure, a father figure"),
    ("The Hierophant","⛪","Spiritual wisdom, tradition, conformity, institutions"),
    ("The Lovers","💑","Love, harmony, relationships, values, choices"),
    ("The Chariot","🏇","Control, willpower, success, determination"),
    ("Strength","🦁","Strength, courage, patience, control, compassion"),
    ("The Hermit","🏮","Soul-searching, introspection, being alone, inner guidance"),
    ("Wheel of Fortune","🎡","Good luck, karma, life cycles, destiny, a turning point"),
    ("Justice","⚖️","Justice, fairness, truth, cause and effect, law"),
    ("The Hanged Man","🙃","Pause, surrender, letting go, new perspectives"),
    ("Death","💀","Endings, change, transformation, transition"),
    ("Temperance","🌊","Balance, moderation, patience, purpose, meaning"),
    ("The Devil","😈","Shadow self, attachment, addiction, restriction"),
    ("The Tower","⚡","Sudden change, upheaval, chaos, revelation, awakening"),
    ("The Star","⭐","Hope, faith, purpose, renewal, spirituality"),
    ("The Moon","🌕","Illusion, fear, the unconscious, confusion, complexity"),
    ("The Sun","☀️","Positivity, fun, warmth, success, vitality"),
    ("Judgement","📯","Reflection, reckoning, awakening, absolution"),
    ("The World","🌍","Completion, integration, accomplishment, travel"),
]

FORTUNE_COOKIES = [
    "A beautiful surprise is coming your way soon. 🌸",
    "Your hard work is about to pay off. Stay patient. 🌟",
    "The best is yet to come — keep moving forward. 🚀",
    "Something you lost will soon be found. 🔍",
    "A kind word today will echo for years. 💛",
    "Trust yourself — you already know the answer. 🔮",
    "The obstacle in front of you is smaller than it seems. 🌈",
    "Your next chapter begins the moment you decide it does. 📖",
    "Great things are built slowly, one day at a time. 🏗️",
    "The universe is conspiring in your favour. ✨",
    "An unexpected friendship will brighten your world. 🤝",
    "What you seek is also seeking you. 🌺",
    "Happiness is closer than you think — look inward. 🍵",
    "Your creativity holds the solution you need. 🎨",
    "A door that closed made room for a better one. 🚪",
    "Today's small action is tomorrow's big result. 🌱",
    "Someone around you admires you more than you know. 💫",
    "The answer will come to you when you stop forcing it. 🌙",
    "Your kindness will return to you tenfold. 🌸",
    "A risk you're considering is safer than it feels. ⚡",
]

YES_NO_ANSWERS = [
    ("Yes ✅", 0x57F287, "The stars align in your favour."),
    ("No ❌", 0xFF4444, "Now is not the right time."),
    ("Maybe 🤔", 0xFFD700, "The answer is unclear — trust your gut."),
    ("Absolutely ✨", 0x57F287, "Without a doubt."),
    ("Not yet ⏳", 0xFF9500, "Patience — the timing isn't right."),
    ("Yes, but... 💛", 0xFFD700, "Proceed with care and awareness."),
]

def _seed(key: str) -> int:
    today = datetime.date.today().isoformat()
    return hash(f"{key}{today}") & 0xFFFFFFFF

def _get_horoscope(sign: str) -> dict:
    rng = random.Random(_seed(sign))
    sections = {cat: rng.choice(lines) for cat, lines in HOROSCOPE_TEMPLATES}
    lucky_num   = rng.randint(1, 99)
    lucky_color = rng.choice(["Rose 🌸","Midnight Blue 🌙","Forest Green 🌿","Gold ✨",
                               "Lavender 💜","Coral 🪸","Sky Blue 🩵","Crimson ❤️","Silver 🌫️"])
    return {"sections": sections, "lucky_num": lucky_num, "lucky_color": lucky_color}


class HoroscopeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _lang(self, guild_id):
        return await self.bot.get_lang(guild_id)

    @nextcord.slash_command(name="horoscope", description="🔮 Daily horoscope & mystical readings")
    async def horoscope(self, interaction: nextcord.Interaction):
        pass

    # ── /horoscope daily ───────────────────────────────────────────────────────
    @horoscope.subcommand(name="daily", description="Get your full daily horoscope")
    async def daily(
        self,
        interaction: nextcord.Interaction,
        sign: str = SlashOption(description="Your star sign", choices=SIGNS),
    ):
        lang = await self._lang(interaction.guild_id)
        h    = _get_horoscope(sign)
        s    = h["sections"]
        embed = nextcord.Embed(
            title=t(lang, "hs_daily_title", emoji=SIGN_EMOJI[sign], sign=sign.title()),
            description=f"*{SIGN_DATES[sign]}*",
            color=0xFF91A4,
        )
        embed.add_field(name=t(lang,"hs_love"),    value=s["love"],    inline=False)
        embed.add_field(name=t(lang,"hs_career"),  value=s["career"],  inline=False)
        embed.add_field(name=t(lang,"hs_money"),   value=s["money"],   inline=False)
        embed.add_field(name=t(lang,"hs_health"),  value=s["health"],  inline=False)
        embed.add_field(name=t(lang,"hs_overall"), value=s["general"], inline=False)
        embed.add_field(name=t(lang,"hs_lucky_num"),    value=str(h["lucky_num"]), inline=True)
        embed.add_field(name=t(lang,"hs_lucky_colour"), value=h["lucky_color"],   inline=True)
        embed.set_footer(text=f"✨ Rosé Horoscopes • {datetime.date.today().strftime('%B %d, %Y')}")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope monthly ────────────────────────────────────────────────────
    @horoscope.subcommand(name="monthly", description="Get your monthly theme & focus")
    async def monthly(
        self,
        interaction: nextcord.Interaction,
        sign: str = SlashOption(description="Your star sign", choices=SIGNS),
    ):
        rng   = random.Random(_seed(f"monthly_{sign}_{datetime.date.today().strftime('%Y-%m')}"))
        theme = rng.choice(MONTHLY_THEMES)
        focus = rng.choice([s[1][rng.randint(0,6)] for s in HOROSCOPE_TEMPLATES])
        power = rng.choice(["Self-trust","Communication","Rest","Action","Gratitude",
                             "Boundaries","Creativity","Patience","Vulnerability","Courage"])
        embed = nextcord.Embed(
            title=f"{SIGN_EMOJI[sign]} {sign.title()} — {datetime.date.today().strftime('%B %Y')}",
            color=0x9B59B6,
        )
        embed.add_field(name="🗓️ Monthly Theme",   value=theme,  inline=False)
        embed.add_field(name="🎯 Area of Focus",   value=focus,  inline=False)
        embed.add_field(name="💪 Power Word",      value=power,  inline=True)
        embed.add_field(name="🌙 Ruling Planet",   value=RULING_PLANETS[sign], inline=True)
        embed.set_footer(text="✨ Monthly reading resets on the 1st")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope tarot ──────────────────────────────────────────────────────
    @horoscope.subcommand(name="tarot", description="Draw a tarot card for guidance")
    async def tarot(
        self,
        interaction: nextcord.Interaction,
        question: str = SlashOption(description="What do you want guidance on?", required=False),
    ):
        lang = await self._lang(interaction.guild_id)
        card, emoji, meaning = random.choice(TAROT_CARDS)
        reversed_card = random.random() < 0.3
        embed = nextcord.Embed(
            title=f"{emoji} {card}" + (" (Reversed)" if reversed_card else ""),
            color=0x9B59B6,
        )
        if question:
            embed.add_field(name=t(lang,"hs_tarot_question"), value=question, inline=False)
        embed.add_field(
            name=t(lang,"hs_tarot_meaning"),
            value=meaning + (" *(reversed — look inward)*" if reversed_card else ""),
            inline=False,
        )
        embed.add_field(
            name=t(lang,"hs_rose_says"),
            value=random.choice([
                "The cards reveal what you already sense deep down.",
                "Let this card guide your thinking, not dictate it.",
                "Trust what resonates — the rest is noise.",
                "This is an invitation to reflect, not a verdict.",
                "What feels true to you right now?"
            ]),
            inline=False,
        )
        embed.set_footer(text="✨ One card draw")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope three_card ─────────────────────────────────────────────────
    @horoscope.subcommand(name="three_card", description="Draw a past / present / future tarot spread")
    async def three_card(
        self,
        interaction: nextcord.Interaction,
        question: str = SlashOption(description="What situation do you want insight on?", required=False),
    ):
        drawn = random.sample(TAROT_CARDS, 3)
        positions = ["🕰️ Past", "⚡ Present", "🌟 Future"]
        embed = nextcord.Embed(
            title="🃏 Three Card Spread",
            description=f"*{question}*" if question else None,
            color=0x9B59B6,
        )
        for (pos, (card, emoji, meaning)) in zip(positions, drawn):
            reversed_card = random.random() < 0.25
            embed.add_field(
                name=f"{pos} — {emoji} {card}" + (" (R)" if reversed_card else ""),
                value=meaning,
                inline=False,
            )
        embed.set_footer(text="✨ Three card spread")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope fortune ────────────────────────────────────────────────────
    @horoscope.subcommand(name="fortune", description="Crack open a fortune cookie")
    async def fortune(self, interaction: nextcord.Interaction):
        lang   = await self._lang(interaction.guild_id)
        fortune = random.choice(FORTUNE_COOKIES)
        lucky   = random.randint(1, 99)
        embed   = nextcord.Embed(
            title=t(lang,"hs_fortune_title"),
            description=f"*\"{fortune}\"*",
            color=0xFFD700,
        )
        embed.add_field(name=t(lang,"hs_lucky_num"), value=str(lucky))
        await interaction.response.send_message(embed=embed)

    # ── /horoscope ask ────────────────────────────────────────────────────────
    @horoscope.subcommand(name="ask", description="Ask the stars a yes/no question")
    async def ask(
        self,
        interaction: nextcord.Interaction,
        question: str = SlashOption(description="Your yes/no question"),
    ):
        answer, colour, detail = random.choice(YES_NO_ANSWERS)
        embed = nextcord.Embed(
            title=f"🔮 {answer}",
            description=f"*\"{question}\"*",
            color=colour,
        )
        embed.add_field(name="✨ The Stars Say", value=detail)
        embed.set_footer(text="For guidance only 🌸")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope compatibility ───────────────────────────────────────────────
    @horoscope.subcommand(name="compatibility", description="Check star sign compatibility")
    async def compatibility(
        self,
        interaction: nextcord.Interaction,
        sign1: str = SlashOption(description="First sign", choices=SIGNS),
        sign2: str = SlashOption(description="Second sign", choices=SIGNS),
    ):
        lang = await self._lang(interaction.guild_id)
        e1, e2 = ELEMENT_OF[sign1], ELEMENT_OF[sign2]
        HARMONIOUS = {("fire","air"),("earth","water")}
        same = sign1 == sign2
        same_elem = e1 == e2
        pair = (e1,e2)
        if same:
            pct, verdict, detail = 75, "High ✨", "Two of the same sign — deep understanding, but may amplify flaws."
        elif same_elem:
            pct, verdict, detail = 88, "Very High 💞", f"Both {e1} signs — shared values and energy. A natural bond."
        elif pair in HARMONIOUS or (pair[1],pair[0]) in HARMONIOUS:
            pct, verdict, detail = 82, "Strong 💛", f"{e1.title()} and {e2.title()} complement each other beautifully."
        else:
            pct, verdict, detail = random.randint(45,65), "Moderate 🌸", "Growth comes from contrast — patience and understanding needed."
        bar = "█"*(pct//10) + "░"*(10-pct//10)
        embed = nextcord.Embed(
            title=f"{SIGN_EMOJI[sign1]} {sign1.title()} × {SIGN_EMOJI[sign2]} {sign2.title()}",
            color=0xFF91A4,
        )
        embed.add_field(name=t(lang,"hs_compatibility"), value=f"`{bar}` **{pct}%** — {verdict}", inline=False)
        embed.add_field(name=t(lang,"hs_elements"), value=f"{ELEMENT_EMOJI[e1]} {e1.title()} × {ELEMENT_EMOJI[e2]} {e2.title()}", inline=True)
        embed.add_field(name=t(lang,"hs_reading"), value=detail, inline=False)
        await interaction.response.send_message(embed=embed)

    # ── /horoscope element ────────────────────────────────────────────────────
    @horoscope.subcommand(name="element", description="Learn about your element and its traits")
    async def element(
        self,
        interaction: nextcord.Interaction,
        sign: str = SlashOption(description="Your star sign", choices=SIGNS),
    ):
        elem = ELEMENT_OF[sign]
        modal = MODALITY_OF[sign]
        compatible = [s for s in SIGNS if ELEMENT_OF[s] == elem and s != sign]
        harmonious_elem = {"fire":"air","air":"fire","earth":"water","water":"earth"}[elem]
        harmonious_signs = [s for s in SIGNS if ELEMENT_OF[s] == harmonious_elem]
        traits = {
            "fire":  "Passionate, energetic, spontaneous, inspiring, and sometimes impulsive.",
            "earth": "Grounded, practical, reliable, patient, and deeply loyal.",
            "air":   "Intellectual, communicative, curious, social, and adaptable.",
            "water": "Intuitive, emotional, empathetic, imaginative, and deeply feeling.",
        }
        embed = nextcord.Embed(
            title=f"{ELEMENT_EMOJI[elem]} {elem.title()} Element — {sign.title()}",
            color=0xFF91A4,
        )
        embed.add_field(name="🌟 Element Traits", value=traits[elem], inline=False)
        embed.add_field(name="🔄 Modality",        value=modal.title(), inline=True)
        embed.add_field(name="🪐 Ruling Planet",   value=RULING_PLANETS[sign], inline=True)
        embed.add_field(name="💫 Keywords",        value=SIGN_KEYWORDS[sign], inline=False)
        embed.add_field(name="🤝 Same Element",    value=", ".join(s.title() for s in compatible), inline=False)
        embed.add_field(name="💞 Most Harmonious", value=", ".join(s.title() for s in harmonious_signs), inline=False)
        await interaction.response.send_message(embed=embed)

    # ── /horoscope numerology ─────────────────────────────────────────────────
    @horoscope.subcommand(name="numerology", description="Find your numerology life path number")
    async def numerology(
        self,
        interaction: nextcord.Interaction,
        birthday: str = SlashOption(description="Your birthday (DD/MM/YYYY)"),
    ):
        try:
            parts = birthday.replace("-","/").replace(".","/").split("/")
            total = sum(int(d) for n in parts for d in str(int(n)))
            while total > 9 and total not in (11,22,33):
                total = sum(int(d) for d in str(total))
        except Exception:
            await interaction.response.send_message(embed=nextcord.Embed(
                description="❌ Invalid date. Use DD/MM/YYYY", color=0xFF4444
            ))
            return
        meanings = {
            1:("The Leader",    "Independent, driven, pioneering. You carve your own path."),
            2:("The Peacemaker","Intuitive, cooperative, diplomatic. You bring harmony."),
            3:("The Creator",   "Expressive, social, optimistic. You inspire others."),
            4:("The Builder",   "Practical, disciplined, reliable. You create lasting things."),
            5:("The Explorer",  "Adventurous, free-spirited, adaptable. You crave experience."),
            6:("The Nurturer",  "Caring, responsible, protective. You heal those around you."),
            7:("The Seeker",    "Analytical, spiritual, introspective. You seek deeper truth."),
            8:("The Achiever",  "Ambitious, authoritative. Power and material success are your lessons."),
            9:("The Humanitarian","Compassionate, generous, idealistic. You serve the greater good."),
            11:("The Intuitive","Master number — highly sensitive, visionary, inspiring."),
            22:("The Master Builder","Master number — capable of turning grand dreams into reality."),
            33:("The Master Teacher","Master number — devoted to uplifting all of humanity."),
        }
        title, desc = meanings.get(total, ("Unknown","This is a rare and powerful path."))
        embed = nextcord.Embed(
            title=f"🔢 Life Path **{total}** — {title}",
            description=desc,
            color=0x9B59B6,
        )
        embed.set_footer(text="Numerology is for fun — your path is yours to write 🌸")
        await interaction.response.send_message(embed=embed)

    # ── /horoscope birthchart ─────────────────────────────────────────────────
    @horoscope.subcommand(name="birthchart", description="Get a mini birth chart reading")
    async def birthchart(
        self,
        interaction: nextcord.Interaction,
        sun_sign:   str = SlashOption(description="Your sun sign (when you were born)", choices=SIGNS),
        moon_sign:  str = SlashOption(description="Your moon sign (your inner self)", choices=SIGNS),
        rising_sign:str = SlashOption(description="Your rising sign (how others see you)", choices=SIGNS),
    ):
        sun_elem   = ELEMENT_OF[sun_sign]
        moon_elem  = ELEMENT_OF[moon_sign]
        rise_elem  = ELEMENT_OF[rising_sign]
        dominant   = max(set([sun_elem,moon_elem,rise_elem]),
                         key=[sun_elem,moon_elem,rise_elem].count)
        embed = nextcord.Embed(
            title="🌌 Mini Birth Chart",
            color=0x9B59B6,
        )
        embed.add_field(
            name=f"☀️ Sun in {sun_sign.title()} {SIGN_EMOJI[sun_sign]}",
            value=f"Your core identity and ego\n*{SIGN_KEYWORDS[sun_sign]}*",
            inline=False,
        )
        embed.add_field(
            name=f"🌙 Moon in {moon_sign.title()} {SIGN_EMOJI[moon_sign]}",
            value=f"Your emotions and inner world\n*{SIGN_KEYWORDS[moon_sign]}*",
            inline=False,
        )
        embed.add_field(
            name=f"⬆️ Rising in {rising_sign.title()} {SIGN_EMOJI[rising_sign]}",
            value=f"How others perceive you\n*{SIGN_KEYWORDS[rising_sign]}*",
            inline=False,
        )
        embed.add_field(
            name=f"{ELEMENT_EMOJI[dominant]} Dominant Element",
            value=f"**{dominant.title()}** — this energy shapes your whole chart.",
            inline=False,
        )
        await interaction.response.send_message(embed=embed)

    # ── /horoscope affinity ───────────────────────────────────────────────────
    @horoscope.subcommand(name="affinity", description="Find which signs you get along with most")
    async def affinity(
        self,
        interaction: nextcord.Interaction,
        sign: str = SlashOption(description="Your star sign", choices=SIGNS),
    ):
        elem  = ELEMENT_OF[sign]
        modal = MODALITY_OF[sign]
        HARMONIOUS_ELEM = {"fire":"air","air":"fire","earth":"water","water":"earth"}
        harm_elem  = HARMONIOUS_ELEM[elem]
        same_elem  = [s for s in SIGNS if ELEMENT_OF[s] == elem and s != sign]
        harm_signs = [s for s in SIGNS if ELEMENT_OF[s] == harm_elem]
        same_modal = [s for s in SIGNS if MODALITY_OF[s] == modal and s != sign]
        challenging = [s for s in SIGNS
                       if ELEMENT_OF[s] not in (elem, harm_elem) and s != sign][:3]
        embed = nextcord.Embed(
            title=f"{SIGN_EMOJI[sign]} {sign.title()} — Sign Affinity",
            color=0xFF91A4,
        )
        embed.add_field(
            name=f"💞 Most Compatible ({harm_elem.title()} signs)",
            value=", ".join(f"{SIGN_EMOJI[s]} {s.title()}" for s in harm_signs),
            inline=False,
        )
        embed.add_field(
            name=f"🤝 Same Element ({elem.title()})",
            value=", ".join(f"{SIGN_EMOJI[s]} {s.title()}" for s in same_elem),
            inline=False,
        )
        embed.add_field(
            name=f"🔄 Same Modality ({modal.title()})",
            value=", ".join(f"{SIGN_EMOJI[s]} {s.title()}" for s in same_modal),
            inline=False,
        )
        embed.add_field(
            name="⚡ Challenging (but growth-producing)",
            value=", ".join(f"{SIGN_EMOJI[s]} {s.title()}" for s in challenging),
            inline=False,
        )
        await interaction.response.send_message(embed=embed)

    # ── /horoscope signs ──────────────────────────────────────────────────────
    @horoscope.subcommand(name="signs", description="View all star signs and their dates")
    async def signs(self, interaction: nextcord.Interaction):
        lang = await self._lang(interaction.guild_id)
        embed = nextcord.Embed(title=t(lang,"hs_signs_title"), color=0xFF91A4)
        embed.description = "\n".join(
            f"{SIGN_EMOJI[s]} **{s.title()}** — {SIGN_DATES[s]} | {ELEMENT_EMOJI[ELEMENT_OF[s]]} {ELEMENT_OF[s].title()}"
            for s in SIGNS
        )
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(HoroscopeCog(bot))
