"""
DeepSeek AI chat cog for Rosé bot.
Uses DeepSeek API (OpenAI-compatible) — get key at platform.deepseek.com
Free tier: generous token allowance
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiohttp
import os
from utils.helpers import error_embed, premium_embed

DEEPSEEK_KEY = os.getenv("DEEPSEEK_API_KEY", "")
BASE_URL     = "https://api.deepseek.com/v1/chat/completions"
MODEL        = "deepseek-chat"

FREE_LIMIT    = 10   # messages per day
PREMIUM_LIMIT = 50

SYSTEM_PROMPT = (
    "You are Rosé, a warm, cozy, and cheerful AI companion on Discord. "
    "You speak in a friendly, conversational tone — like a caring friend. "
    "Keep responses concise (2-4 sentences unless asked for more). "
    "You love tea, music, and helping people feel welcome. "
    "If someone seems upset, be gentle and supportive. "
    "You are NOT ChatGPT or Claude — you are Rosé, a unique bot. "
    "Never say you can't do something — just guide them kindly."
)

class AICog(commands.Cog):
    def __init__(self, bot):
        self.bot  = bot
        self._used: dict = {}        # {user_id: (date, count)}
        self._memory: dict = {}      # {user_id: [messages]} — premium only

    def _today(self):
        import datetime
        return datetime.date.today().isoformat()

    def _check(self, uid, premium):
        limit = PREMIUM_LIMIT if premium else FREE_LIMIT
        entry = self._used.get(uid)
        today = self._today()
        used  = entry[1] if entry and entry[0]==today else 0
        return used < limit, limit-used

    def _bump(self, uid):
        today = self._today()
        entry = self._used.get(uid)
        used  = (entry[1] if entry and entry[0]==today else 0) + 1
        self._used[uid] = (today, used)

    async def _call_deepseek(self, messages: list) -> str | None:
        if not DEEPSEEK_KEY:
            return None
        headers = {"Authorization": f"Bearer {DEEPSEEK_KEY}", "Content-Type": "application/json"}
        payload = {"model": MODEL, "messages": messages, "max_tokens": 400, "temperature": 0.8}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(BASE_URL, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as r:
                    if r.status != 200:
                        return None
                    data = await r.json()
                    return data["choices"][0]["message"]["content"].strip()
        except:
            return None

    @nextcord.slash_command(name="ai", description="🤖 Chat with Rosé AI (powered by DeepSeek)")
    async def ai(self, interaction: nextcord.Interaction):
        pass

    @ai.subcommand(name="chat", description="Chat with Rosé AI")
    async def chat(self, interaction: nextcord.Interaction,
                   message: str = SlashOption(description="What do you want to say?")):
        premium = interaction.user.id in self.bot.premium_users or interaction.guild_id in self.bot.premium_guilds
        allowed, remaining = self._check(interaction.user.id, premium)
        if not allowed:
            await interaction.response.send_message(embed=error_embed(
                f"Daily AI limit reached! {'Premium: 50/day' if premium else 'Free: 10/day — upgrade on [Patreon](https://patreon.com/katsioon) for 50/day!'}"
            )); return
        if not DEEPSEEK_KEY:
            await interaction.response.send_message(embed=error_embed(
                "No DeepSeek API key! Add `DEEPSEEK_API_KEY` to `.env`.\nGet a free key at [platform.deepseek.com](https://platform.deepseek.com)"
            )); return
        await interaction.response.defer()
        uid = interaction.user.id
        # Build message history (premium = memory, free = single turn)
        if premium:
            history = self._memory.get(uid, [])
            history.append({"role":"user","content":message})
            if len(history) > 20:
                history = history[-20:]
        else:
            history = [{"role":"user","content":message}]
        full_messages = [{"role":"system","content":SYSTEM_PROMPT}] + history
        reply = await self._call_deepseek(full_messages)
        if not reply:
            await interaction.followup.send(embed=error_embed("DeepSeek API failed. Try again in a moment!")); return
        self._bump(uid)
        if premium:
            history.append({"role":"assistant","content":reply})
            self._memory[uid] = history
        _, remaining = self._check(uid, premium)
        embed = nextcord.Embed(description=f"**{interaction.user.display_name}:** {message}\n\n**Rosé:** {reply}", color=0xFF91A4)
        embed.set_footer(text=f"{'⭐ Premium · memory active' if premium else f'Free · {remaining} msgs left today'} · DeepSeek AI")
        await interaction.followup.send(embed=embed)

    @ai.subcommand(name="ask", description="Ask Rosé a quick question")
    async def ask(self, interaction: nextcord.Interaction,
                  question: str = SlashOption(description="Your question")):
        premium = interaction.user.id in self.bot.premium_users or interaction.guild_id in self.bot.premium_guilds
        allowed, _ = self._check(interaction.user.id, premium)
        if not allowed:
            await interaction.response.send_message(embed=error_embed("Daily limit reached!")); return
        if not DEEPSEEK_KEY:
            await interaction.response.send_message(embed=error_embed("No DeepSeek API key configured.")); return
        await interaction.response.defer()
        reply = await self._call_deepseek([
            {"role":"system","content":SYSTEM_PROMPT},
            {"role":"user","content":question}
        ])
        if not reply:
            await interaction.followup.send(embed=error_embed("AI request failed. Try again!")); return
        self._bump(interaction.user.id)
        embed = nextcord.Embed(title="🤖 Rosé Says...", description=reply, color=0xFF91A4)
        embed.set_footer(text=f"Powered by DeepSeek · {question[:80]}")
        await interaction.followup.send(embed=embed)

    @ai.subcommand(name="roast", description="Get gently roasted by Rosé 🔥")
    async def roast(self, interaction: nextcord.Interaction,
                    user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        allowed, _ = self._check(interaction.user.id, True)  # use no limit for fun cmd
        if not DEEPSEEK_KEY:
            await interaction.response.send_message(embed=error_embed("No AI key configured.")); return
        await interaction.response.defer()
        reply = await self._call_deepseek([
            {"role":"system","content":"You are Rosé, a playful Discord bot. Write a funny, lighthearted roast in 2 sentences. Be creative but never mean-spirited or offensive."},
            {"role":"user","content":f"Roast {target.display_name} in a gentle, funny way."}
        ])
        if not reply:
            await interaction.followup.send(embed=error_embed("AI hiccup! Try again.")); return
        embed = nextcord.Embed(title=f"🔥 Roasting {target.display_name}...", description=reply, color=0xFF6B35)
        embed.set_thumbnail(url=target.display_avatar.url)
        await interaction.followup.send(embed=embed)

    @ai.subcommand(name="clear", description="Clear your AI memory (Premium)")
    async def clear(self, interaction: nextcord.Interaction):
        premium = interaction.user.id in self.bot.premium_users
        if not premium:
            await interaction.response.send_message(embed=premium_embed("AI Memory")); return
        self._memory.pop(interaction.user.id, None)
        await interaction.response.send_message(embed=nextcord.Embed(description="🧹 Memory cleared!", color=0x57F287))

    @ai.subcommand(name="usage", description="Check your AI usage today")
    async def usage(self, interaction: nextcord.Interaction):
        premium = interaction.user.id in self.bot.premium_users or interaction.guild_id in self.bot.premium_guilds
        limit = PREMIUM_LIMIT if premium else FREE_LIMIT
        entry = self._used.get(interaction.user.id)
        used  = entry[1] if entry and entry[0]==self._today() else 0
        bar   = "█"*int(used/limit*10) + "░"*(10-int(used/limit*10))
        embed = nextcord.Embed(
            title="🤖 AI Usage",
            description=f"`{bar}` **{used}/{limit}** messages today\n\n{'⭐ Premium — 50/day' if premium else 'Free — 10/day · [Patreon](https://patreon.com/katsioon) for 50/day'}",
            color=0xFF91A4,
        )
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(AICog(bot))
