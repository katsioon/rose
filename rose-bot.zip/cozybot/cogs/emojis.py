"""
Emoji management for Rosé bot.
/emoji steal - steal from any server by emoji ID or name
/emoji add   - add emoji from URL or attachment
/emoji delete - remove server emoji
/emoji list  - list server emojis
/emoji info  - info about an emoji
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiohttp
import re
from utils.helpers import error_embed, success_embed, info_embed

EMOJI_RE = re.compile(r"<a?:(\w+):(\d+)>")

class EmojiCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _download(self, url: str) -> bytes | None:
        async with aiohttp.ClientSession() as s:
            async with s.get(url, timeout=aiohttp.ClientTimeout(total=10)) as r:
                if r.status == 200:
                    return await r.read()
        return None

    @nextcord.slash_command(name="emoji", description="😄 Emoji management tools")
    async def emoji(self, interaction: nextcord.Interaction):
        pass

    def _require_manage_emojis(self, interaction):
        return interaction.user.guild_permissions.manage_emojis

    @emoji.subcommand(name="steal", description="Copy an emoji from any server into yours")
    async def steal(self, interaction: nextcord.Interaction,
                    emoji_str: str = SlashOption(description="Paste the emoji (e.g. <:name:id>) or just the emoji ID"),
                    name: str = SlashOption(description="Name to give it (optional)", required=False)):
        if not self._require_manage_emojis(interaction):
            await interaction.response.send_message(embed=error_embed("You need **Manage Emojis** permission.")); return

        # Parse emoji mention or raw ID
        match = EMOJI_RE.search(emoji_str)
        if match:
            animated = emoji_str.startswith("<a:")
            emoji_name = name or match.group(1)
            emoji_id = match.group(2)
        elif emoji_str.strip().isdigit():
            emoji_id = emoji_str.strip()
            emoji_name = name or f"emoji_{emoji_id}"
            animated = False  # Try static first, fallback to gif
        else:
            await interaction.response.send_message(embed=error_embed(
                "Paste the emoji directly (e.g. `<:catjam:12345>`) or provide its numeric ID."
            )); return

        await interaction.response.defer()

        # Try animated then static
        for ext, anim in ([("gif", True), ("png", False)] if not match else [("gif" if animated else "png", animated)]):
            url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{ext}"
            data = await self._download(url)
            if data:
                try:
                    new_emoji = await interaction.guild.create_custom_emoji(name=emoji_name, image=data)
                    embed = success_embed(f"Emoji **:{new_emoji.name}:** added! {new_emoji}")
                    await interaction.followup.send(embed=embed)
                    return
                except nextcord.Forbidden:
                    await interaction.followup.send(embed=error_embed("I need **Manage Emojis** permission in this server.")); return
                except nextcord.HTTPException as e:
                    await interaction.followup.send(embed=error_embed(f"Failed to add emoji: {e}")); return

        await interaction.followup.send(embed=error_embed("Could not find that emoji. Make sure the ID is correct."))

    @emoji.subcommand(name="add", description="Add an emoji from a URL or attachment")
    async def add(self, interaction: nextcord.Interaction,
                  name: str = SlashOption(description="Name for the emoji"),
                  url: str = SlashOption(description="Image URL (or attach an image below)", required=False),
                  attachment: nextcord.Attachment = SlashOption(description="Upload an image", required=False)):
        if not self._require_manage_emojis(interaction):
            await interaction.response.send_message(embed=error_embed("You need **Manage Emojis** permission.")); return
        await interaction.response.defer()
        name = name.replace(" ", "_")[:32]
        src = url or (attachment.url if attachment else None)
        if not src:
            await interaction.followup.send(embed=error_embed("Provide a URL or attach an image.")); return
        data = await self._download(src)
        if not data:
            await interaction.followup.send(embed=error_embed("Could not download the image.")); return
        try:
            new_emoji = await interaction.guild.create_custom_emoji(name=name, image=data)
            await interaction.followup.send(embed=success_embed(f"Added emoji **:{new_emoji.name}:** {new_emoji}"))
        except nextcord.Forbidden:
            await interaction.followup.send(embed=error_embed("I need **Manage Emojis** permission."))
        except nextcord.HTTPException as e:
            await interaction.followup.send(embed=error_embed(f"Failed: {e}"))

    @emoji.subcommand(name="delete", description="Delete a server emoji")
    async def delete(self, interaction: nextcord.Interaction,
                     name: str = SlashOption(description="Name of the emoji to delete")):
        if not self._require_manage_emojis(interaction):
            await interaction.response.send_message(embed=error_embed("You need **Manage Emojis** permission.")); return
        target = nextcord.utils.get(interaction.guild.emojis, name=name)
        if not target:
            await interaction.response.send_message(embed=error_embed(f"No emoji named `:{name}:` found.")); return
        await target.delete(reason=f"Deleted by {interaction.user}")
        await interaction.response.send_message(embed=success_embed(f"Deleted `:{name}:`"))

    @emoji.subcommand(name="list", description="List all emojis in this server")
    async def list_emojis(self, interaction: nextcord.Interaction):
        emojis = interaction.guild.emojis
        if not emojis:
            await interaction.response.send_message(embed=info_embed("😄 Server Emojis", "No custom emojis yet!")); return
        static   = [str(e) for e in emojis if not e.animated]
        animated = [str(e) for e in emojis if e.animated]
        embed = nextcord.Embed(title=f"😄 {interaction.guild.name} Emojis ({len(emojis)})", color=0xFFD700)
        if static:   embed.add_field(name=f"Static ({len(static)})",   value=" ".join(static[:30])   or "—", inline=False)
        if animated: embed.add_field(name=f"Animated ({len(animated)})",value=" ".join(animated[:30]) or "—", inline=False)
        await interaction.response.send_message(embed=embed)

    @emoji.subcommand(name="info", description="Get info about an emoji")
    async def info_cmd(self, interaction: nextcord.Interaction,
                       emoji_str: str = SlashOption(description="The emoji (paste it)")):
        match = EMOJI_RE.search(emoji_str)
        if not match:
            await interaction.response.send_message(embed=error_embed("Paste a custom emoji (e.g. `<:name:id>`)")); return
        animated = emoji_str.startswith("<a:")
        name, eid = match.group(1), match.group(2)
        url = f"https://cdn.discordapp.com/emojis/{eid}.{'gif' if animated else 'png'}"
        embed = nextcord.Embed(title=f":{name}:", color=0xFF91A4)
        embed.add_field(name="ID",       value=eid,                        inline=True)
        embed.add_field(name="Animated", value="Yes" if animated else "No", inline=True)
        embed.add_field(name="URL",      value=f"[Click]({url})",           inline=True)
        embed.set_thumbnail(url=url)
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(EmojiCog(bot))
