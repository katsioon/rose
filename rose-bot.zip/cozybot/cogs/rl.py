"""
RL Resources cog - curated reinforcement learning resource library
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
from utils.helpers import error_embed, success_embed, info_embed, premium_embed, RL_CATEGORIES

SEED_RESOURCES = [
    ("Spinning Up in Deep RL", "https://spinningup.openai.com", "courses",
     "OpenAI's hands-on introduction to deep reinforcement learning with implementations."),
    ("Sutton & Barto (RL Bible)", "http://incompleteideas.net/book/the-book-2nd.html", "fundamentals",
     "The definitive textbook: Reinforcement Learning: An Introduction. Free online."),
    ("Stable Baselines3", "https://stable-baselines3.readthedocs.io", "tools",
     "Reliable PyTorch implementations of RL algorithms (PPO, SAC, TD3, DQN...)."),
    ("DeepMind RL Lecture Series", "https://www.youtube.com/playlist?list=PLqYmG7hTraZDVH599EItlEWsUOsJbAodm", "videos",
     "Comprehensive lecture series from DeepMind covering modern RL."),
    ("RL Course by David Silver", "https://www.youtube.com/playlist?list=PLqYmG7hTraZDM-OYHWgPebj2MfCFzFObQ", "courses",
     "Classic UCL course by David Silver, one of the best foundational RL courses."),
    ("CleanRL", "https://github.com/vwxyzjn/cleanrl", "tools",
     "Single-file RL algorithm implementations. Great for learning and research."),
    ("Gymnasium", "https://gymnasium.farama.org", "tools",
     "The standard API for RL environments (formerly OpenAI Gym)."),
    ("PPO Paper", "https://arxiv.org/abs/1707.06347", "papers",
     "Proximal Policy Optimization Algorithms by Schulman et al. (2017)."),
    ("SAC Paper", "https://arxiv.org/abs/1801.01290", "papers",
     "Soft Actor-Critic: Off-Policy Maximum Entropy Deep RL."),
    ("Hugging Face Deep RL Course", "https://huggingface.co/learn/deep-rl-course", "courses",
     "Free, hands-on deep RL course with certificates. Highly recommended for beginners."),
    ("RL Discord", "https://discord.gg/xhfNqQv", "blogs",
     "Active community of RL researchers and practitioners."),
    ("PettingZoo", "https://pettingzoo.farama.org", "tools",
     "Multi-agent RL environments. The Gymnasium for MARL."),
    ("Minari", "https://minari.farama.org", "datasets",
     "Standard dataset format and storage for offline RL."),
    ("Weights & Biases RL Guide", "https://wandb.ai/site/articles/reinforcement-learning", "blogs",
     "Practical guides for tracking and debugging RL experiments."),
]

class RLCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await self._seed_resources()

    async def _seed_resources(self):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT COUNT(*) FROM rl_resources") as cur:
                count = (await cur.fetchone())[0]
            if count == 0:
                await db.executemany(
                    "INSERT INTO rl_resources (title, url, category, description, added_by) VALUES (?,?,?,?,?)",
                    [(t, u, c, d, 0) for t, u, c, d in SEED_RESOURCES]
                )
                await db.commit()

    def _resource_embed(self, row, color=0x5865F2):
        rid, title, url, cat, desc, _, upvotes = row
        embed = nextcord.Embed(title=f"📚 {title}", url=url, description=desc, color=color)
        embed.add_field(name="Category", value=f"`{cat}`")
        embed.add_field(name="👍 Upvotes", value=str(upvotes))
        embed.set_footer(text=f"ID: {rid}")
        return embed

    @nextcord.slash_command(name="rl", description="📚 Reinforcement Learning resources")
    async def rl(self, interaction: nextcord.Interaction): pass

    @rl.subcommand(name="browse", description="Browse RL resources by category")
    async def rl_browse(
        self,
        interaction: nextcord.Interaction,
        category: str = SlashOption(description="Category", choices=RL_CATEGORIES, required=False),
        page: int = SlashOption(description="Page number", min_value=1, default=1)):
        per_page = 5
        offset = (page - 1) * per_page
        async with aiosqlite.connect(self.bot.db_path) as db:
            if category:
                async with db.execute(
                    "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources WHERE category=? ORDER BY upvotes DESC LIMIT ? OFFSET ?",
                    (category, per_page, offset)
                ) as cur:
                    rows = await cur.fetchall()
                async with db.execute("SELECT COUNT(*) FROM rl_resources WHERE category=?", (category)) as cur:
                    total = (await cur.fetchone())[0]
            else:
                async with db.execute(
                    "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources ORDER BY upvotes DESC LIMIT ? OFFSET ?",
                    (per_page, offset)
                ) as cur:
                    rows = await cur.fetchall()
                async with db.execute("SELECT COUNT(*) FROM rl_resources") as cur:
                    total = (await cur.fetchone())[0]

        if not rows:
            await interaction.response.send_message(embed=info_embed("📚 RL Resources", "No resources found."))
            return

        cat_str = f" [{category}]" if category else ""
        desc = ""
        for row in rows:
            rid, title, url, cat, rdesc, _, upvotes = row
            desc += f"**[{title}]({url})** `{cat}` 👍{upvotes}\n{rdesc[:80]}...\n\n"

        embed = nextcord.Embed(
            title=f"📚 RL Resources{cat_str}",
            description=desc,
            color=0x5865F2
        )
        total_pages = (total + per_page - 1) // per_page
        embed.set_footer(text=f"Page {page}/{total_pages} • {total} total resources")
        await interaction.response.send_message(embed=embed)

    @rl.subcommand(name="random", description="Get a random RL resource")
    async def rl_random(
        self,
        interaction: nextcord.Interaction,
        category: str = SlashOption(description="Category filter", choices=RL_CATEGORIES, required=False)):
        async with aiosqlite.connect(self.bot.db_path) as db:
            if category:
                async with db.execute(
                    "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources WHERE category=? ORDER BY RANDOM() LIMIT 1",
                    (category)
                ) as cur:
                    row = await cur.fetchone()
            else:
                async with db.execute(
                    "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources ORDER BY RANDOM() LIMIT 1"
                ) as cur:
                    row = await cur.fetchone()
        if not row:
            await interaction.response.send_message(embed=error_embed("No resources found!"))
            return
        await interaction.response.send_message(embed=self._resource_embed(row))

    @rl.subcommand(name="search", description="Search RL resources")
    async def rl_search(self, interaction: nextcord.Interaction, query: str = SlashOption(description="Search query")):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources WHERE title LIKE ? OR description LIKE ? ORDER BY upvotes DESC LIMIT 5",
                (f"%{query}%", f"%{query}%")
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=error_embed(f"No results for `{query}`"))
            return
        desc = ""
        for row in rows:
            rid, title, url, cat, rdesc, _, upvotes = row
            desc += f"**[{title}]({url})** `{cat}` 👍{upvotes}\n{rdesc[:80]}...\n\n"
        await interaction.response.send_message(embed=info_embed(f"🔍 Results for '{query}'", desc))

    @rl.subcommand(name="upvote", description="Upvote an RL resource")
    async def rl_upvote(self, interaction: nextcord.Interaction, resource_id: int = SlashOption(description="Resource ID")):
        async with aiosqlite.connect(self.bot.db_path) as db:
            try:
                await db.execute("INSERT INTO rl_votes (user_id, resource_id) VALUES (?,?)", (interaction.user.id, resource_id))
                await db.execute("UPDATE rl_resources SET upvotes=upvotes+1 WHERE id=?", (resource_id))
                await db.commit()
                await interaction.response.send_message(embed=success_embed(f"Upvoted resource #{resource_id}!"))
            except:
                await interaction.response.send_message(embed=error_embed("Already voted on this resource!"))

    @rl.subcommand(name="submit", description="Submit an RL resource (Premium)")
    async def rl_submit(
        self,
        interaction: nextcord.Interaction,
        title: str = SlashOption(description="Resource title"),
        url: str = SlashOption(description="Resource URL"),
        category: str = SlashOption(description="Category", choices=RL_CATEGORIES),
        description: str = SlashOption(description="Short description")):
        if interaction.user.id not in self.bot.premium_users and interaction.guild_id not in self.bot.premium_guilds:
            await interaction.response.send_message(embed=premium_embed("Resource Submission"))
            return
        if not url.startswith("http"):
            await interaction.response.send_message(embed=error_embed("Invalid URL!"))
            return
        async with aiosqlite.connect(self.bot.db_path) as db:
            cur = await db.execute(
                "INSERT INTO rl_resources (title, url, category, description, added_by) VALUES (?,?,?,?,?)",
                (title, url, category, description, interaction.user.id)
            )
            rid = cur.lastrowid
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Resource submitted! ID: #{rid}\nTitle: **{title}**"))

    @rl.subcommand(name="top", description="Top upvoted RL resources")
    async def rl_top(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT id, title, url, category, description, added_by, upvotes FROM rl_resources ORDER BY upvotes DESC LIMIT 10"
            ) as cur:
                rows = await cur.fetchall()
        medals = ["🥇", "🥈", "🥉"] + ["🔹"] * 7
        desc = ""
        for i, (rid, title, url, cat, rdesc, _, upvotes) in enumerate(rows):
            desc += f"{medals[i]} **[{title}]({url})** `{cat}` — 👍{upvotes}\n"
        await interaction.response.send_message(embed=info_embed("🏆 Top RL Resources", desc))

    @rl.subcommand(name="roadmap", description="Get an RL learning roadmap")
    async def rl_roadmap(
        self,
        interaction: nextcord.Interaction,
        level: str = SlashOption(description="Your level", choices=["beginner", "intermediate", "advanced"])):
        roadmaps = {
            "beginner": """**🌱 Beginner RL Roadmap**
1. **Python & Math Basics** — NumPy, Linear Algebra, Calculus, Probability
2. **RL Fundamentals** — Sutton & Barto Ch. 1-6 (MDPs, Bellman, TD learning)
3. **David Silver's Course** — UCL RL lectures (free on YouTube)
4. **OpenAI Spinning Up** — Hands-on intro with implementations
5. **First Project** — Train an agent on CartPole or LunarLander
6. **Hugging Face RL Course** — Modern, practical, certificate available""",
            "intermediate": """**🌿 Intermediate RL Roadmap**
1. **Deep RL Fundamentals** — DQN, Policy Gradients, Actor-Critic
2. **Stable Baselines3** — Use PPO, SAC, TD3 on custom environments
3. **CleanRL** — Read single-file implementations to understand internals
4. **Key Papers** — PPO, SAC, TD3, Rainbow DQN
5. **Custom Environments** — Build with Gymnasium
6. **Experiment Tracking** — W&B or TensorBoard
7. **Research Paper** — Reproduce a recent RL paper""",
            "advanced": """**🌳 Advanced RL Roadmap**
1. **MARL** — Multi-Agent RL with PettingZoo
2. **Offline RL** — Conservative Q-Learning, Decision Transformers
3. **Model-Based RL** — Dreamer, MuZero, MBPO
4. **Hierarchical RL** — Options Framework, HIRO
5. **RL + LLMs** — RLHF, Constitutional AI, GRPO
6. **Custom Research** — Novel environment or algorithm contribution
7. **Deployment** — RL in production, real-world robotics""",
        }
        await interaction.response.send_message(embed=info_embed(f"🗺️ RL Roadmap", roadmaps[level], 0x57F287))


def setup(bot):
    bot.add_cog(RLCog(bot))
