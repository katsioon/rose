"""
Cozy cog - mood boards, journal entries, vibes, affirmations, and cozy utilities
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
from utils.helpers import error_embed, success_embed, info_embed, now, MOODS

AFFIRMATIONS = [
    "You are capable of amazing things. 🌟",
    "Your efforts matter more than you know. 💛",
    "Every small step forward is still progress. 🐾",
    "You deserve rest as much as you deserve success. 🍵",
    "It's okay to take things one breath at a time. 🌿",
    "Your presence in the world makes a difference. 🌸",
    "You have overcome hard things before — you've got this. 💪",
    "Today is a new canvas. Paint it gently. 🎨",
    "You are allowed to be a work in progress. 🌱",
    "Kindness to yourself is never wasted. 🤍",
]

COZY_AESTHETICS = [
    "☕ rain on windows + warm mug + good book",
    "🕯️ candlelight + lo-fi beats + fuzzy blanket",
    "🌿 fresh plants + morning sunlight + herbal tea",
    "📚 library corner + autumn leaves + soft sweater",
    "🍵 matcha latte + journaling + cloudy afternoon",
    "🎶 vinyl records + dim lamp + rainy evening",
    "🌙 stargazing + cozy socks + chamomile tea",
    "🔥 fireplace + hot cocoa + favorite playlist",
]

class CozyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @nextcord.slash_command(name="cozy", description="🍵 Cozy corner commands")
    async def cozy(self, interaction: nextcord.Interaction): pass

    @cozy.subcommand(name="affirmation", description="Get a daily affirmation")
    async def cozy_affirmation(self, interaction: nextcord.Interaction):
        affirmation = random.choice(AFFIRMATIONS)
        embed = nextcord.Embed(
            title="🌸 Daily Affirmation",
            description=f"*{affirmation}*",
            color=0xFFB3C6)
        embed.set_footer(text="You've got this 💛")
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="vibe", description="Get a random cozy vibe")
    async def cozy_vibe(self, interaction: nextcord.Interaction):
        vibe = random.choice(COZY_AESTHETICS)
        embed = nextcord.Embed(
            title="✨ Today's Vibe",
            description=vibe,
            color=0xF4A261)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="mood", description="Log your mood")
    async def cozy_mood(
        self,
        interaction: nextcord.Interaction,
        mood: str = SlashOption(description="How are you feeling?", choices=list(MOODS.keys())),
        note: str = SlashOption(description="Optional note", required=False)):
        emoji = MOODS[mood]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO cozy_board (guild_id, user_id, content, mood) VALUES (?,?,?,?)",
                (interaction.guild_id, interaction.user.id, note or "", mood)
            )
            await db.commit()
        embed = nextcord.Embed(
            title=f"{emoji} Mood Logged",
            description=f"**{interaction.user.display_name}** is feeling **{mood}** {emoji}\n" + (f"\n*{note}*" if note else ""),
            color=0xFFB3C6)
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="mood_history", description="View your recent moods")
    async def cozy_mood_history(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT mood, content, created_at FROM cozy_board WHERE user_id=? ORDER BY created_at DESC LIMIT 10",
                (interaction.user.id)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("📊 Mood History", "No moods logged yet!"))
            return
        desc = ""
        for mood, note, ts in rows:
            emoji = MOODS.get(mood, "❓")
            note_str = f" — *{note}*" if note else ""
            desc += f"{emoji} **{mood}** <t:{ts}:R>{note_str}\n"
        embed = nextcord.Embed(
            title=f"📊 {interaction.user.display_name}'s Mood History",
            description=desc,
            color=0xFFB3C6)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="board", description="View the server mood board")
    async def cozy_board_cmd(self, interaction: nextcord.Interaction):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT user_id, mood, content, created_at FROM cozy_board WHERE guild_id=? ORDER BY created_at DESC LIMIT 15",
                (interaction.guild_id)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🌸 Mood Board", "Nothing here yet! Log a mood with `/cozy mood`"))
            return
        desc = ""
        for uid, mood, note, ts in rows:
            user = interaction.guild.get_member(uid)
            name = user.display_name if user else "Someone"
            emoji = MOODS.get(mood, "❓")
            note_str = f" — *{note[:40]}*" if note else ""
            desc += f"{emoji} **{name}** {mood}{note_str} <t:{ts}:R>\n"
        embed = nextcord.Embed(
            title=f"🌸 {interaction.guild.name} Mood Board",
            description=desc,
            color=0xFFB3C6)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="tea", description="What tea should you drink right now?")
    async def cozy_tea(self, interaction: nextcord.Interaction):
        teas = [
            ("Chamomile", "🌼", "Calming and soothing. Perfect for winding down.", "#FFF8DC"),
            ("Matcha", "🍵", "Energizing with a zen focus. Great for studying.", "#90EE90"),
            ("Earl Grey", "☕", "Classic and sophisticated. A timeless choice.", "#DEB887"),
            ("Peppermint", "🌿", "Refreshing and invigorating. Clears the mind.", "#98FB98"),
            ("Ginger", "🫚", "Warming and spicy. Perfect for cold days.", "#FFD700"),
            ("Oolong", "🍂", "Complex and floral. For adventurous tea drinkers.", "#D2691E"),
            ("Rooibos", "❤️", "Caffeine-free, naturally sweet, earthy and cozy.", "#CD5C5C"),
            ("Jasmine", "🌸", "Delicate and floral. Uplifting and serene.", "#FFB6C1"),
        ]
        name, emoji, desc, _ = random.choice(teas)
        embed = nextcord.Embed(
            title=f"{emoji} You should drink: **{name} Tea**",
            description=desc,
            color=0xF4A261)
        embed.set_footer(text="Remember to stay hydrated! 🍵")
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="playlist", description="Get a cozy playlist vibe recommendation")
    async def cozy_playlist(
        self,
        interaction: nextcord.Interaction,
        mood: str = SlashOption(description="Current mood", choices=list(MOODS.keys()), required=False)):
        playlists = {
            "happy": ("Sunny Indie Pop ☀️", "bright vocals, upbeat guitar, pure feel-good energy"),
            "calm": ("Lo-fi Chill Hop 🌙", "soft beats, ambient pads, no distractions"),
            "cozy": ("Cozy Coffee Shop Jazz ☕", "mellow piano, brushed drums, warm vibes"),
            "tired": ("Ambient Dreamscapes 💤", "drifting synths, gentle rain, ultra relaxing"),
            "excited": ("Hyperpop Energy ⚡", "high-energy, euphoric drops, pure hype"),
            "sad": ("Melancholic Indie 🌧️", "emotional lyrics, soft guitar, cathartic beauty"),
            "anxious": ("Nature Sounds & Binaural Beats 🌊", "gentle waves, grounding tones, breathing space"),
            "grateful": ("Feel-Good Soul 🌺", "warm harmonies, positive lyrics, heartwarming"),
            "creative": ("Cinematic Soundscapes 🎬", "orchestral swells, inspiring builds, epic focus"),
            "focused": ("Deep Work Instrumentals 🎯", "minimal beats, no lyrics, maximum focus"),
        }
        if mood and mood in playlists:
            name, desc = playlists[mood]
        else:
            name, desc = random.choice(list(playlists.values()))
        embed = nextcord.Embed(
            title=f"🎶 Playlist Vibe: {name}",
            description=f"*{desc}*\n\nSearch this vibe on Spotify, YouTube Music, or Apple Music!",
            color=0x1DB954)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="hug", description="Send a virtual hug to someone")
    async def cozy_hug(
        self,
        interaction: nextcord.Interaction,
        user: nextcord.Member = SlashOption(description="Who to hug")):
        hug_msgs = [
            f"🤗 {interaction.user.mention} sends a warm hug to {user.mention}!",
            f"💛 {interaction.user.mention} wraps {user.mention} in a cozy hug!",
            f"🌸 A big warm hug from {interaction.user.mention} to {user.mention}!",
        ]
        embed = nextcord.Embed(description=random.choice(hug_msgs), color=0xFFB3C6)
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="breathe", description="Guided breathing exercise for 4-7-8 relaxation")
    async def cozy_breathe(self, interaction: nextcord.Interaction):
        embed = nextcord.Embed(
            title="🌬️ Breathing Exercise — 4-7-8 Method",
            description=(
                "This technique helps calm anxiety and promote relaxation.\n\n"
                "**Inhale** through your nose for **4 seconds** 🌬️\n"
                "**Hold** your breath for **7 seconds** ⏸️\n"
                "**Exhale** completely through your mouth for **8 seconds** 💨\n\n"
                "Repeat 3-4 times. Take it slow. You've got this. 💛"
            ),
            color=0x87CEEB)
        embed.set_footer(text="Your wellbeing matters 🌸")
        await interaction.response.send_message(embed=embed)

    @cozy.subcommand(name="quote", description="Get an inspirational quote")
    async def cozy_quote(self, interaction: nextcord.Interaction):
        quotes = [
            ("The present moment is filled with joy and happiness. If you are attentive, you will see it.", "Thich Nhat Hanh"),
            ("Not all those who wander are lost.", "J.R.R. Tolkien"),
            ("In the middle of every difficulty lies opportunity.", "Albert Einstein"),
            ("Do what you can, with what you have, where you are.", "Theodore Roosevelt"),
            ("The secret of getting ahead is getting started.", "Mark Twain"),
            ("Simplicity is the ultimate sophistication.", "Leonardo da Vinci"),
            ("It always seems impossible until it is done.", "Nelson Mandela"),
            ("Be yourself; everyone else is already taken.", "Oscar Wilde"),
        ]
        quote, author = random.choice(quotes)
        embed = nextcord.Embed(
            description=f"*\"{quote}\"*\n\n— **{author}**",
            color=0xF4A261)
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(CozyCog(bot))
