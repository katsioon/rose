"""
Advanced RPG + Card Collection system for Rosé bot.
/rpg: profile, fight, dungeon, craft, inventory, equip, shop
/cards: draw, collection, trade, burn, set_info
"""
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import random
import time
from utils.helpers import error_embed, success_embed, info_embed

# ── Classes ────────────────────────────────────────────────────────────────────
CLASSES = {
    "warrior":  {"emoji":"⚔️","hp":120,"atk":15,"def":10,"spd":5},
    "mage":     {"emoji":"🔮","hp":80, "atk":25,"def":5, "spd":8},
    "rogue":    {"emoji":"🗡️","hp":90, "atk":20,"def":7, "spd":15},
    "paladin":  {"emoji":"🛡️","hp":130,"atk":12,"def":15,"spd":4},
    "ranger":   {"emoji":"🏹","hp":100,"atk":18,"def":8, "spd":12},
}

# ── Enemies ────────────────────────────────────────────────────────────────────
ENEMIES = [
    ("Goblin",      "👺", 40,  8,  2,  20,  5),
    ("Orc",         "👹", 80,  14, 5,  50,  12),
    ("Dragon",      "🐉", 200, 30, 15, 200, 50),
    ("Skeleton",    "💀", 55,  10, 3,  30,  8),
    ("Dark Knight", "🖤", 120, 22, 12, 120, 30),
    ("Slime",       "🟢", 30,  5,  1,  15,  4),
    ("Witch",       "🧙", 70,  20, 4,  60,  15),
    ("Troll",       "🧌", 150, 18, 10, 100, 25),
]  # name, emoji, hp, atk, def, xp, gold

DUNGEONS = [
    ("Goblin Cave",    1,  [0,3,5], 100, 25),
    ("Dark Forest",    5,  [1,4,6], 250, 60),
    ("Shadow Keep",    10, [4,7],   500, 120),
    ("Dragon's Lair",  20, [2,4,7], 1000,250),
]  # name, min_level, enemy_pool, xp, gold

# ── Cards ──────────────────────────────────────────────────────────────────────
CARD_RARITIES = {
    "common":    (0.55, "⬜", 0xAAAAAA, 1,   10),
    "uncommon":  (0.25, "🟩", 0x57F287, 2,   30),
    "rare":      (0.12, "🟦", 0x5865F2, 3,   80),
    "epic":      (0.06, "🟪", 0x9B59B6, 5,   200),
    "legendary": (0.02, "🟨", 0xFFD700, 10,  500),
}  # prob, marker, color, atk_bonus, sell_price

CARDS = [
    ("Rose Princess",  "legendary","🌸","A radiant princess who commands the flowers."),
    ("Storm Dragon",   "legendary","🐉","An ancient dragon born from thunder."),
    ("Moon Witch",     "epic","🌙","A witch who draws power from the moonlight."),
    ("Iron Golem",     "epic","🗿","Constructed from enchanted ore, indestructible."),
    ("Fox Spirit",     "rare","🦊","A cunning spirit who shapeshifts at will."),
    ("Crystal Mage",   "rare","💎","A mage who channels spells through gems."),
    ("Forest Elf",     "uncommon","🧝","A swift archer of the ancient woods."),
    ("Merchant",       "uncommon","🪙","A trader with connections everywhere."),
    ("Town Guard",     "common","⚔️","Faithful defender of the city gates."),
    ("Apprentice",     "common","📚","Just starting their magical journey."),
    ("Farmer",         "common","🌾","Simple folk with surprising resilience."),
    ("Wanderer",       "uncommon","🗺️","A traveler who has seen the whole world."),
    ("Shadow Thief",   "rare","👤","Steals from the rich, keeps it all."),
    ("Sea Serpent",    "epic","🐍","Terror of the deep ocean."),
    ("Angel Knight",   "legendary","👼","A divine warrior descended from the heavens."),
]

def _draw_rarity() -> str:
    r = random.random()
    cumulative = 0.0
    for rarity, (prob, *_) in CARD_RARITIES.items():
        cumulative += prob
        if r <= cumulative:
            return rarity
    return "common"

ITEMS = {
    "iron_sword":    {"name":"Iron Sword",    "emoji":"⚔️", "type":"weapon", "atk":10,  "price":100},
    "steel_armor":   {"name":"Steel Armor",   "emoji":"🛡️", "type":"armor",  "def":8,   "price":150},
    "health_potion": {"name":"Health Potion", "emoji":"🧪", "type":"consumable","hp":50,"price":50},
    "magic_staff":   {"name":"Magic Staff",   "emoji":"🔮", "type":"weapon", "atk":18,  "price":250},
    "shadow_cloak":  {"name":"Shadow Cloak",  "emoji":"🌑", "type":"armor",  "def":12,  "price":300},
    "mana_gem":      {"name":"Mana Gem",      "emoji":"💎", "type":"consumable","atk":15,"price":180},
    "dragon_scale":  {"name":"Dragon Scale",  "emoji":"🐉", "type":"armor",  "def":20,  "price":500},
    "legendary_bow": {"name":"Legendary Bow", "emoji":"🏹", "type":"weapon", "atk":25,  "price":600},
}

class RPGCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._fight_cd: dict = {}
        self._dungeon_cd: dict = {}
        self._draw_cd: dict = {}

    async def _get_char(self, guild_id, user_id):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT class,hp,max_hp,atk,def,spd,level,xp,gold,weapon,armor FROM rpg_chars WHERE guild_id=? AND user_id=?",
                (guild_id,user_id)
            ) as cur:
                return await cur.fetchone()

    async def _create_char(self, guild_id, user_id, cls):
        stats = CLASSES[cls]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT OR IGNORE INTO rpg_chars (guild_id,user_id,class,hp,max_hp,atk,def,spd) VALUES (?,?,?,?,?,?,?,?)",
                (guild_id,user_id,cls,stats["hp"],stats["hp"],stats["atk"],stats["def"],stats["spd"])
            )
            await db.commit()

    @nextcord.slash_command(name="rpg", description="⚔️ Advanced RPG game")
    async def rpg(self, interaction: nextcord.Interaction):
        pass

    @rpg.subcommand(name="start", description="Create your RPG character")
    async def start(self, interaction: nextcord.Interaction,
                    cls: str = SlashOption(description="Choose your class", choices={f"{v['emoji']} {k.title()}":k for k,v in CLASSES.items()})):
        existing = await self._get_char(interaction.guild_id, interaction.user.id)
        if existing:
            await interaction.response.send_message(embed=error_embed("You already have a character! Use `/rpg profile`.")); return
        await self._create_char(interaction.guild_id, interaction.user.id, cls)
        stats = CLASSES[cls]
        embed = nextcord.Embed(title=f"{stats['emoji']} Character Created!", color=0xFFD700)
        embed.description = f"Welcome, **{cls.title()}**! Your adventure begins.\n\n❤️ HP: {stats['hp']} · ⚔️ ATK: {stats['atk']} · 🛡️ DEF: {stats['def']} · ⚡ SPD: {stats['spd']}"
        await interaction.response.send_message(embed=embed)

    @rpg.subcommand(name="profile", description="View your RPG character")
    async def profile(self, interaction: nextcord.Interaction,
                      user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        row = await self._get_char(interaction.guild_id, target.id)
        if not row:
            await interaction.response.send_message(embed=error_embed(
                ("They don't have" if user else "You don't have") + " a character! Use `/rpg start`."
            )); return
        cls,hp,max_hp,atk,def_,spd,lvl,xp,gold,weapon,armor = row
        stats = CLASSES.get(cls, CLASSES["warrior"])
        hp_bar = "█"*int(hp/max_hp*10) + "░"*(10-int(hp/max_hp*10))
        embed = nextcord.Embed(title=f"{stats['emoji']} {target.display_name}", color=0xFF91A4)
        embed.add_field(name="Class",  value=cls.title(),   inline=True)
        embed.add_field(name="Level",  value=str(lvl),      inline=True)
        embed.add_field(name="Gold",   value=f"🪙 {gold:,}", inline=True)
        embed.add_field(name="❤️ HP",  value=f"`{hp_bar}` {hp}/{max_hp}", inline=False)
        embed.add_field(name="⚔️ ATK", value=str(atk),      inline=True)
        embed.add_field(name="🛡️ DEF", value=str(def_),     inline=True)
        embed.add_field(name="⚡ SPD", value=str(spd),      inline=True)
        if weapon: embed.add_field(name="Weapon", value=ITEMS.get(weapon,{}).get("name","?"), inline=True)
        if armor:  embed.add_field(name="Armor",  value=ITEMS.get(armor,{}).get("name","?"),  inline=True)
        embed.set_thumbnail(url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @rpg.subcommand(name="fight", description="Fight a random monster!")
    async def fight(self, interaction: nextcord.Interaction):
        row = await self._get_char(interaction.guild_id, interaction.user.id)
        if not row:
            await interaction.response.send_message(embed=error_embed("Create a character first! `/rpg start`")); return
        uid = interaction.user.id
        now = time.time()
        if now - self._fight_cd.get(uid,0) < 30:
            left = int(30 - (now - self._fight_cd[uid]))
            await interaction.response.send_message(embed=error_embed(f"Rest up! Fight again in **{left}s**.")); return
        self._fight_cd[uid] = now
        cls,hp,max_hp,atk,def_,spd,lvl,xp,gold,weapon,armor = row
        # Scale enemy to player level
        eligible = [e for e in ENEMIES if e[2] <= max(40, hp)]
        enemy = random.choice(eligible)
        ename,eemoji,ehp,eatk,edef,exp_reward,gold_reward = enemy
        # Simple battle simulation
        player_hp = hp
        battle_log = []
        rounds = 0
        while player_hp > 0 and ehp > 0 and rounds < 20:
            pdmg = max(1, atk - edef + random.randint(-3,5))
            edm  = max(1, eatk - def_ + random.randint(-3,5))
            if spd > 8: pdmg = int(pdmg * 1.2)  # speed bonus
            ehp -= pdmg
            if ehp > 0:
                player_hp -= edm
                if rounds < 3:
                    battle_log.append(f"You hit {eemoji} for **{pdmg}** · {eemoji} hits you for **{edm}**")
            rounds += 1
        won = ehp <= 0
        new_hp = max(1, player_hp) if won else max(1, hp // 2)
        earned_xp   = exp_reward if won else exp_reward // 4
        earned_gold = gold_reward if won else 0
        new_xp  = xp + earned_xp
        new_lvl = lvl
        while new_xp >= (new_lvl+1)*100:
            new_xp -= (new_lvl+1)*100
            new_lvl += 1
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE rpg_chars SET hp=?,level=?,xp=?,gold=gold+? WHERE guild_id=? AND user_id=?",
                             (new_hp,new_lvl,new_xp,earned_gold,interaction.guild_id,uid))
            await db.commit()
        color = 0x57F287 if won else 0xFF4444
        embed = nextcord.Embed(
            title=f"{'⚔️ Victory!' if won else '💀 Defeated!'} vs {eemoji} {ename}",
            description="\n".join(battle_log[:3]) + ("..." if len(battle_log)>3 else ""),
            color=color,
        )
        embed.add_field(name="Result",    value="Won! 🎉" if won else "Lost 😢",       inline=True)
        embed.add_field(name="XP Gained", value=f"+{earned_xp}",                       inline=True)
        embed.add_field(name="Gold",      value=f"+🪙{earned_gold}" if won else "—",   inline=True)
        if new_lvl > lvl: embed.add_field(name="⬆️ Level Up!", value=f"Level **{new_lvl}**!", inline=False)
        await interaction.response.send_message(embed=embed)

    @rpg.subcommand(name="dungeon", description="Enter a dungeon for big rewards (1h cooldown)")
    async def dungeon(self, interaction: nextcord.Interaction,
                      name: str = SlashOption(description="Dungeon name", choices={d[0]:d[0] for d in DUNGEONS})):
        row = await self._get_char(interaction.guild_id, interaction.user.id)
        if not row:
            await interaction.response.send_message(embed=error_embed("Create a character first!")); return
        uid = interaction.user.id
        now = time.time()
        if now - self._dungeon_cd.get(uid,0) < 3600:
            left = int(3600-(now-self._dungeon_cd[uid]))
            m,s = divmod(left,60)
            await interaction.response.send_message(embed=error_embed(f"Dungeon on cooldown! Try again in **{m}m {s}s**.")); return
        dung = next((d for d in DUNGEONS if d[0]==name), None)
        if not dung: await interaction.response.send_message(embed=error_embed("Invalid dungeon.")); return
        dname,min_lvl,pool,xp_r,gold_r = dung
        cls,hp,max_hp,atk,def_,spd,lvl,xp,gold,weapon,armor = row
        if lvl < min_lvl:
            await interaction.response.send_message(embed=error_embed(f"Need Level **{min_lvl}** for {dname}. You're {lvl}.")); return
        self._dungeon_cd[uid] = now
        # Multi-wave dungeon
        waves = random.randint(2,4)
        total_dmg_taken = 0
        victories = 0
        for _ in range(waves):
            enemy = ENEMIES[random.choice(pool)]
            ename,_,ehp,eatk,edef,_,_ = enemy
            pdmg = max(1, atk - edef + random.randint(0,8))
            edm  = max(1, eatk - def_ + random.randint(0,5))
            total_dmg_taken += edm * max(1, ehp // pdmg)
            if total_dmg_taken < max_hp:
                victories += 1
        won = victories >= waves//2 + 1
        earned = (xp_r if won else xp_r//3, gold_r if won else 0)
        new_hp = max(1, max_hp - total_dmg_taken) if won else max(1, max_hp//4)
        new_xp = xp + earned[0]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE rpg_chars SET hp=?,xp=?,gold=gold+? WHERE guild_id=? AND user_id=?",
                             (new_hp,new_xp,earned[1],interaction.guild_id,uid))
            await db.commit()
        embed = nextcord.Embed(
            title=f"{'🏆 Dungeon Cleared!' if won else '💀 Dungeon Failed'}: {dname}",
            description=f"Fought **{waves}** waves. Won **{victories}**.",
            color=0x57F287 if won else 0xFF4444,
        )
        embed.add_field(name="XP",  value=f"+{earned[0]}")
        embed.add_field(name="Gold",value=f"+🪙{earned[1]}" if won else "—")
        await interaction.response.send_message(embed=embed)

    @rpg.subcommand(name="shop", description="Buy items with your gold")
    async def shop(self, interaction: nextcord.Interaction,
                   item: str = SlashOption(description="Item to buy", choices={v["name"]:k for k,v in ITEMS.items()}, required=False)):
        if not item:
            desc = "\n".join(f"{v['emoji']} **{v['name']}** — 🪙{v['price']} | {v['type']}" for v in ITEMS.values())
            await interaction.response.send_message(embed=info_embed("🏪 RPG Shop", desc)); return
        row = await self._get_char(interaction.guild_id, interaction.user.id)
        if not row:
            await interaction.response.send_message(embed=error_embed("Create a character first!")); return
        it = ITEMS[item]
        _,_,_,_,_,_,_,_,gold,_,_ = row
        if gold < it["price"]:
            await interaction.response.send_message(embed=error_embed(f"Need 🪙{it['price']}, you have 🪙{gold}.")); return
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute("UPDATE rpg_chars SET gold=gold-? WHERE guild_id=? AND user_id=?",
                             (it["price"],interaction.guild_id,interaction.user.id))
            await db.execute("INSERT INTO rpg_inventory (guild_id,user_id,item_id,quantity) VALUES (?,?,?,1) ON CONFLICT(guild_id,user_id,item_id) DO UPDATE SET quantity=quantity+1",
                             (interaction.guild_id,interaction.user.id,item))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Bought {it['emoji']} **{it['name']}** for 🪙{it['price']}!"))

    # ── Cards ──────────────────────────────────────────────────────────────────

    @nextcord.slash_command(name="cards", description="🃏 Card collection game")
    async def cards(self, interaction: nextcord.Interaction):
        pass

    @cards.subcommand(name="draw", description="Draw a random card (uses 50 coins, 1 free/day)")
    async def draw(self, interaction: nextcord.Interaction):
        uid = interaction.user.id
        now = time.time()
        free = now - self._draw_cd.get(uid,0) > 86400
        if not free:
            # Charge coins
            async with aiosqlite.connect(self.bot.db_path) as db:
                async with db.execute("SELECT coins FROM economy WHERE user_id=?", (uid,)) as cur:
                    row = await cur.fetchone()
                if not row or row[0] < 50:
                    await interaction.response.send_message(embed=error_embed("Not enough coins! (50🪙) or wait for your free daily draw.")); return
                await db.execute("UPDATE economy SET coins=coins-50 WHERE user_id=?", (uid,))
                await db.commit()
        else:
            self._draw_cd[uid] = now
        rarity = _draw_rarity()
        pool = [c for c in CARDS if c[1]==rarity]
        card = random.choice(pool)
        cname,crar,cemoji,cdesc = card
        _,marker,color,atk_bonus,_ = CARD_RARITIES[rarity]
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO card_collection (user_id,card_name,rarity,count) VALUES (?,?,?,1) ON CONFLICT(user_id,card_name) DO UPDATE SET count=count+1",
                (uid,cname,rarity)
            )
            await db.commit()
        embed = nextcord.Embed(
            title=f"{cemoji} {cname}",
            description=cdesc,
            color=color,
        )
        embed.add_field(name="Rarity",    value=f"{marker} {rarity.title()}")
        embed.add_field(name="ATK Bonus", value=f"+{atk_bonus}")
        embed.set_footer(text="Free draw!" if free else "Cost: 50🪙")
        await interaction.response.send_message(embed=embed)

    @cards.subcommand(name="collection", description="View your card collection")
    async def collection(self, interaction: nextcord.Interaction,
                         user: nextcord.Member = SlashOption(required=False)):
        target = user or interaction.user
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute(
                "SELECT card_name,rarity,count FROM card_collection WHERE user_id=? ORDER BY CASE rarity WHEN 'legendary' THEN 0 WHEN 'epic' THEN 1 WHEN 'rare' THEN 2 WHEN 'uncommon' THEN 3 ELSE 4 END",
                (target.id,)
            ) as cur:
                rows = await cur.fetchall()
        if not rows:
            await interaction.response.send_message(embed=info_embed("🃏 Collection", "No cards yet! Use `/cards draw`.")); return
        lines = []
        for cname,crar,count in rows:
            marker = CARD_RARITIES[crar][1]
            card = next((c for c in CARDS if c[0]==cname),None)
            emoji = card[2] if card else "🃏"
            lines.append(f"{marker} {emoji} **{cname}** ×{count}")
        embed = nextcord.Embed(title=f"🃏 {target.display_name}'s Cards", color=0x9B59B6)
        embed.description = "\n".join(lines[:20])
        embed.set_footer(text=f"{len(rows)} unique cards")
        await interaction.response.send_message(embed=embed)

    @cards.subcommand(name="sell", description="Sell a card for coins")
    async def sell(self, interaction: nextcord.Interaction,
                   card_name: str = SlashOption(description="Card name to sell")):
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT rarity,count FROM card_collection WHERE user_id=? AND card_name=?", (interaction.user.id,card_name)) as cur:
                row = await cur.fetchone()
        if not row:
            await interaction.response.send_message(embed=error_embed("You don't have that card!")); return
        rarity,count = row
        price = CARD_RARITIES[rarity][4]
        async with aiosqlite.connect(self.bot.db_path) as db:
            if count <= 1:
                await db.execute("DELETE FROM card_collection WHERE user_id=? AND card_name=?", (interaction.user.id,card_name))
            else:
                await db.execute("UPDATE card_collection SET count=count-1 WHERE user_id=? AND card_name=?", (interaction.user.id,card_name))
            await db.execute("INSERT OR IGNORE INTO economy (user_id) VALUES (?)", (interaction.user.id,))
            await db.execute("UPDATE economy SET coins=coins+? WHERE user_id=?", (price,interaction.user.id))
            await db.commit()
        await interaction.response.send_message(embed=success_embed(f"Sold **{card_name}** for 🪙{price}!"))


def setup(bot):
    bot.add_cog(RPGCog(bot))
