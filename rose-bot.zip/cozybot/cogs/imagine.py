"""
Text-to-image generation for Rosé bot.
Endpoint: POST https://api.freepik.com/v1/ai/text-to-image  (Classic Fast)

Response shape:
  { "data": { "generated": [{"base64": "..."}], "task_id": "...", "status": "COMPLETED" } }

Images are returned as base64 synchronously — no polling needed.
"""

import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiohttp
import asyncio
import os
import io
import base64
import datetime
from utils.helpers import error_embed, success_embed, info_embed

FREEPIK_KEY = os.getenv("FREEPIK_API_KEY", "")
BASE_URL    = "https://api.freepik.com/v1/ai/text-to-image"

FREE_LIMIT    = 3
PREMIUM_LIMIT = 20

# Valid image.size values per Freepik docs
SIZES = {
    "square":    ("Square 1:1",    "square_1_1"),
    "landscape": ("Landscape 16:9","widescreen_16_9"),
    "portrait":  ("Portrait 9:16", "mobile_9_16"),
    "wide":      ("Wide 4:3",      "traditional_4_3"),
    "tall":      ("Tall 3:4",      "traditional_3_4"),
}

# styling.style
STYLES = {
    "anime":       "🌸 Anime",
    "photo":       "📷 Photo",
    "digital-art": "🎨 Digital Art",
    "illustration":"🖌️ Illustration",
    "watercolor":  "💧 Watercolor",
    "painting":    "🖼️ Painting",
    "3d":          "🎮 3D",
    "sketch":      "✏️ Sketch",
    "cartoon":     "🎭 Cartoon",
    "pixel-art":   "👾 Pixel Art",
}

# styling.effects.color
COLORS = {
    "none":    "—",
    "pastel":  "🌸 Pastel",
    "vibrant": "🌈 Vibrant",
    "warm":    "🔥 Warm",
    "cool":    "❄️ Cool",
    "muted":   "🌫️ Muted",
    "b&w":     "⬛ B&W",
}

# styling.effects.lightning
LIGHTINGS = {
    "none":        "—",
    "warm":        "🌅 Warm",
    "dramatic":    "⚡ Dramatic",
    "studio":      "💡 Studio",
    "golden-hour": "🌇 Golden Hour",
    "neon":        "🌃 Neon",
    "cinematic":   "🎬 Cinematic",
}


class ImagineCog(commands.Cog):
    def __init__(self, bot):
        self.bot   = bot
        self._used: dict = {}   # {user_id: (date_str, count)}

    # ── Usage helpers ─────────────────────────────────────────────────────────

    def _today(self) -> str:
        return datetime.date.today().isoformat()

    def _used_today(self, uid: int) -> int:
        entry = self._used.get(uid)
        return entry[1] if entry and entry[0] == self._today() else 0

    def _can_generate(self, uid: int, premium: bool) -> tuple[bool, int]:
        limit = PREMIUM_LIMIT if premium else FREE_LIMIT
        used  = self._used_today(uid)
        return used < limit, limit - used

    def _bump(self, uid: int):
        today = self._today()
        used  = self._used_today(uid)
        self._used[uid] = (today, used + 1)

    # ── Core generate call ────────────────────────────────────────────────────

    async def _generate(
        self, prompt: str, negative: str,
        style: str, color: str, lighting: str,
        size_key: str, guidance: float, seed: int | None,
    ) -> tuple[bytes | None, str | None]:
        """
        Returns (image_bytes, error_message).
        Calls POST /v1/ai/text-to-image and extracts base64 from response.
        """
        if not FREEPIK_KEY:
            return None, (
                "No Freepik API key configured!\n"
                "Add `FREEPIK_API_KEY=your_key` to your `.env`.\n"
                "Get a free key at <https://www.freepik.com/api>"
            )

        _, size_val = SIZES.get(size_key, SIZES["square"])

        # Build styling block
        effects = {}
        if color   != "none": effects["color"]     = color
        if lighting != "none": effects["lightning"] = lighting

        styling: dict = {"style": style}
        if effects:
            styling["effects"] = effects

        payload: dict = {
            "prompt":      prompt,
            "num_images":  1,
            "image":       {"size": size_val},
            "styling":     styling,
            "filter_nsfw": True,
            "guidance_scale": guidance,
        }
        if negative:
            payload["negative_prompt"] = negative
        if seed is not None:
            payload["seed"] = seed

        headers = {
            "x-freepik-api-key": FREEPIK_KEY,
            "Content-Type":      "application/json",
            "Accept":            "application/json",
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    BASE_URL, json=payload, headers=headers,
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as resp:
                    body = await resp.json()

                    if resp.status == 401:
                        return None, "❌ Invalid Freepik API key — check your `.env`."
                    if resp.status == 429:
                        return None, "⏳ Rate limited by Freepik. Try again in a moment!"
                    if resp.status == 402:
                        return None, "💳 Freepik quota exceeded. Check your plan at freepik.com/api."
                    if resp.status not in (200, 201, 202):
                        msg = body.get("message") or body.get("error") or str(body)[:200]
                        return None, f"❌ Freepik error {resp.status}: {msg}"

            # ── Parse response ─────────────────────────────────────────────
            # Freepik returns: { "data": [{"base64": "..."}, ...] }
            # data is a LIST of image objects directly
            raw  = body.get("data", [])
            # Also handle wrapped shape: {"data": {"generated": [...]}}
            if isinstance(raw, dict):
                generated = raw.get("generated", [])
                status_str = raw.get("status", "unknown")
            elif isinstance(raw, list):
                generated = raw
                status_str = "ok"
            else:
                generated = []
                status_str = "unknown"

            if not generated:
                return None, f"❌ No image returned (status: {status_str}). Try again or rephrase your prompt."

            img_obj = generated[0]

            # Could be a dict with "base64" or "url", or a plain string
            if isinstance(img_obj, dict):
                b64_str = img_obj.get("base64") or img_obj.get("url")
            else:
                b64_str = str(img_obj)

            if not b64_str:
                return None, "❌ Empty image data in response."

            # If it's a URL rather than base64, we can't embed directly — return as-is
            if b64_str.startswith("http"):
                # Download it so we always send a file (avoids CDN expiry issues)
                async with aiohttp.ClientSession() as s:
                    async with s.get(b64_str, timeout=aiohttp.ClientTimeout(total=30)) as r:
                        if r.status == 200:
                            return await r.read(), None
                        return None, f"❌ Could not download image (HTTP {r.status})."

            # Strip data URI prefix if present  e.g. "data:image/jpeg;base64,..."
            if "," in b64_str:
                b64_str = b64_str.split(",", 1)[1]

            return base64.b64decode(b64_str), None

        except asyncio.TimeoutError:
            return None, "⏳ Request timed out (60s). Freepik may be busy — try again!"
        except Exception as exc:
            return None, f"❌ Unexpected error: {str(exc)[:200]}"

    # ── Slash commands ─────────────────────────────────────────────────────────

    @nextcord.slash_command(name="imagine", description="🎨 Generate images from text with Freepik AI")
    async def imagine(self, interaction: nextcord.Interaction):
        pass

    @imagine.subcommand(name="generate", description="Turn a text prompt into an image")
    async def generate(
        self,
        interaction: nextcord.Interaction,
        prompt:   str   = SlashOption(description="Describe the image you want to create"),
        style:    str   = SlashOption(description="Art style", choices=STYLES,
                                      required=False, default="photo"),
        size:     str   = SlashOption(description="Aspect ratio",
                                      choices={v[0]: k for k, v in SIZES.items()},
                                      required=False, default="square"),
        color:    str   = SlashOption(description="Color effect", choices=COLORS,
                                      required=False, default="none"),
        lighting: str   = SlashOption(description="Lighting effect", choices=LIGHTINGS,
                                      required=False, default="none"),
        negative: str   = SlashOption(description="What to exclude from the image (optional)",
                                      required=False, default=""),
        guidance: float = SlashOption(description="Prompt strength 0.0–2.0 (default 1.0)",
                                      required=False, default=1.0, min_value=0.0, max_value=2.0),
        seed:     int   = SlashOption(description="Seed for reproducible results (optional)",
                                      required=False, default=-1),
    ):
        premium = (
            interaction.user.id in self.bot.premium_users
            or interaction.guild_id in self.bot.premium_guilds
        )
        allowed, remaining = self._can_generate(interaction.user.id, premium)
        if not allowed:
            lim = PREMIUM_LIMIT if premium else FREE_LIMIT
            await interaction.response.send_message(embed=error_embed(
                f"You've hit your daily limit of **{lim}** image{'s' if lim > 1 else ''}!\n"
                + ("Resets at midnight. ⭐" if premium
                   else "Upgrade to Premium on [Patreon](https://patreon.com/katsioon) for 20/day!")
            ))
            return

        await interaction.response.defer()

        size_label  = SIZES.get(size, SIZES["square"])[0]
        style_label = STYLES.get(style, style)

        # ── Show loading embed ─────────────────────────────────────────────
        loading = nextcord.Embed(
            title="🎨 Generating your image...",
            description=(
                f"**Prompt:** {prompt[:200]}\n"
                f"**Style:** {style_label}  **Size:** {size_label}\n"
                "*(usually takes 10–30 seconds)*"
            ),
            color=0xFF91A4,
        )
        await interaction.followup.send(embed=loading)

        # ── Call API ───────────────────────────────────────────────────────
        actual_seed = seed if seed != -1 else None
        img_bytes, err = await self._generate(
            prompt, negative, style, color, lighting, size, guidance, actual_seed
        )

        if err:
            await interaction.edit_original_message(embed=error_embed(err))
            return

        self._bump(interaction.user.id)
        _, remaining = self._can_generate(interaction.user.id, premium)

        # ── Build result embed ─────────────────────────────────────────────
        embed = nextcord.Embed(
            title="🎨 Here's your image!",
            description=f"**Prompt:** {prompt[:200]}",
            color=0xFF91A4,
        )
        embed.add_field(name="Style",  value=style_label, inline=True)
        embed.add_field(name="Size",   value=size_label,  inline=True)
        if color    != "none": embed.add_field(name="Color",   value=COLORS[color],     inline=True)
        if lighting != "none": embed.add_field(name="Lighting",value=LIGHTINGS[lighting],inline=True)
        if negative:           embed.add_field(name="Excluded", value=negative[:100],   inline=False)
        if actual_seed:        embed.add_field(name="🌱 Seed",  value=str(actual_seed), inline=True)
        embed.set_footer(text=(
            f"⭐ Premium · {remaining} left today · Freepik AI"
            if premium else
            f"Free · {remaining} gens left today · Freepik AI"
        ))
        embed.set_image(url="attachment://generated.png")

        file = nextcord.File(io.BytesIO(img_bytes), filename="generated.png")
        await interaction.edit_original_message(embed=embed, file=file)

    @imagine.subcommand(name="styles", description="View all available art styles & effects")
    async def styles(self, interaction: nextcord.Interaction):
        embed = nextcord.Embed(title="🎨 Styles & Effects", color=0xFF91A4)
        embed.add_field(
            name="🖼️ Art Styles",
            value="\n".join(f"`{k}` {v}" for k, v in STYLES.items()),
            inline=True,
        )
        embed.add_field(
            name="🎨 Color Effects",
            value="\n".join(f"`{k}` {v}" for k, v in COLORS.items() if k != "none"),
            inline=True,
        )
        embed.add_field(
            name="💡 Lighting",
            value="\n".join(f"`{k}` {v}" for k, v in LIGHTINGS.items() if k != "none"),
            inline=True,
        )
        embed.set_footer(text="Use these in /imagine generate")
        await interaction.response.send_message(embed=embed)

    @imagine.subcommand(name="usage", description="Check your image generation usage today")
    async def usage(self, interaction: nextcord.Interaction):
        premium = (
            interaction.user.id in self.bot.premium_users
            or interaction.guild_id in self.bot.premium_guilds
        )
        limit = PREMIUM_LIMIT if premium else FREE_LIMIT
        used  = self._used_today(interaction.user.id)
        pct   = int(used / limit * 10)
        bar   = "█" * pct + "░" * (10 - pct)
        embed = nextcord.Embed(
            title="🎨 Image Gen Usage",
            description=(
                f"`{bar}` **{used} / {limit}** today\n\n"
                + ("⭐ **Premium** — 20 images/day" if premium
                   else "**Free** — 3 images/day · [Upgrade on Patreon](https://patreon.com/katsioon) for 20/day!")
            ),
            color=0xFF91A4,
        )
        await interaction.response.send_message(embed=embed)

    @imagine.subcommand(name="info", description="About Rosé AI image generation")
    async def info(self, interaction: nextcord.Interaction):
        embed = nextcord.Embed(
            title="🎨 Rosé Image Generation",
            description=(
                "Generate stunning AI images right inside Discord!\n\n"
                "**Powered by [Freepik Classic Fast](https://www.freepik.com/api)**\n\n"
                f"**{len(STYLES)}** art styles · **{len(COLORS)-1}** color effects · "
                f"**{len(LIGHTINGS)-1}** lighting effects · **{len(SIZES)}** aspect ratios\n\n"
                "🆓 **Free:** 3 images/day\n"
                "⭐ **Premium:** 20 images/day — [Patreon](https://patreon.com/katsioon)\n\n"
                "**✨ Prompt tips:**\n"
                "• Be specific — describe subject, mood, setting & lighting\n"
                "• Use `negative` to exclude unwanted elements (e.g. *blurry, cartoon*)\n"
                "• Set a `seed` to recreate the same image later\n"
                "• Lower `guidance` = more creative; higher = closer to your prompt"
            ),
            color=0xFF91A4,
        )
        await interaction.response.send_message(embed=embed)


def setup(bot):
    bot.add_cog(ImagineCog(bot))
