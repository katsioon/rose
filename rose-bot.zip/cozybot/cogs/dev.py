"""
Dev/owner commands for Rosé bot.
Add your Discord user ID(s) to DEV_IDS below.
"""
import os
import nextcord
from nextcord.ext import commands
from nextcord import SlashOption
import aiosqlite
import time
from utils.helpers import success_embed, error_embed, info_embed

# ── Add your Discord user ID here ─────────────────────────────────────────────
DEV_IDS: set[int] = {1046158340675346574}

# ── Reusable dev-only check ────────────────────────────────────────────────────

async def _deny(interaction: nextcord.Interaction):
    """Send a silent rejection and return True if the user is NOT a dev."""
    if interaction.user.id not in DEV_IDS:
        await interaction.response.send_message(
            embed=error_embed("You don't have permission to use dev commands."))
        return True
    return False


class DevCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # ── /dev parent ────────────────────────────────────────────────────────────

    @nextcord.slash_command(name="dev", description="🔧 Developer commands", guild_ids=[int(os.getenv("SUPPORT_GUILD_ID", "0"))] if os.getenv("SUPPORT_GUILD_ID") else None)
    async def dev(self, interaction: nextcord.Interaction):
        # Parent command — dev check handled in every subcommand individually
        pass

    # ── Guild config ───────────────────────────────────────────────────────────

    @dev.subcommand(name="config", description="View a guild's current config")
    async def dev_config(
        self,
        interaction: nextcord.Interaction,
        guild_id: str = SlashOption(description="Guild ID (blank = current server)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT * FROM guild_config WHERE guild_id=?", (gid)) as cur:
                row = await cur.fetchone()
        if not row:
            await interaction.response.send_message(embed=error_embed(f"No config found for guild `{gid}`."))
            return
        cols = ["guild_id", "join_ch", "leave_ch", "join_msg", "leave_msg",
                "ticket_cat", "ticket_log", "ticket_role", "inv_tracking", "prefix"]
        embed = nextcord.Embed(title=f"⚙️ Config — {gid}", color=0x5865F2)
        for i, col in enumerate(cols):
            val = str(row[i]) if row[i] is not None else "*not set*"
            embed.add_field(name=col, value=val, inline=True)
        await interaction.response.send_message(embed=embed)

    @dev.subcommand(name="set_join_channel", description="Set join announcement channel for a guild")
    async def dev_set_join(
        self,
        interaction: nextcord.Interaction,
        channel_id: str = SlashOption(description="Channel ID"),
        guild_id: str = SlashOption(description="Guild ID (blank = current)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, join_channel_id) VALUES (?,?)"
                " ON CONFLICT(guild_id) DO UPDATE SET join_channel_id=excluded.join_channel_id",
                (gid, int(channel_id))
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Join channel set to `{channel_id}` for guild `{gid}`")
        )

    @dev.subcommand(name="set_leave_channel", description="Set leave announcement channel for a guild")
    async def dev_set_leave(
        self,
        interaction: nextcord.Interaction,
        channel_id: str = SlashOption(description="Channel ID"),
        guild_id: str = SlashOption(description="Guild ID (blank = current)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, leave_channel_id) VALUES (?,?)"
                " ON CONFLICT(guild_id) DO UPDATE SET leave_channel_id=excluded.leave_channel_id",
                (gid, int(channel_id))
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Leave channel set to `{channel_id}` for guild `{gid}`")
        )

    @dev.subcommand(name="set_join_message", description="Set custom join message for a guild")
    async def dev_set_join_msg(
        self,
        interaction: nextcord.Interaction,
        message: str = SlashOption(description="Message text — use {user} and {server} as placeholders"),
        guild_id: str = SlashOption(description="Guild ID (blank = current)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, join_message) VALUES (?,?)"
                " ON CONFLICT(guild_id) DO UPDATE SET join_message=excluded.join_message",
                (gid, message)
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Join message updated for guild `{gid}`")
        )

    @dev.subcommand(name="set_leave_message", description="Set custom leave message for a guild")
    async def dev_set_leave_msg(
        self,
        interaction: nextcord.Interaction,
        message: str = SlashOption(description="Message text — use {user} and {server} as placeholders"),
        guild_id: str = SlashOption(description="Guild ID (blank = current)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, leave_message) VALUES (?,?)"
                " ON CONFLICT(guild_id) DO UPDATE SET leave_message=excluded.leave_message",
                (gid, message)
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Leave message updated for guild `{gid}`")
        )

    @dev.subcommand(name="toggle_invite_tracking", description="Enable or disable invite tracking for a guild")
    async def dev_toggle_invites(
        self,
        interaction: nextcord.Interaction,
        guild_id: str = SlashOption(description="Guild ID (blank = current)", required=False)):
        if await _deny(interaction): return
        gid = int(guild_id) if guild_id else interaction.guild_id
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT invite_tracking FROM guild_config WHERE guild_id=?", (gid)) as cur:
                row = await cur.fetchone()
            new_val = 0 if (row and row[0]) else 1
            await db.execute(
                "INSERT INTO guild_config (guild_id, invite_tracking) VALUES (?,?)"
                " ON CONFLICT(guild_id) DO UPDATE SET invite_tracking=excluded.invite_tracking",
                (gid, new_val)
            )
            await db.commit()
        state = "enabled ✅" if new_val else "disabled ❌"
        await interaction.response.send_message(
            embed=success_embed(f"Invite tracking {state} for guild `{gid}`")
        )

    # ── Premium management ─────────────────────────────────────────────────────

    @dev.subcommand(name="grant_premium", description="Grant premium to a user or guild")
    async def dev_grant_premium(
        self,
        interaction: nextcord.Interaction,
        target_id: str = SlashOption(description="User or Guild ID"),
        target_type: str = SlashOption(description="Type", choices=["user", "guild"]),
        days: int = SlashOption(description="Days of premium (0 = permanent)", default=30, min_value=0)):
        if await _deny(interaction): return
        expires = int(time.time()) + (days * 86400) if days > 0 else 9_999_999_999
        tid = int(target_id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            if target_type == "user":
                await db.execute(
                    "INSERT OR REPLACE INTO premium_users (user_id, expires_at) VALUES (?,?)", (tid, expires)
                )
                self.bot.premium_users.add(tid)
            else:
                await db.execute(
                    "INSERT OR REPLACE INTO premium_guilds (guild_id, expires_at) VALUES (?,?)", (tid, expires)
                )
                self.bot.premium_guilds.add(tid)
            await db.commit()
        dur = f"{days} days" if days > 0 else "permanent"
        await interaction.response.send_message(
            embed=success_embed(f"⭐ Premium granted to {target_type} `{target_id}` for **{dur}**")
        )

    @dev.subcommand(name="revoke_premium", description="Revoke premium from a user or guild")
    async def dev_revoke_premium(
        self,
        interaction: nextcord.Interaction,
        target_id: str = SlashOption(description="User or Guild ID"),
        target_type: str = SlashOption(description="Type", choices=["user", "guild"])):
        if await _deny(interaction): return
        tid = int(target_id)
        async with aiosqlite.connect(self.bot.db_path) as db:
            if target_type == "user":
                await db.execute("DELETE FROM premium_users WHERE user_id=?", (tid))
                self.bot.premium_users.discard(tid)
            else:
                await db.execute("DELETE FROM premium_guilds WHERE guild_id=?", (tid))
                self.bot.premium_guilds.discard(tid)
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Premium revoked from {target_type} `{target_id}`")
        )

    @dev.subcommand(name="premium_list", description="List all active premium users and guilds")
    async def dev_premium_list(self, interaction: nextcord.Interaction):
        if await _deny(interaction): return
        async with aiosqlite.connect(self.bot.db_path) as db:
            async with db.execute("SELECT user_id, expires_at FROM premium_users") as cur:
                users = await cur.fetchall()
            async with db.execute("SELECT guild_id, expires_at FROM premium_guilds") as cur:
                guilds = await cur.fetchall()
        now = int(time.time())
        embed = nextcord.Embed(title="⭐ Active Premium", color=0xFFD700)
        u_lines = "\n".join(
            f"`{uid}` — {'permanent' if exp > 9_999_999_990 else f'expires <t:{exp}:R>'}"
            for uid, exp in users if exp > now
        ) or "*none*"
        g_lines = "\n".join(
            f"`{gid}` — {'permanent' if exp > 9_999_999_990 else f'expires <t:{exp}:R>'}"
            for gid, exp in guilds if exp > now
        ) or "*none*"
        embed.add_field(name=f"👤 Users ({len(users)})", value=u_lines[:1000], inline=False)
        embed.add_field(name=f"🏠 Guilds ({len(guilds)})", value=g_lines[:1000], inline=False)
        await interaction.response.send_message(embed=embed)

    # ── Broadcast ──────────────────────────────────────────────────────────────

    @dev.subcommand(name="broadcast", description="Send a message to all guild system channels")
    async def dev_broadcast(
        self,
        interaction: nextcord.Interaction,
        message: str = SlashOption(description="Message to broadcast")):
        if await _deny(interaction): return
        await interaction.response.defer()
        sent = failed = 0
        for guild in self.bot.guilds:
            ch = guild.system_channel
            if ch and ch.permissions_for(guild.me).send_messages:
                try:
                    embed = nextcord.Embed(
                        title="📢 Rosé Announcement",
                        description=message,
                        color=0xF4A261)
                    embed.set_footer(text="Rosé Bot Dev Team")
                    await ch.send(embed=embed)
                    sent += 1
                except Exception:
                    failed += 1
            else:
                failed += 1
        await interaction.followup.send(
            embed=success_embed(f"Broadcast sent to **{sent}** guilds. ({failed} skipped/failed)"))

    # ── Guild list ─────────────────────────────────────────────────────────────

    @dev.subcommand(name="guilds", description="List all guilds the bot is in")
    async def dev_guilds(self, interaction: nextcord.Interaction):
        if await _deny(interaction): return
        guilds = sorted(self.bot.guilds, key=lambda g: g.member_count or 0, reverse=True)
        lines = [
            f"`{g.id}` **{g.name}** — {g.member_count:,} members"
            + (" ⭐" if g.id in self.bot.premium_guilds else "")
            for g in guilds[:25]
        ]
        embed = nextcord.Embed(
            title=f"📋 Guilds ({len(self.bot.guilds)} total)",
            description="\n".join(lines) or "*none*",
            color=0x5865F2)
        if len(guilds) > 25:
            embed.set_footer(text=f"Showing top 25 of {len(guilds)}")
        await interaction.response.send_message(embed=embed)

    # ── Bot stats ──────────────────────────────────────────────────────────────

    @dev.subcommand(name="stats", description="Bot statistics")
    async def dev_stats(self, interaction: nextcord.Interaction):
        if await _deny(interaction): return
        try:
            import psutil, os as _os
            proc = psutil.Process(_os.getpid())
            mem = f"{proc.memory_info().rss / 1024 / 1024:.1f} MB"
        except ImportError:
            mem = "*psutil not installed*"
        embed = nextcord.Embed(title="📊 Rosé Stats", color=0x5865F2)
        embed.add_field(name="Guilds", value=f"{len(self.bot.guilds):,}")
        embed.add_field(name="Users", value=f"{sum(g.member_count or 0 for g in self.bot.guilds):,}")
        embed.add_field(name="Premium Guilds", value=str(len(self.bot.premium_guilds)))
        embed.add_field(name="Premium Users", value=str(len(self.bot.premium_users)))
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms")
        embed.add_field(name="Memory", value=mem)
        await interaction.response.send_message(embed=embed)

    # ── Cog reload ─────────────────────────────────────────────────────────────

    @dev.subcommand(name="reload", description="Reload a cog without restarting")
    async def dev_reload(
        self,
        interaction: nextcord.Interaction,
        cog: str = SlashOption(description="Cog path e.g. cogs.tickets")):
        if await _deny(interaction): return
        try:
            self.bot.reload_extension(cog)
            await interaction.response.send_message(
                embed=success_embed(f"Reloaded `{cog}` ✅")
            )
        except Exception as e:
            await interaction.response.send_message(embed=error_embed(str(e)))

    # ── Raw SQL ────────────────────────────────────────────────────────────────

    @dev.subcommand(name="sql", description="Run a read-only SQL query")
    async def dev_sql(
        self,
        interaction: nextcord.Interaction,
        query: str = SlashOption(description="SELECT query only")):
        if await _deny(interaction): return
        if any(kw in query.upper() for kw in ["DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE"]):
            await interaction.response.send_message(
                embed=error_embed("Only SELECT queries are allowed here for safety.")
            )
            return
        try:
            async with aiosqlite.connect(self.bot.db_path) as db:
                async with db.execute(query) as cur:
                    rows = await cur.fetchmany(15)
                    cols = [d[0] for d in (cur.description or [])]
            if not rows:
                await interaction.response.send_message(embed=info_embed("🗄️ SQL", "No results."))
                return
            header = " | ".join(cols)
            body = "\n".join(" | ".join(str(v) for v in row) for row in rows)
            result = f"```\n{header}\n{'─' * len(header)}\n{body}\n```"
            if len(result) > 1990:
                result = result[:1990] + "\n...```"
            embed = nextcord.Embed(title="🗄️ SQL Result", description=result, color=0x5865F2)
            await interaction.response.send_message(embed=embed)
        except Exception as e:
            await interaction.response.send_message(embed=error_embed(f"SQL error: {e}"))

    # ── Sync slash commands ────────────────────────────────────────────────────

    @dev.subcommand(name="sync", description="Force sync slash commands globally")
    async def dev_sync(self, interaction: nextcord.Interaction):
        if await _deny(interaction): return
        await interaction.response.defer()
        try:
            await self.bot.sync_all_application_commands()
            await interaction.followup.send(
                embed=success_embed("Slash commands synced globally! May take up to 1 hour to appear."))
        except Exception as e:
            await interaction.followup.send(embed=error_embed(str(e)))

    # ── Force leave guild ──────────────────────────────────────────────────────

    @dev.subcommand(name="leave_guild", description="Force the bot to leave a guild")
    async def dev_leave_guild(
        self,
        interaction: nextcord.Interaction,
        guild_id: str = SlashOption(description="Guild ID to leave")):
        if await _deny(interaction): return
        guild = self.bot.get_guild(int(guild_id))
        if not guild:
            await interaction.response.send_message(embed=error_embed("Guild not found."))
            return
        name = guild.name
        await guild.leave()
        await interaction.response.send_message(embed=success_embed(f"Left guild **{name}** (`{guild_id}`)"))


def setup(bot):
    bot.add_cog(DevCog(bot))

    @dev.subcommand(name="set_guild_log", description="Set the channel to log server joins/leaves")
    async def dev_set_guild_log(
        self,
        interaction: nextcord.Interaction,
        channel_id: str = SlashOption(description="Channel ID in your support server"),
    ):
        if await _deny(interaction): return
        # Write to .env isn't practical at runtime, so we store in DB under guild 0 as a global setting
        async with aiosqlite.connect(self.bot.db_path) as db:
            await db.execute(
                "INSERT INTO guild_config (guild_id, join_channel_id) VALUES (0,?) ON CONFLICT(guild_id) DO UPDATE SET join_channel_id=excluded.join_channel_id",
                (int(channel_id),)
            )
            await db.commit()
        await interaction.response.send_message(
            embed=success_embed(f"Guild log channel set to `{channel_id}`\n⚠️ Also set `GUILD_LOG_CHANNEL_ID={channel_id}` in your `.env` for persistence across restarts.")
        )