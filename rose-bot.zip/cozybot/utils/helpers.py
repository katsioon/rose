import nextcord
import time
from typing import Optional

def premium_embed(feature: str) -> nextcord.Embed:
    return nextcord.Embed(
        title="⭐ Premium Feature",
        description=f"**{feature}** is a Rosé Premium feature!\n\n"
                    "Subscribe on **[Patreon](https://patreon.com/katsioon)** or join the **[Support Server](https://discord.gg/rKajpSCGKF)** to unlock:\n"
                    "• Unlimited tickets & custom messages\n"
                    "• AI chat with memory\n"
                    "• Rare pets & pet battles\n"
                    "• Advanced RL analytics\n"
                    "• Custom bot prefix\n"
                    "• Priority support",
        color=0xFFD700,
    )

def error_embed(msg: str) -> nextcord.Embed:
    return nextcord.Embed(description=f"❌ {msg}", color=0xFF4444)

def success_embed(msg: str) -> nextcord.Embed:
    return nextcord.Embed(description=f"✅ {msg}", color=0x57F287)

def info_embed(title: str, msg: str, color=0xF4A261) -> nextcord.Embed:
    return nextcord.Embed(title=title, description=msg, color=color)

def now() -> int:
    return int(time.time())

def human_time(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        return f"{seconds//60}m {seconds%60}s"
    elif seconds < 86400:
        h = seconds // 3600
        m = (seconds % 3600) // 60
        return f"{h}h {m}m"
    else:
        d = seconds // 86400
        h = (seconds % 86400) // 3600
        return f"{d}d {h}h"

PET_TYPES = {
    "cat": {"emoji": "🐱", "rarity": "common"},
    "dog": {"emoji": "🐶", "rarity": "common"},
    "bunny": {"emoji": "🐰", "rarity": "common"},
    "fox": {"emoji": "🦊", "rarity": "uncommon"},
    "panda": {"emoji": "🐼", "rarity": "uncommon"},
    "penguin": {"emoji": "🐧", "rarity": "uncommon"},
    "dragon": {"emoji": "🐉", "rarity": "rare"},
    "unicorn": {"emoji": "🦄", "rarity": "rare"},
    "phoenix": {"emoji": "🔥", "rarity": "legendary"},
    "axolotl": {"emoji": "🦎", "rarity": "rare"},
}

RL_CATEGORIES = ["fundamentals", "algorithms", "papers", "tools", "courses", "datasets", "blogs", "videos"]

MOODS = {
    "happy": "😊",
    "calm": "😌",
    "cozy": "🍵",
    "tired": "😴",
    "excited": "🎉",
    "sad": "😢",
    "anxious": "😰",
    "grateful": "🙏",
    "creative": "🎨",
    "focused": "🎯",
}
