import aiosqlite

async def init_db(path: str):
    async with aiosqlite.connect(path) as db:
        await db.executescript("""
        CREATE TABLE IF NOT EXISTS guild_config (
            guild_id          INTEGER PRIMARY KEY,
            ticket_category   INTEGER,
            ticket_limit      INTEGER DEFAULT 1,
            support_role_id   INTEGER,
            join_channel_id   INTEGER,
            leave_channel_id  INTEGER,
            join_message      TEXT,
            leave_message     TEXT,
            invite_tracking   INTEGER DEFAULT 0,
            lang              TEXT DEFAULT 'en'
        );
        CREATE TABLE IF NOT EXISTS tickets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id    INTEGER,
            user_id     INTEGER,
            channel_id  INTEGER,
            topic       TEXT,
            status      TEXT DEFAULT 'open',
            opened_at   INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS economy (
            user_id     INTEGER PRIMARY KEY,
            coins       INTEGER DEFAULT 0,
            bank        INTEGER DEFAULT 0,
            last_daily  INTEGER DEFAULT 0,
            last_work   INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS pets (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER,
            name        TEXT,
            type        TEXT,
            hunger      INTEGER DEFAULT 100,
            happiness   INTEGER DEFAULT 100,
            energy      INTEGER DEFAULT 100,
            last_fed    INTEGER DEFAULT 0,
            last_played INTEGER DEFAULT 0,
            last_slept  INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS moods (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id   INTEGER,
            guild_id  INTEGER,
            mood      TEXT,
            note      TEXT,
            logged_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS rl_resources (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            title     TEXT,
            url       TEXT UNIQUE,
            category  TEXT,
            desc      TEXT,
            upvotes   INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS rl_votes (
            user_id     INTEGER,
            resource_id INTEGER,
            PRIMARY KEY (user_id, resource_id)
        );
        CREATE TABLE IF NOT EXISTS reminders (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id   INTEGER,
            channel_id INTEGER,
            message   TEXT,
            remind_at INTEGER,
            done      INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS invite_cache (
            code TEXT PRIMARY KEY,
            uses INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS invite_stats (
            guild_id   INTEGER,
            inviter_id INTEGER,
            code       TEXT PRIMARY KEY,
            uses       INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS premium_users (
            user_id  INTEGER PRIMARY KEY,
            granted_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS premium_guilds (
            guild_id   INTEGER PRIMARY KEY,
            granted_at INTEGER DEFAULT (strftime('%s','now'))
        );
        CREATE TABLE IF NOT EXISTS social_profiles (
            user_id         INTEGER PRIMARY KEY,
            rep             INTEGER DEFAULT 0,
            last_rep_given  INTEGER DEFAULT 0,
            hugs_given      INTEGER DEFAULT 0,
            hugs_received   INTEGER DEFAULT 0,
            pats_given      INTEGER DEFAULT 0,
            pats_received   INTEGER DEFAULT 0,
            slaps_given     INTEGER DEFAULT 0,
            slaps_received  INTEGER DEFAULT 0,
            bio             TEXT,
            lastfm_username TEXT,
            badges          TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS levels (
            guild_id   INTEGER,
            user_id    INTEGER,
            xp         INTEGER DEFAULT 0,
            level      INTEGER DEFAULT 0,
            rank_color TEXT,
            PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS level_config (
            guild_id         INTEGER PRIMARY KEY,
            xp_min           INTEGER DEFAULT 15,
            xp_max           INTEGER DEFAULT 25,
            xp_cooldown      INTEGER DEFAULT 60,
            level_up_channel INTEGER,
            level_up_msg     TEXT,
            xp_multiplier    REAL DEFAULT 1.0,
            no_xp_roles      TEXT DEFAULT '',
            no_xp_channels   TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS level_roles (
            guild_id INTEGER,
            level    INTEGER,
            role_id  INTEGER,
            PRIMARY KEY (guild_id, level)
        );
        CREATE TABLE IF NOT EXISTS rpg_chars (
            guild_id INTEGER,
            user_id  INTEGER,
            class    TEXT DEFAULT 'warrior',
            hp       INTEGER DEFAULT 100,
            max_hp   INTEGER DEFAULT 100,
            atk      INTEGER DEFAULT 15,
            def      INTEGER DEFAULT 10,
            spd      INTEGER DEFAULT 5,
            level    INTEGER DEFAULT 1,
            xp       INTEGER DEFAULT 0,
            gold     INTEGER DEFAULT 50,
            weapon   TEXT,
            armor    TEXT,
            PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS rpg_inventory (
            guild_id INTEGER,
            user_id  INTEGER,
            item_id  TEXT,
            quantity INTEGER DEFAULT 1,
            PRIMARY KEY (guild_id, user_id, item_id)
        );
        CREATE TABLE IF NOT EXISTS card_collection (
            user_id   INTEGER,
            card_name TEXT,
            rarity    TEXT,
            count     INTEGER DEFAULT 1,
            PRIMARY KEY (user_id, card_name)
        );
        CREATE TABLE IF NOT EXISTS fish_bucket (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER,
            fish_name  TEXT,
            emoji      TEXT,
            sell_price INTEGER
        );
        CREATE TABLE IF NOT EXISTS farm_plots (
            user_id    INTEGER,
            slot       INTEGER,
            crop       TEXT,
            planted_at REAL,
            PRIMARY KEY (user_id, slot)
        );
        CREATE TABLE IF NOT EXISTS mine_inventory (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER,
            ore_name   TEXT,
            emoji      TEXT,
            sell_price INTEGER
        );
        CREATE TABLE IF NOT EXISTS custom_commands (
            guild_id    INTEGER,
            name        TEXT,
            response    TEXT,
            embed_color INTEGER DEFAULT 16749972,
            image_url   TEXT,
            uses        INTEGER DEFAULT 0,
            PRIMARY KEY (guild_id, name)
        );
        CREATE TABLE IF NOT EXISTS shop_purchases (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER,
            item_id      TEXT,
            purchased_at INTEGER
        );
        """)
        await db.commit()
